#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <arpa/inet.h>
#include "macHdrs.h"

uint16_t payloadSize(uint8_t *pkt) {
    firstHdrByte firstByte;
    firstByte = (firstHdrByte) (pkt[0]);

    if (firstByte.fields.F == 0) {
        return (uint16_t) (pkt[1]);
    } else {
        return ntohs(*((uint16_t *)&pkt[1]));
    }
}

uint8_t *ptrToPayload(uint8_t *pkt) {
    firstHdrByte firstByte;
    firstByte = (firstHdrByte) (pkt[0]);

    if (firstByte.fields.F == 0) {
        return (pkt+2);
    } else {
        return (pkt+3);
    }
}

uint8_t getLCID(uint8_t *pkt) {
    firstHdrByte firstByte;
    firstByte = (firstHdrByte) (pkt[0]);
    return firstByte.fields.LCID;
}

mac16BitHdr generate16BitHdr(uint8_t F, uint8_t LCID, uint8_t L) {
    if (F != 0 && F != 1) {
        fprintf(stderr, "Bad F in generate16BitHdr.\n");
        exit(EXIT_FAILURE);
    }

    mac16BitHdr macHdr;
    macHdr.firstByte.fields.R = 0;
    macHdr.firstByte.fields.F = F;
    macHdr.firstByte.fields.LCID = LCID;
    macHdr.L = L;

    return macHdr;
}

mac24BitHdr generate24BitHdr(uint8_t F, uint8_t LCID, uint16_t L) {
    if (F != 0 && F != 1) {
        fprintf(stderr, "Bad F in generate24BitHdr.\n");
        exit(EXIT_FAILURE);
    }

    mac24BitHdr macHdr;
    macHdr.firstByte.fields.R = 0;
    macHdr.firstByte.fields.F = F;
    macHdr.firstByte.fields.LCID = LCID;
    macHdr.L = htons(L);

    return macHdr;
}

