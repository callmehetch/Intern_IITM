#ifndef _RINGBUFFER_H
#define _RINGBUFFER_H 1

#include <stdint.h>

#define MAX_BUF_SIZE 1024

typedef struct _ringBuffer {
    uint8_t data[MAX_BUF_SIZE];
    uint32_t length;
    uint32_t readIndex;
    uint32_t writeIndex;
} ringBuffer;

ringBuffer *getBuffer();

size_t writeToBuffer(ringBuffer *buffer, 
                  size_t bytes, 
                  uint8_t *source);

size_t readFromBuffer(ringBuffer *buffer, 
                   size_t bytes, 
                   uint8_t *dest);

void freeBuffer(ringBuffer *buffer);

#endif
