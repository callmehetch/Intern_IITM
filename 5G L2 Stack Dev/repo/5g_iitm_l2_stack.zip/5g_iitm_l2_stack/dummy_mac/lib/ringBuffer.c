#include <stdint.h>
#include <stdlib.h>
#include "ringBuffer.h"

ringBuffer *getBuffer() {
    ringBuffer *buffer;
    buffer = malloc(sizeof(ringBuffer));
    buffer->length = 0;
    buffer->readIndex = 0;
    buffer->writeIndex = 0;
    return buffer;
}

size_t writeToBuffer(ringBuffer *buffer,
                     size_t bytes,
                     uint8_t *source)
{
    size_t bytesWritten;
    bytesWritten = 0;
    while (bytesWritten < bytes && buffer->length < MAX_BUF_SIZE) {
        buffer->data[buffer->writeIndex] = *source;
        buffer->length++;
        buffer->writeIndex = (buffer->writeIndex + 1) % MAX_BUF_SIZE;
        source++;
        bytesWritten++;
    }
    return bytesWritten;
}

size_t readFromBuffer(ringBuffer *buffer,
                      size_t bytes,
                      uint8_t *dest)
{
    size_t bytesRead;
    bytesRead = 0;
    while (bytesRead < bytes && buffer->length > 0) {
        *dest = buffer->data[buffer->readIndex];
        buffer->length--;
        buffer->readIndex = (buffer->readIndex + 1) % MAX_BUF_SIZE;
        dest++;
        bytesRead++;
    }
    return bytesRead;
}

void freeBuffer(ringBuffer *buffer) {
    free(buffer);
}

