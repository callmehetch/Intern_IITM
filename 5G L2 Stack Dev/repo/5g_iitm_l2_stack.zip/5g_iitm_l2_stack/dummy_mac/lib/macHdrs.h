#ifndef _MACHDRS_H
#define _MACHDRS_H 1

#include <stdint.h>

typedef union _firstHdrByte {
    struct {
        uint8_t LCID    : 6;
        uint8_t F       : 1;
        uint8_t R       : 1;
    } fields;
    uint8_t byte;
} firstHdrByte;

typedef struct __attribute__((__packed__)) _mac16BitHdr {
    firstHdrByte    firstByte;
    uint8_t         L;      
} mac16BitHdr;

typedef struct __attribute__((__packed__)) _mac24BitHdr {
    firstHdrByte    firstByte;
    uint16_t        L;
} mac24BitHdr;

uint16_t payloadSize(uint8_t *pkt);
uint8_t *ptrToPayload(uint8_t *pkt);
uint8_t getLCID(uint8_t *pkt);
mac16BitHdr generate16BitHdr(uint8_t F, uint8_t LCID, uint8_t L);
mac24BitHdr generate24BitHdr(uint8_t F, uint8_t LCID, uint16_t L);

#endif
