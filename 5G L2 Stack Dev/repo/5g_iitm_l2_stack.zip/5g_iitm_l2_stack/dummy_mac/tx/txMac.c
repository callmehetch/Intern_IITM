#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#include <err.h>
#include <errno.h>
#include <strings.h>
#include <string.h>
#include <dirent.h>
#include "../lib/ringBuffer.h"
#include "../lib/macHdrs.h"

#define PORT 5555
#define MAX_UE_NUM 10
#define MAX_LCHANNELS (32*MAX_UE_NUM)
#define PKTSIZE 512

#define MAX_IPC_FNAME 100
#define IPC_SEM_STR "/txSem"
#define IPC_SHM_STR "/txShm"
#define MAX_IPC_STR (MAX_IPC_FNAME+10)

#define CONFIG_FTYPE ".txt"
#define MAX_CONFIG_NAME 100

typedef struct _txLChannel {
    uint8_t LCID;
    uint8_t ueid;
    ringBuffer *buffer;
    sem_t *sem;
    int bufFd;
    struct sockaddr_in rxAddr;
} txLChannel;

typedef struct sockaddr SA;

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Give at least one argument.\n");
        exit(EXIT_FAILURE);
    }

    txLChannel lcs[MAX_LCHANNELS];

    char config[MAX_LCHANNELS][MAX_CONFIG_NAME+1];
    uint32_t numConfigLCs;
    DIR *configDir;
    configDir = opendir(argv[1]);
    if (configDir == NULL) {
        err(errno, "Error opening directory %s", argv[1]);
    }
    numConfigLCs = 0;
    while (numConfigLCs < MAX_LCHANNELS) {
        struct dirent *dirEntry;
        if ((dirEntry = readdir(configDir)) == NULL) {
            break;
        }
        char fName[MAX_CONFIG_NAME+1];
        strncpy(fName, argv[1], MAX_CONFIG_NAME);
        if (fName[strlen(fName)-1] != '/') {
            strcat(fName, "/");
        }
        strncat(fName, dirEntry->d_name, MAX_CONFIG_NAME-strlen(fName));
        int fNameLen, configTypeLen;
        fNameLen = strlen(fName);
        configTypeLen = strlen(CONFIG_FTYPE);
        if (fNameLen <= configTypeLen || fNameLen > MAX_CONFIG_NAME) {
            continue;
        }
        if (strcmp(fName+fNameLen-configTypeLen, CONFIG_FTYPE) == 0) {
            strcpy(config[numConfigLCs], fName);
            numConfigLCs++;
        }
    }
    closedir(configDir);

    int sockfd;
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1) {
        err(errno, "Socket creation failed in TX");
    }

    uint32_t numLChannels;
    numLChannels = 0;
    while (numLChannels < numConfigLCs) {
        FILE *configFile = fopen(config[numLChannels], "r");
        char semStr[MAX_IPC_STR];
        char shmStr[MAX_IPC_STR];
        char readStr[MAX_IPC_FNAME];
        int fd;
        uint8_t lcid;
        uint8_t ueid;
        ringBuffer *buffer;
        sem_t *sem;
        struct sockaddr_in addr;

        strcpy(semStr, IPC_SEM_STR);
        strcpy(shmStr, IPC_SHM_STR);

        fgets(readStr, MAX_IPC_FNAME, configFile);
        if (readStr[strlen(readStr)-1] == '\n') {
            readStr[strlen(readStr)-1] = '\0';
        }
        ueid = (uint8_t) atoi(readStr);
        strncpy(semStr+strlen(semStr), readStr, MAX_IPC_FNAME);
        strcpy(semStr+strlen(semStr), "-");
        strncpy(shmStr+strlen(shmStr), readStr, MAX_IPC_FNAME);
        strcpy(shmStr+strlen(shmStr), "-");

        fgets(readStr, MAX_IPC_FNAME, configFile);
        if (readStr[strlen(readStr)-1] == '\n') {
            readStr[strlen(readStr)-1] = '\0';
        }
        lcid = (uint8_t) atoi(readStr);
        strncpy(semStr+strlen(semStr), readStr, MAX_IPC_FNAME);
        strncpy(shmStr+strlen(shmStr), readStr, MAX_IPC_FNAME);

        fgets(readStr, MAX_IPC_FNAME, configFile);
        if (readStr[strlen(readStr)-1] == '\n') {
            readStr[strlen(readStr)-1] = '\0';
        }
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(PORT);
        addr.sin_addr.s_addr = inet_addr(readStr);

        fclose(configFile);

        fd = shm_open(shmStr, O_CREAT | O_RDWR, S_IRWXU);
        if (fd == -1) {
            fprintf(stderr, "Error creating shared memory fpr %s.\n",
                                                     config[numLChannels]);
            numLChannels++;
            continue;
        }
        if (ftruncate(fd, sizeof(ringBuffer)) == -1) {
            fprintf(stderr, "Error truncating memory for %s.\n",
                                                     config[numLChannels]);
            shm_unlink(shmStr);
            numLChannels++;
            continue;
        }
        buffer = mmap(NULL, sizeof(ringBuffer),
                      PROT_READ | PROT_WRITE,
                      MAP_SHARED, fd, 0);
        if (buffer == MAP_FAILED) {
            fprintf(stderr, "mmap falied for %s.\n", config[numLChannels]);
            shm_unlink(shmStr);
            numLChannels++;
            continue;
        }

        sem = sem_open(semStr, O_CREAT | O_RDWR, S_IRWXU, 1);
        if (sem == SEM_FAILED) {
            fprintf(stderr, "sem_open failed for %s.\n", 
                                                     config[numLChannels]);
            shm_unlink(shmStr);
            numLChannels;
            continue;
        }

        lcs[numLChannels].LCID = lcid;
        lcs[numLChannels].ueid = ueid;
        lcs[numLChannels].buffer = buffer;
        lcs[numLChannels].sem = sem;
        lcs[numLChannels].bufFd = fd;
        lcs[numLChannels].rxAddr = addr;

        numLChannels++;
    }

    uint32_t bytesRead[MAX_LCHANNELS];
    memset(bytesRead, 0, (sizeof(*bytesRead))*MAX_LCHANNELS);
    uint8_t buf[MAX_LCHANNELS][PKTSIZE+sizeof(mac24BitHdr)];
    while (1) {
        for (int i = 0; i < numLChannels; i++) {
            mac24BitHdr hdr;
            sem_wait(lcs[i].sem);
            bytesRead[i] += readFromBuffer(lcs[i].buffer, 
                                        PKTSIZE-bytesRead[i], 
                                        buf[i]+bytesRead[i]+sizeof(hdr));
            sem_post(lcs[i].sem);

            if (bytesRead[i] >= PKTSIZE) {
                hdr = generate24BitHdr(1, lcs[i].LCID, PKTSIZE);
                *((mac24BitHdr *)buf[i]) = hdr;
                int sent;
                sent = sendto(sockfd, buf[i], PKTSIZE+sizeof(hdr), 0,
                         (SA *)&lcs[i].rxAddr, sizeof(lcs[i].rxAddr));
                if (sent != PKTSIZE+sizeof(hdr)) {
                    fprintf(stderr, "Error sending to %s.\n", config[i]);
                }
                bytesRead[i] -= PKTSIZE;
            }
            usleep(100);
        }
    }

    return 0;
}

