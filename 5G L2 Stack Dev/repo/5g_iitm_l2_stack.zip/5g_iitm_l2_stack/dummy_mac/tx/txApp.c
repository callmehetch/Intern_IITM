#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#include <err.h>
#include <errno.h>
#include <strings.h>
#include <string.h>
#include "../lib/ringBuffer.h"
#include "../lib/macHdrs.h"

#define FIRST_INDICATOR 0x55
#define MID_INDICATOR 0x00
#define LAST_INDICATOR 0xAA
#define APP_PKTSIZE 1024

#define MAX_IPC_FNAME 100
#define IPC_SEM_STR "/txSem"
#define IPC_SHM_STR "/txShm"
#define MAX_IPC_STR (MAX_IPC_FNAME+10)

int main(int argc, char **argv) {
    if (argc < 1) {
        fprintf(stderr, "Give at least one argument.\n");
        exit(EXIT_FAILURE);
    }

    ringBuffer *buffer;
    sem_t *sem;
    int bufFd;
    char semStr[MAX_IPC_STR];
    char shmStr[MAX_IPC_STR];
    char readStr[MAX_IPC_FNAME];

    strcpy(semStr, IPC_SEM_STR);
    strcpy(shmStr, IPC_SHM_STR);

    FILE *config;
    config = fopen(argv[1], "r");

    /* ueid */
    fgets(readStr, MAX_IPC_FNAME, config);
    if (readStr[strlen(readStr)-1] == '\n') {
        readStr[strlen(readStr)-1] = '\0';
    }
    strncpy(semStr+strlen(semStr), readStr, MAX_IPC_FNAME);
    strcpy(semStr+strlen(semStr), "-");
    strncpy(shmStr+strlen(shmStr), readStr, MAX_IPC_FNAME);
    strcpy(shmStr+strlen(shmStr), "-");

    /* lcid */
    fgets(readStr, MAX_IPC_FNAME, config);
    if (readStr[strlen(readStr)-1] == '\n') {
        readStr[strlen(readStr)-1] = '\0';
    }
    strncpy(semStr+strlen(semStr), readStr, MAX_IPC_FNAME);
    strncpy(shmStr+strlen(shmStr), readStr, MAX_IPC_FNAME);

    /* address */
    fgets(readStr, MAX_IPC_FNAME, config);

    /* file to send */
    fgets(readStr, MAX_IPC_FNAME, config);
    char lastByte = readStr[strlen(readStr)-1];
    if (lastByte == '\n' || lastByte == EOF) {
        readStr[strlen(readStr)-1] = '\0';
    }

    fclose(config);

    FILE *fileToSend;
    fileToSend = fopen(readStr, "r");
    if (fileToSend == NULL) {
        fprintf(stderr, "Opening file %s failed\n", readStr);
    }

    bufFd = shm_open(shmStr, O_RDWR, 0);
    if (bufFd == -1) {
        err(errno, "shm_open failed in app");
    }
    buffer = mmap(NULL, sizeof(ringBuffer),
                  PROT_READ | PROT_WRITE,
                  MAP_SHARED, bufFd, 0);
    if (buffer == MAP_FAILED) {
        shm_unlink(shmStr);
        err(errno, "mmap failed in app");
    }

    sem = sem_open(semStr, 0);
    if (sem == SEM_FAILED) {
        shm_unlink(shmStr);
        err(errno, "sem_open failed in app");
    }

    sem_unlink(semStr);
    shm_unlink(shmStr);
        
    uint8_t buf[APP_PKTSIZE];

    buf[0] = FIRST_INDICATOR;
    strncpy(buf+1, readStr, APP_PKTSIZE-2);
    buf[APP_PKTSIZE-1] = '\0';
    uint32_t bytesWritten;
    bytesWritten = 0;
    while (bytesWritten < APP_PKTSIZE) {
        sem_wait(sem);
        bytesWritten += writeToBuffer(buffer,
                                      APP_PKTSIZE-bytesWritten,
                                      buf+bytesWritten);
        sem_post(sem);
    }

    while (1) {
        uint16_t sizeRead = fread(buf+1, sizeof(uint8_t),
                                            APP_PKTSIZE-3, fileToSend);
        if (ferror(fileToSend)) {
            fprintf(stderr, "Error reading from file %s\n", readStr);
            exit(EXIT_FAILURE);
        }

        if (feof(fileToSend)) {
            buf[0] = LAST_INDICATOR;
            *((uint16_t *)&buf[APP_PKTSIZE-2]) = sizeRead;

            uint32_t bytesWritten;
            bytesWritten = 0;
            while (bytesWritten < APP_PKTSIZE) {
                sem_wait(sem);
                bytesWritten += writeToBuffer(buffer,
                                              APP_PKTSIZE-bytesWritten,
                                              buf+bytesWritten);
                sem_post(sem);
            }

            break;
        }

        buf[0] = MID_INDICATOR;
        uint32_t bytesWritten;
        bytesWritten = 0;
        while (bytesWritten < APP_PKTSIZE) {
            sem_wait(sem);
            bytesWritten += writeToBuffer(buffer,
                                          APP_PKTSIZE-bytesWritten,
                                          buf+bytesWritten);
            sem_post(sem);
        }
    }

    fclose(fileToSend);

    return 0;
}

