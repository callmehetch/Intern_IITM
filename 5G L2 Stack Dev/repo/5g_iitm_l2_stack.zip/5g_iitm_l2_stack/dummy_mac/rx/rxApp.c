#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#include <err.h>
#include <errno.h>
#include <strings.h>
#include <string.h>
#include "../lib/ringBuffer.h"
#include "../lib/macHdrs.h"


#define FIRST_INDICATOR 0x55
#define MID_INDICATOR 0x00
#define LAST_INDICATOR 0xAA
#define APP_PKTSIZE 1024

#define MAX_IPC_FNAME 100
#define IPC_SEM_STR "/rxSem"
#define IPC_SHM_STR "/rxShm"
#define MAX_IPC_STR (MAX_IPC_FNAME+10)

int main(int argc, char **argv) {
    uint8_t buf[APP_PKTSIZE];
    ringBuffer *buffer;
    sem_t *sem;
    int bufFd;
    FILE *fileToRecv = NULL;

    FILE *configFile = fopen(argv[1], "r");
    char semStr[MAX_IPC_STR];
    char shmStr[MAX_IPC_STR];
    char strLCID[MAX_IPC_FNAME];

    strcpy(semStr, IPC_SEM_STR);
    strcpy(shmStr, IPC_SHM_STR);

    fgets(strLCID, MAX_IPC_FNAME, configFile);
    fclose(configFile);

    char lastByte = strLCID[strlen(strLCID)-1];
    if (lastByte == '\n' || lastByte == EOF) {
        strLCID[strlen(strLCID)-1] = '\0';
    }
    strncpy(semStr+strlen(IPC_SEM_STR), strLCID, MAX_IPC_FNAME);
    strncpy(shmStr+strlen(IPC_SHM_STR), strLCID, MAX_IPC_FNAME);

    /* Open shared memory created by MAC */
    bufFd = shm_open(shmStr, O_RDWR, 0);
    if (bufFd == -1) {
        err(errno, "shm_open falied in app");
    }
    buffer = mmap(NULL, sizeof(ringBuffer),
                  PROT_READ | PROT_WRITE,
                  MAP_SHARED, bufFd, 0);
    if (buffer == MAP_FAILED) {
        shm_unlink(shmStr);
        err(errno, "mmap falied in app");
    }

    sem  = sem_open(semStr, 0);
    if (sem == SEM_FAILED) {
        shm_unlink(shmStr);
        err(errno, "sem_open falied in app");
    }

    sem_unlink(semStr);
    shm_unlink(shmStr);

    // get lock
    // read data
    // check indicator
    // if last break out of loop
    while (1) {

        size_t bytesRead;
        bytesRead = 0;
        while (bytesRead < APP_PKTSIZE) {
            sem_wait(sem);
            bytesRead += readFromBuffer(buffer,
                                        APP_PKTSIZE-bytesRead, 
                                        buf+bytesRead);
            sem_post(sem);
        }

        if (fileToRecv == NULL) {
            if (buf[0] != FIRST_INDICATOR) {
                fprintf(stderr, "Error in first packet.\n");
                exit(EXIT_FAILURE);
            }
            fileToRecv = fopen(buf+1, "w");
            if (fileToRecv == NULL || ferror(fileToRecv)) {
                fprintf(stderr, "Error opening file %s.\n", buf+1);
                exit(EXIT_FAILURE);
            }
        } else if (buf[0] == MID_INDICATOR) {
            fwrite(buf+1, sizeof(uint8_t), APP_PKTSIZE-3, fileToRecv);
            if (ferror(fileToRecv)) {
                fprintf(stderr, "Error writing middle packet to file.\n");
                exit(EXIT_FAILURE);
            }
        } else if (buf[0] == LAST_INDICATOR) {
            uint16_t lastPktSize = *(uint16_t *)(&buf[APP_PKTSIZE-2]);
            fwrite(buf+1, sizeof(uint8_t), lastPktSize, fileToRecv);
            if (ferror(fileToRecv)) {
                fprintf(stderr, "Error writing last packet to file.\n");
                exit(EXIT_FAILURE);
            }
            break;
        } else {
            fprintf(stderr, "Error in packet indicator.\n");
            exit(EXIT_FAILURE);
        }
    }

    fclose(fileToRecv);

    return 0;
}

