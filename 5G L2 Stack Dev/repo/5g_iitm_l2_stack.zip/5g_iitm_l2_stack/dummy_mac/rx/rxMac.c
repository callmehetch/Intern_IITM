#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#include <err.h>
#include <errno.h>
#include <strings.h>
#include <string.h>
#include <dirent.h>
#include "../lib/ringBuffer.h"
#include "../lib/macHdrs.h"

#define PORT 5555
#define MAX_LCHANNELS 32
#define PKTSIZE 512

#define MAX_IPC_FNAME 100
#define IPC_SEM_STR "/rxSem"
#define IPC_SHM_STR "/rxShm"
#define MAX_IPC_STR (MAX_IPC_FNAME+10)

#define CONFIG_FTYPE ".txt"
#define MAX_CONFIG_NAME 100

typedef struct _lChannel {
    uint8_t LCID;
    ringBuffer *buffer;
    sem_t *sem;
    int bufFd;
} lChannel;

typedef struct sockaddr SA;

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Give at least one argument.\n");
        exit(EXIT_FAILURE);
    }

    lChannel lcs[MAX_LCHANNELS];
    lChannel *lcidToChannel[MAX_LCHANNELS];
    uint8_t buf[PKTSIZE+sizeof(mac24BitHdr)];

    char config[MAX_LCHANNELS][MAX_CONFIG_NAME+1];
    uint32_t numConfigLCs;
    DIR *configDir;
    configDir = opendir(argv[1]);
    if (configDir == NULL) {
        err(errno, "Error opening directory %s", argv[1]);
    }
    numConfigLCs = 0;
    while (numConfigLCs < MAX_LCHANNELS) {
        struct dirent *dirEntry;
        if ((dirEntry = readdir(configDir)) == NULL) {
            break;
        }
        char fName[MAX_CONFIG_NAME+1];
        strncpy(fName, argv[1], MAX_CONFIG_NAME);
        if (fName[strlen(fName)-1] != '/') {
            strcat(fName, "/");
        }
        strncat(fName, dirEntry->d_name, MAX_CONFIG_NAME-strlen(fName));
        int fNameLen, configTypeLen;
        fNameLen = strlen(fName);
        configTypeLen = strlen(CONFIG_FTYPE);
        if (fNameLen <= configTypeLen || fNameLen > MAX_CONFIG_NAME) {
            continue;
        }
        if (strcmp(fName+fNameLen-configTypeLen, CONFIG_FTYPE) == 0) {
            strcpy(config[numConfigLCs], fName);
            numConfigLCs++;
        }
    }
    closedir(configDir);

    int sockfd;
    struct sockaddr_in servaddr;
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == -1) {
        err(errno, "Socket creation failed in RX");
    }
    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = INADDR_ANY;
    if (bind(sockfd, (SA *)&servaddr, sizeof(servaddr)) != 0) {
        err(errno, "Error binding socket");
    }


    for (int i = 0; i < MAX_LCHANNELS; i++) {
        lcidToChannel[i] = NULL;
    }

    uint8_t numLChannels;
    numLChannels = 0;
    while (numLChannels < numConfigLCs) {
        FILE *configFile = fopen(config[numLChannels], "r");
        char semStr[MAX_IPC_STR];
        char shmStr[MAX_IPC_STR];
        char strLCID[MAX_IPC_FNAME];
        int fd;
        uint8_t lcid;
        ringBuffer *buffer;
        sem_t *sem;

        strcpy(semStr, IPC_SEM_STR);
        strcpy(shmStr, IPC_SHM_STR);

        fgets(strLCID, MAX_IPC_FNAME, configFile);
        fclose(configFile);

        char lastByte = strLCID[strlen(strLCID)-1];
        if (lastByte == '\n' || lastByte == EOF) {
            strLCID[strlen(strLCID)-1] = '\0';
        }
        strncpy(semStr+strlen(IPC_SEM_STR), strLCID, MAX_IPC_FNAME);
        strncpy(shmStr+strlen(IPC_SHM_STR), strLCID, MAX_IPC_FNAME);

        lcid = (uint8_t) atoi(strLCID);

        /* Create shared memory mapping for buffer */
        fd = shm_open(shmStr, O_CREAT | O_RDWR, S_IRWXU);
        if (fd == -1) {
            fprintf(stderr, "Error creating memory for %s.\n",
                                                config[numLChannels]);
            numLChannels++;
            continue;
        }
        if (ftruncate(fd, sizeof(ringBuffer)) == -1) {
            fprintf(stderr, "Error truncating memory for %s.\n",
                                                config[numLChannels]);
            shm_unlink(shmStr);
            numLChannels++;
            continue;
        }
        buffer = mmap(NULL, sizeof(ringBuffer), 
                      PROT_READ | PROT_WRITE,
                      MAP_SHARED, fd, 0);
        if (buffer == MAP_FAILED) {
            fprintf(stderr, "mmap falied for %s.\n", config[numLChannels]);
            shm_unlink(shmStr);
            numLChannels++;
            continue;
        }

        /* Create semaphore for this buffer */
        sem = sem_open(semStr, O_CREAT | O_RDWR, S_IRWXU, 1);
        if (sem == SEM_FAILED) {
            fprintf(stderr, "sem_open failed for %s.\n",
                                                config[numLChannels]);
            shm_unlink(shmStr);
            numLChannels++;
            continue;
        }

        lcs[numLChannels].LCID = lcid;
        lcs[numLChannels].buffer = buffer;
        lcs[numLChannels].sem = sem;
        lcs[numLChannels].bufFd = fd;

        lcidToChannel[lcid] = &lcs[numLChannels];

        numLChannels++;
    }

    //loop begin
    //sem_wait()
    //put data in appropriate buffer
    //sem_post()
    //get data from tx
    //loop end

    while (1) {
        /* Receive packet */
        int received = recvfrom(sockfd, buf, PKTSIZE+sizeof(mac24BitHdr), 0, NULL, NULL);

        lChannel *channel;
        channel = lcidToChannel[getLCID(buf)];

        uint8_t *payload;
        uint16_t size;
        payload = ptrToPayload(buf);
        size = payloadSize(buf);

        size_t bytesWritten;
        bytesWritten = 0;
        while (bytesWritten < PKTSIZE) {
            sem_wait(channel->sem);
            bytesWritten += writeToBuffer(channel->buffer, 
                                          size-bytesWritten, 
                                          payload+bytesWritten);
            sem_post(channel->sem);
        }
    }

    return 0;
}

