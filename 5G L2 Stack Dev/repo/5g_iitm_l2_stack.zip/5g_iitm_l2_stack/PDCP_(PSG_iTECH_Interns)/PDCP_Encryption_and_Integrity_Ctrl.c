/*
    Date        :   25-09-2019
    Version     :   2.0
    Authors     :   Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
    Includes    :   Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
    5G Testbed interns
*/

/* @brief Encryption and Authentication control
 *
 * @details Contains the control to perform Encryption
 * and Authentiaction check process according to the algorithm 
 * stated by the upper layers.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "PDCP_Snow3G.c"
#include "PDCP_AES.c"
#include "PDCP_ZUC.c"

#define KEY_SIZE 16                                                              //Size of main Key in bits.

/* Perfoming Encryption/Decryption Operation */

/*
    Function to perform ciphering/deciphering .
    @param  integrity_algorithm     type of algorithm to be used for ciphering/deciphering.
    @param  data_len                length of sdu packet without pdu header attached.
    @param  payload                 pointer to sdu packet with 2 byte offset(Because only the data part of the SDU is to be ciphered ) .
    @param  bearer                  holds QOS flow or Mapped flow.
    @param  dir;                    holds direction of dataflow(uplink or downlink).
    @param  count;                  holds 32 bit Frame dependent input.
    @param  key                     holds 128bit key for ciphering and integrity protection.
    
    */
uint8_t* ciphering_op( int ciphering_type,uint8_t *payload, uint32_t data_length,uint32_t bearer,uint32_t dir,uint32_t count,uint8_t *cip_key)
{
    uint8_t *data = payload;                                                     //Input payload.
    uint8_t *enc_dec_data;                                                       //Holds the Encrypted/Decrypted Data.
    int c_type = ciphering_type;                                                 //The variable c_type is assigned with the type of ciphering to be performed.
    uint32_t lenbits = data_length*8;                                            //total length of input payload in bits.
    enc_dec_data = malloc( (lenbits/8) * sizeof(uint8_t));                       //Buffer to store encrypted data.                                                                      //Encryption/Decryption 128-bit key.
    switch(c_type)
        {
            case 1:     
                printf("\nEncryption/Decryption Algorithm: Snow3G\n");
                /* Performing Encryprtion/Decryption using Snow3G algorithm */
                Snow3gCiph(cip_key ,count, bearer, dir,  data, enc_dec_data, lenbits);                
                break;
            case 2:
                printf("\nEncryption/Decryption Algorithm: AES\n");
                /* Performing Encryprtion/Decryption using AES algorithm */
                AesCiph (cip_key, count, bearer, dir, lenbits, data, enc_dec_data);
                break;
            case 3:
                printf("\nEncryption/Decryption Algorithm: ZUC\n");
                /* Performing Encryprtion/Decryption using ZUC algorithm */
                ZucCiph (cip_key, count, bearer, dir, lenbits,  (uint32_t*) data, (uint32_t*) enc_dec_data );
                break;
        }
    //free(data);
    //FIX FOR LARGER SIZE PACKETS
    for(int i=0;i<data_length;i++){
        data[i]=enc_dec_data[i];
    }
    free(enc_dec_data);
	return data;
}

/* Verifying the Authenticity of the data */

/*
    Function to perform integrity protection.
    @param  integrity_algorithm     type of algorithm to be used for mac generation
    @param  data_len                length of sdu packet with pdu header attached.
    @param  payload                 pointer to sdu packet
    @param  bearer                  holds QOS flow or Mapped flow.
    @param  dir;                    holds direction of dataflow(uplink or downlink).
    @param  count;                  holds 32 bit Frame dependent input.
    @param  key                     holds 128bit key for ciphering and integrity protection
    
    */
uint32_t integrity_op( int integrity_type,uint8_t *payload,uint32_t data_length,uint32_t bearer,uint32_t dir,uint32_t count,uint8_t* int_key)
{
    uint8_t *data = payload;                                                     //Input payload.
    int i_type = integrity_type;                                                 //The variable i_type is assigned with the type of Integrity check to be performed.
    uint32_t macI;                                                               //Holds the MAC value generated. 
    uint32_t maclenbits = data_length*8;                                         //Size of MAC generated in bits.
    // u_char int_key[KEY_SIZE] ={
    //                             0xd3, 0x48, 0x9b, 0xe8, 0x21, 0x08, 0x7a,0xcd,
    //                             0x02, 0x12, 0x3a, 0x92, 0x48, 0x03, 0x33,0x59
    //                             };                                               //Authentication 128-bit key.
    switch(i_type)
        {
            case 1:
                printf("\nAuthentication Algorithm: Snow3G\n");
                /* Mac generation using Snow3G */
                macI = Snow3gIntg(int_key, count, bearer, dir, data, maclenbits); 
                break;
            case 2:
                printf("\nAuthentication Algorithm: AES\n");
                /* Mac generation using AES */
                macI = AesCmac(int_key, data, maclenbits, &macI);                 
                break;
            case 3:
                printf("\nAuthentication Algorithm: ZUC\n");
                /* Mac generation using ZUC */
                macI= ZucIntg (int_key, count, dir, bearer, maclenbits, (uint32_t*) data, &macI);
                break;
        }
    return macI;
}

/* EOF */