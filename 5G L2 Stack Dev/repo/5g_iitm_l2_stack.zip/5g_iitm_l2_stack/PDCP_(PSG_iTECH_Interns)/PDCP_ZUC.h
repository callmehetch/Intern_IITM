/*
	Date 		:	25-09-2019
	Version		:	2.0
	Authors		:	Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
	Includes	:	Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
	5G Testbed interns
*/

/*@brief ZUC header
 *@details This module contains the structures 
 *and pre defined assignments required by the 
 *PDCP_ZUC module
 */

#include<string.h>
#include<arpa/inet.h>

#define ZUC_SBOX_SZ 256
#define ZUC_LFSR_SZ 16
#define D_CONST_SZ 16
#define MUL_POW_2(x,k) ((((x)<<k) | ((x)>>(31 - k))) & 0x7FFFFFFF)
#define _ROT(a,k) (((a) << k) | ((a) >> (32 - k)))
#define MAK_UINT_32(a, b, c, d) (((uint32_t)(a) << 24) | ((uint32_t)(b) << 16) | ((uint32_t)(c) << 8 ) | ((uint32_t)(d)))
#define MAK_UINT_31( a, b, c) (((uint32_t)(a) << 23) | ((uint32_t)(b) << 8) | (uint32_t)(c))

/*
 * @brief DS for holding Zuc Variables used for operation
 */
typedef struct ZucVars
{
    uint32_t lfsrS[ZUC_LFSR_SZ];
    uint32_t fR[2];
    uint32_t brcX[4];
    u_char sbOne[ZUC_SBOX_SZ];
    u_char sbZero[ZUC_SBOX_SZ];
    uint32_t ekD[D_CONST_SZ];
} ZucVarsT,
 *ZucVarsP;

void ZucMain ( u_char* zucKey, u_char* initVec, uint32_t* keyStr, uint32_t keyStrLen,uint32_t * data, uint32_t length);

/* EOF */