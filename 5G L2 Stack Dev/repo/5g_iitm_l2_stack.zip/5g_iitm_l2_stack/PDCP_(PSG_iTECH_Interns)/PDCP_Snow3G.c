/*
    Date        :   25-09-2019
    Version     :   2.0
    Authors     :   Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
    Includes    :   Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
    5G Testbed interns
*/

/*@brief Snow3G Encryption Decryption and Integrity protection
 *
 *@details To perform Snow3G Encryption decryption 
 *and Integrity protection
 */

#include "PDCP_Snow3G.h"

/*@brief This function maps 128 bits to 64 bits
 *
 * Invoked by Snow3gS1()/Snow3gS2()/Snow3gMulxPow()
 *
 * @param V :8 bit input
 * @param c :8 bit input
 */
static u_char Snow3gMulx ( u_char V, u_char c )
{
    if ( V & 0x80 )
    {
        return ( (V << 1) ^ c );
    }
    else
    {
        return ( V << 1);
    }

}

/*
 * @brief This function maps 128 bits and a positive integer i to 64 bit
 *
 * Invoked by Snow3gDivalpha()/Snow3gMulAlpha/Snow3gMulx()
 *
 *
 * @param V :8 bit input
 * @param i :positive integer- power
 * @param c :8 bit input
 */
static u_char Snow3gMulxPow ( u_char V, u_char i, u_char c )
{
    if ( i == 0)
    {
        return V;
    }
    else
    {
        return Snow3gMulx( Snow3gMulxPow( V, i-1, c ), c );
    }

}

/*
 * @brief to generate a 32 bit output from 8 bit input
 *
 * Invoked by Snow3gClkLFSRKStrmmd()/Snow3gClkLFSRinitmd()
 *
 * @param c :8 bit input
 */
static uint32_t Snow3gMulAlpha ( u_char c )
{
    return ( ( ((uint32_t)Snow3gMulxPow(c, 23, 0xa9)) << SFT_24 ) |
        ( ((uint32_t)Snow3gMulxPow(c, 245, 0xa9)) << SFT_16 ) |
        ( ((uint32_t)Snow3gMulxPow(c, 48, 0xa9)) << SFT_8 ) |
        ( ((uint32_t)Snow3gMulxPow(c, 239, 0xa9)) ) ) ;
}


/*
 * @brief to generate a 32 bit output from 8 bit input
 *
 * Invoked by Snow3gClkLFSRKStrmmd()/Snow3gClkLFSRinitmd()
 *
 * @param c :8 bit input
 */
static uint32_t Snow3gDivalpha ( u_char c )
{
    return ( ( ((uint32_t)Snow3gMulxPow(c, 16, 0xa9)) << SFT_24 ) |
        ( ((uint32_t)Snow3gMulxPow(c, 39, 0xa9)) << SFT_16 ) |
        ( ((uint32_t)Snow3gMulxPow(c, 6, 0xa9)) << SFT_8 ) |
        ( ((uint32_t)Snow3gMulxPow(c, 64, 0xa9)) ) ) ;
}

/*
 * @brief To Substitute value from SBOX and process it
 *
 * @details This take value from SBOX sBoxR and
 *           process it and send back value
 *
 * Invoked by Snow3gClkFsm()
 *
 * @param w  :a 32 bit input
 */
static uint32_t Snow3gS1 ( uint32_t w,Snow3gVarsP s3gVarst  )
{
    u_char r0=0, r1=0, r2=0, r3=0;
    u_char srw0 = s3gVarst->sBoxR[ (u_char)((w >> SFT_24) & 0xff) ];
    u_char srw1 = s3gVarst->sBoxR[ (u_char)((w >> SFT_16) & 0xff) ];
    u_char srw2 = s3gVarst->sBoxR[ (u_char)((w >> SFT_8) & 0xff) ];
    u_char srw3 = s3gVarst->sBoxR[ (u_char)((w) & 0xff) ];
    r0 = ( ( Snow3gMulx( srw0 , 0x1b) ) ^
        ( srw1 ) ^
        ( srw2 ) ^
        ( (Snow3gMulx( srw3, 0x1b)) ^ srw3 )
    );
    r1 = ( ( ( Snow3gMulx( srw0 , 0x1b) ) ^ srw0 ) ^
        ( Snow3gMulx ( srw1, 0x1b) ) ^
        ( srw2 ) ^
        ( srw3 )
    );
    r2 = ( ( srw0 ) ^
        ( ( Snow3gMulx( srw1 , 0x1b) ) ^ srw1 ) ^
        ( Snow3gMulx ( srw2, 0x1b) ) ^
        ( srw3 )
    );
    r3 = ( ( srw0 ) ^
        ( srw1 ) ^
        ( ( Snow3gMulx( srw2 , 0x1b) ) ^ srw2 ) ^
        ( Snow3gMulx ( srw3, 0x1b) )
    );
    return ( ( ((uint32_t)r0) << SFT_24 ) | ( ((uint32_t)r1) << SFT_16 )
            | ( ((uint32_t)r2) << SFT_8 ) | ( ((uint32_t)r3) ) );
}

/*
 * @brief To take value from SBOX sBoxQ and process it and send back value
 *
 * Invoked by Snow3gClkFsm()
 *
 * @param w  :a 32 bit input
 */
static uint32_t Snow3gS2 ( uint32_t w, Snow3gVarsP s3gVarst )
{
    u_char r0=0, r1=0, r2=0, r3=0;
    u_char sqw0 = s3gVarst->sBoxQ[ (u_char)((w >> SFT_24) & 0xff) ];
    u_char sqw1 = s3gVarst->sBoxQ[ (u_char)((w >> SFT_16) & 0xff) ];
    u_char sqw2 = s3gVarst->sBoxQ[ (u_char)((w >> SFT_8) & 0xff) ];
    u_char sqw3 = s3gVarst->sBoxQ[ (u_char)((w) & 0xff) ];
    r0 = ( ( Snow3gMulx( sqw0 , 0x69) ) ^
        ( sqw1 ) ^
        ( sqw2 ) ^
        ( (Snow3gMulx( sqw3, 0x69)) ^ sqw3 )
    );
    r1 = ( ( ( Snow3gMulx( sqw0 , 0x69) ) ^ sqw0 ) ^
        ( Snow3gMulx(sqw1, 0x69) ) ^
        ( sqw2 ) ^
        ( sqw3 )
    );
    r2 = ( ( sqw0 ) ^
        ( ( Snow3gMulx( sqw1 , 0x69) ) ^ sqw1 ) ^
        ( Snow3gMulx(sqw2, 0x69) ) ^
        ( sqw3 )
    );
    r3 = ( ( sqw0 ) ^
        ( sqw1 ) ^
        ( ( Snow3gMulx( sqw2 , 0x69) ) ^ sqw2 ) ^
        ( Snow3gMulx( sqw3, 0x69) )
    );
    return ( ( ((uint32_t)r0) << SFT_24 ) | ( ((uint32_t)r1) << SFT_16 ) |
            ( ((uint32_t)r2) << SFT_8 ) | ( ((uint32_t)r3) ) );
}

/*
 * @brief To Update LFSR Registers S0-S15 as the LFSR receives a single clock
 *
 * Invoked by Snow3gInit()
 *
 * @param fsmWrd   :32 bit Input word
 * @param s3gVarst :Pointer to Snow3g Variable Structure
 */
static void Snow3gClkLFSRinitmd ( uint32_t fsmWrd ,
                                      Snow3gVarsP s3gVarst)
{
    uint32_t v = ( ( ( s3gVarst->lfsrS[0] << SFT_8) & 0xffffff00 ) ^
                 ( Snow3gMulAlpha( (u_char)( ( s3gVarst->lfsrS[0] >>
                 SFT_24) & 0xff) ) ) ^  ( s3gVarst->lfsrS[2] ) ^
                 ( (s3gVarst->lfsrS[11] >> SFT_8) & 0x00ffffff ) ^
                 ( Snow3gDivalpha( (u_char)( ( s3gVarst->lfsrS[11])
                 & 0xff ) ) ) ^ ( fsmWrd ));
    for (int32_t i = 0; i < 15; i++)
    {
        s3gVarst->lfsrS[i] = s3gVarst->lfsrS[i+1];
    }
    s3gVarst->lfsrS[15] = v;
}

/*
 * @brief To Update LFSR Registers S0-S15 as the LFSR receives a single clock
 *
 * Invoked by Snow3gGenKs()
 *
 * @param s3gVarst :Pointer to Snow3g Variable Structure
 */
static void Snow3gClkLFSRKStrmmd ( Snow3gVarsP s3gVarst,uint8_t* data,uint32_t length)
{   
    uint32_t v = ( ( (s3gVarst->lfsrS[0] << SFT_8) & 0xffffff00 ) ^
                 ( Snow3gMulAlpha( (u_char)((s3gVarst->lfsrS[0] >> SFT_24)
                  &0xff) ) ) ^  ( s3gVarst->lfsrS[2] ) ^
                 ( (s3gVarst->lfsrS[11] >> SFT_8) & 0x00ffffff ) ^
                 ( Snow3gDivalpha( (u_char)( ( s3gVarst->lfsrS[11])
                                                    & 0xff ) ) ) );
    for (int32_t i = 0; i < 15; i++)
    {
        s3gVarst->lfsrS[i] = s3gVarst->lfsrS[i+1];
    }
    s3gVarst->lfsrS[15] = v;
}

/*
 * @brief To Update FSM registers R1, R2, R3.
 *
 * Invoked by Snow3gInit()/Snow3gGenKs()
 *
 * @param s3gVarst :Pointer to Snow3g Variable Structure
 */
static uint32_t Snow3gClkFsm ( Snow3gVarsP s3gVarst,uint8_t* data,uint32_t length)
{   

    uint32_t fsmWrd = ( ( s3gVarst->lfsrS[15] + s3gVarst->fsmR[0] ) &
            0xffffffff ) ^ s3gVarst->fsmR[1] ;
    uint32_t r = ( s3gVarst->fsmR[1] + ( s3gVarst->fsmR[2]
                   ^ s3gVarst->lfsrS[5] ) ) & 0xffffffff ;
    s3gVarst->fsmR[2] = Snow3gS2 ( s3gVarst->fsmR[1] ,s3gVarst );
    s3gVarst->fsmR[1] = Snow3gS1 ( s3gVarst->fsmR[0] ,s3gVarst);
    s3gVarst->fsmR[0] = r;
    return fsmWrd;
}

/*
 * @brief To initialize SNOW3G Algorithm
 *
 * Invoked by Snow3gInt()/Snow3gCip
 *
 * @param s3K[4]     :Four 32-bit words making up 128-bit key.
 * @param initVec[4] :Four 32-bit words making 128-bit initialization variable
 * @param s3gVarst   :Pointer to Snow3g Variable 
 */
static void Snow3gInit ( uint32_t s3K[4], uint32_t initVec[4],
                             Snow3gVarsP s3gVarst  ,uint8_t*data ,uint32_t length)
{
    u_char i=0;
    uint32_t fsmWrd = 0x0;
    s3gVarst->lfsrS[15] = s3K[3] ^ initVec[0];
    s3gVarst->lfsrS[14] = s3K[2];
    s3gVarst->lfsrS[13] = s3K[1];
    s3gVarst->lfsrS[12] = s3K[0] ^ initVec[1];
    s3gVarst->lfsrS[11] = s3K[3] ^ 0xffffffff;
    s3gVarst->lfsrS[10] = s3K[2] ^ 0xffffffff ^ initVec[2];
    s3gVarst->lfsrS[9] = s3K[1] ^ 0xffffffff ^ initVec[3];
    s3gVarst->lfsrS[8] = s3K[0] ^ 0xffffffff;
    s3gVarst->lfsrS[7] = s3K[3];
    s3gVarst->lfsrS[6] = s3K[2];
    s3gVarst->lfsrS[5] = s3K[1];
    s3gVarst->lfsrS[4] = s3K[0];
    s3gVarst->lfsrS[3] = s3K[3] ^ 0xffffffff;
    s3gVarst->lfsrS[2] = s3K[2] ^ 0xffffffff;
    s3gVarst->lfsrS[1] = s3K[1] ^ 0xffffffff;
    s3gVarst->lfsrS[0] = s3K[0] ^ 0xffffffff;
    for( i = 0; i < 32; i++)
    {
        fsmWrd = Snow3gClkFsm(s3gVarst,data,length);
        Snow3gClkLFSRinitmd ( fsmWrd, s3gVarst );
    }
}

/*
 * @brief To Generate Keystream by SNOW3G Algorithm
 *
 * This function used to Generate Keystream that has to be XORed w/ input msg
 *
 * Invoked by Snow3gInt()/Snow3gCip
 *
 * 3GPP TS 38.323 (Rel 15 Ver : 15.2.0)
 * Procedure :
 *
 * @param n        :number of 32-bit words of keystream
 * @param ks       :pointer to Keystream
 * @param s3gVarst :Pointer to Snow3g Variable Structure
 */
static void Snow3gGenKs ( uint32_t n, uint32_t *ks,
                              Snow3gVarsP s3gVarst,uint8_t * data,uint32_t length)
{
    uint32_t t = 0;
    uint32_t fsmWrd = 0x0;
    Snow3gClkFsm(s3gVarst,data,length);                             // Clock FSM once. Discard the output. 
    Snow3gClkLFSRKStrmmd(s3gVarst,data,length);                     // Clock LFSR in keystream mode once. 

    for ( t = 0; t < n; t++)
    {
        fsmWrd = Snow3gClkFsm ( s3gVarst ,data,length);
        
        ks[t] = fsmWrd ^ s3gVarst->lfsrS[0];

        Snow3gClkLFSRKStrmmd ( s3gVarst ,data,length);
    }
}

/*
 * @brief Function to fill S-BOX R Variable
 *
 * @param Snow3gVarsP :Pointer to Snow3g Variable Structure
 */
static void Snow3gFillSboxR ( Snow3gVarsP s3gVarst)
{
    /* Rijndael S-box sBoxR */
    u_char sBoxR[S3G_SBOX_SZ] = {
                        0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30,
                        0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76, 0xCA, 0x82,
                        0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2,
                        0xAF, 0x9C, 0xA4, 0x72, 0xC0, 0xB7, 0xFD, 0x93, 0x26,
                        0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71,
                        0xD8, 0x31, 0x15, 0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96,
                        0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2,
                        0x75, 0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0,
                        0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84, 0x53,
                        0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB,
                        0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF, 0xD0, 0xEF, 0xAA,
                        0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F,
                        0x50, 0x3C, 0x9F, 0xA8, 0x51, 0xA3, 0x40, 0x8F, 0x92,
                        0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF,
                        0xF3, 0xD2, 0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44,
                        0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
                        0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46,
                        0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB, 0xE0, 0x32,
                        0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC,
                        0x62, 0x91, 0x95, 0xE4, 0x79, 0xE7, 0xC8, 0x37, 0x6D,
                        0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65,
                        0x7A, 0xAE, 0x08, 0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6,
                        0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B,
                        0x8A, 0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E,
                        0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E, 0xE1,
                        0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E,
                        0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF, 0x8C, 0xA1, 0x89,
                        0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F,
                        0xB0, 0x54, 0xBB, 0x16
                        };
    memcpy ( &s3gVarst->sBoxR, sBoxR, sizeof(sBoxR) );
}

/*
 * @brief Function to fill S-BOX Q Variable
 *
 * @param Snow3gVarsP :Pointer to Snow3g Variable Structure
 */
static void Snow3gFillSboxQ ( Snow3gVarsP s3gVarst)
{
    /* Rijndael S-box sBoxQ */
    u_char sBoxQ[S3G_SBOX_SZ] = {
                        0x25, 0x24, 0x73, 0x67, 0xD7, 0xAE, 0x5C, 0x30, 0xA4,
                        0xEE, 0x6E, 0xCB, 0x7D, 0xB5, 0x82, 0xDB, 0xE4, 0x8E,
                        0x48, 0x49, 0x4F, 0x5D, 0x6A, 0x78, 0x70, 0x88, 0xE8,
                        0x5F, 0x5E, 0x84, 0x65, 0xE2, 0xD8, 0xE9, 0xCC, 0xED,
                        0x40, 0x2F, 0x11, 0x28, 0x57, 0xD2, 0xAC, 0xE3, 0x4A,
                        0x15, 0x1B, 0xB9, 0xB2, 0x80, 0x85, 0xA6, 0x2E, 0x02,
                        0x47, 0x29, 0x07, 0x4B, 0x0E, 0xC1, 0x51, 0xAA, 0x89,
                        0xD4, 0xCA, 0x01, 0x46, 0xB3, 0xEF, 0xDD, 0x44, 0x7B,
                        0xC2, 0x7F, 0xBE, 0xC3, 0x9F, 0x20, 0x4C, 0x64, 0x83,
                        0xA2, 0x68, 0x42, 0x13, 0xB4, 0x41, 0xCD, 0xBA, 0xC6,
                        0xBB, 0x6D, 0x4D, 0x71, 0x21, 0xF4, 0x8D, 0xB0, 0xE5,
                        0x93, 0xFE, 0x8F, 0xE6, 0xCF, 0x43, 0x45, 0x31, 0x22,
                        0x37, 0x36, 0x96, 0xFA, 0xBC, 0x0F, 0x08, 0x52, 0x1D,
                        0x55, 0x1A, 0xC5, 0x4E, 0x23, 0x69, 0x7A, 0x92, 0xFF,
                        0x5B, 0x5A, 0xEB, 0x9A, 0x1C, 0xA9, 0xD1, 0x7E, 0x0D,
                        0xFC, 0x50, 0x8A, 0xB6, 0x62, 0xF5, 0x0A, 0xF8, 0xDC,
                        0x03, 0x3C, 0x0C, 0x39, 0xF1, 0xB8, 0xF3, 0x3D, 0xF2,
                        0xD5, 0x97, 0x66, 0x81, 0x32, 0xA0, 0x00, 0x06, 0xCE,
                        0xF6, 0xEA, 0xB7, 0x17, 0xF7, 0x8C, 0x79, 0xD6, 0xA7,
                        0xBF, 0x8B, 0x3F, 0x1F, 0x53, 0x63, 0x75, 0x35, 0x2C,
                        0x60, 0xFD, 0x27, 0xD3, 0x94, 0xA5, 0x7C, 0xA1, 0x05,
                        0x58, 0x2D, 0xBD, 0xD9, 0xC7, 0xAF, 0x6B, 0x54, 0x0B,
                        0xE0, 0x38, 0x04, 0xC8, 0x9D, 0xE7, 0x14, 0xB1, 0x87,
                        0x9C, 0xDF, 0x6F, 0xF9, 0xDA, 0x2A, 0xC4, 0x59, 0x16,
                        0x74, 0x91, 0xAB, 0x26, 0x61, 0x76, 0x34, 0x2B, 0xAD,
                        0x99, 0xFB, 0x72, 0xEC, 0x33, 0x12, 0xDE, 0x98, 0x3B,
                        0xC0, 0x9B, 0x3E, 0x18, 0x10, 0x3A, 0x56, 0xE1, 0x77,
                        0xC9, 0x1E, 0x9E, 0x95, 0xA3, 0x90, 0x19, 0xA8, 0x6C,
                        0x09, 0xD0, 0xF0, 0x86
                        };
    memcpy(&s3gVarst->sBoxQ,sBoxQ,sizeof(sBoxQ));
}

/*
 * @brief Function to fill SNOW3G Variables used in functions
 *
 * @param Snow3gVarsP :Pointer to Snow3g Variable Structure
 */
static void Snow3gFillVars ( Snow3gVarsP s3gVarst)
{
    memset ( &s3gVarst->lfsrS, 0, sizeof(s3gVarst->lfsrS) );
    memset ( &s3gVarst->fsmR, 0, sizeof(s3gVarst->fsmR) );
    Snow3gFillSboxR ( s3gVarst );
    Snow3gFillSboxQ ( s3gVarst );
}

/*
 * @brief Main function Implementing Snowg algorithm
 *
 * @param s3gKey[4]  :Four 32-bit words making up 128-bit key or Algorithm.
 * @param initVec[4] :Four 32-bit words making 128-bit initialization variable
 * @param numWords   :number of 32 bit words in keystream
 * @param keyStr     :Pointer to the Key Stream
 */
void Snow3gMain ( uint32_t s3gKey[4], uint32_t initVec[4],
                   uint32_t numWords, uint32_t *keyStr , uint8_t *data, uint32_t length )
 {  
 
    Snow3gVarsT s3gVarst;
    Snow3gFillVars ( &s3gVarst );
    Snow3gInit ( s3gKey, initVec, &s3gVarst ,data,length);
    Snow3gGenKs ( numWords, keyStr, &s3gVarst, data, length );
    
}

/* SNOW3G Cipheiring/Deciphering starts */
/*
 * @brief to perform SNOW3G Cipheiring/Deciphering
 *
 * This function is used to perform SNOW3G Cipheiring/Deciphering
 *
 * Invoked by CiphDciph()
 *
 * 3GPP TS 38.323 (Rel 15 Ver : 15.2.0)
 * Procedure :
 *
 * @param key     :12 bit Ciphering key
 * @param mCnt    :32 bit count of the PDU
 * @param rbId    :32 bit Radio Bearer ID
 * @param dir     :Uplink/dolink
 * @param plnMsg  :Input Data Pointer
 * @param cipMsg  :Output Cipher Text Pointer
 * @param lenBits :Length of the input Data in Bits
 */
void Snow3gCiph ( u_char *key, uint32_t mCnt, uint32_t rbId, uint32_t dir,
                u_char *plnMsg,u_char *cipMsg, uint32_t lenBits)
{
    uint32_t wordK[4];
    uint32_t initVec[4];
    uint32_t n = ( lenBits + 31 ) / 32;
    uint32_t lastbits = ( 8-( lenBits%8 ) ) % 8;
    uint32_t *keyStr;
    /* Initialisation */
    for (uint32_t i = 0; i < 4; i++)
    {
         wordK[3-i] = ( key[4*i] << 24) ^ (key[4*i+1] << 16)
                        ^ (key[4*i+2] << 8) ^ (key[4*i+3] );
    }
    initVec[3] = mCnt;
    initVec[2] = ( rbId << 27 ) | ( ( dir & 0x1 ) << 26);
    initVec[1] = initVec[3];
    initVec[0] = initVec[2];
    keyStr = ( uint32_t *) malloc(sizeof(uint32_t)*n);
    /* Run SNOW 3G algorithm to generate sequence of key stream bits keyStr*/
    Snow3gMain( wordK, initVec, n, keyStr, plnMsg,lenBits/8);
    /*
     * Exclusive-OR the input data with keystream to generate the output bit
     * stream
     */
    for ( uint32_t i=0; i < n; i++ )
    {
        cipMsg[4*i+0] = (plnMsg[4*i+0]^(u_char) (keyStr[i] >> 24)) & 0xff;
        cipMsg[4*i+1] = (plnMsg[4*i+1]^(u_char) (keyStr[i] >> 16)) & 0xff;
        cipMsg[4*i+2] = (plnMsg[4*i+2]^(u_char) (keyStr[i] >> 8))& 0xff;
        cipMsg[4*i+3] = (plnMsg[4*i+3]^(u_char) (keyStr[i] )) & 0xff;
    }
    free ( keyStr );
    /*
     * In case length of data is not word-aligned,zero bits have to be
     * added at last
     */
    if ( lastbits )
    {
        cipMsg [ lenBits/8 ] &= 256 - (1<<lastbits);
    }
}
/* SNOW3G Cipheiring/Deciphering ends */


/* SNOW3G Integrity protection starts */
/*
 * @brief to multiply two 64 bit i/ps and return a 64 bit o/p(used by NIA1)
 *
 * Invoked by Mul64xPOW()
 *
 *
 * @param mulOpV :64 bit input
 * @param c      :64 bit input
 * @returns      :64 bit output
 */ 
static uint64_t Mul64x ( uint64_t mulOpV, uint64_t c)
{
    if ( mulOpV & 0x8000000000000000 )
    {
            return (mulOpV << 1) ^ c;
    }
    else
    {
        return mulOpV << 1;
    }
}


/*
 * @brief To multiply a 64 bit input by power of 2 based on ips(used by NIA1)
 *
 * Invoked by Mul64()
 *
 *
 * @param mulOpV :64 bit input
 * @param i      :positive integer- power
 * @param c      :64 bit input
 * @returns      :64 bit output
 */
static uint64_t Mul64xPOW ( uint64_t mulOpV, u_char i, uint64_t c)
{
    if ( i == 0)
    {
        return mulOpV;
    }
    else
    {
        return Mul64x ( Mul64xPOW ( mulOpV, i-1, c ) , c);
    }
}


/*
 * @brief Funtion used for multiplication of mulOpV by init(used by NIA1)
 *
 * Invoked by Snow3gIntg()
 *
 *
 * @param mulOpV :64 bit input
 * @param initP  :64 bit input
 * @param c      :64 bit input
 * @returns      :64 bit output
 */
static uint64_t Mul64 ( uint64_t mulOpV, uint64_t initP, uint64_t c)
{
    uint64_t result = 0;
    int i = 0;
    for ( i = 0; i < 64; i++)
    {
        if( ( initP>>i ) & 0x1 )
        {
            result ^= Mul64xPOW( mulOpV, i, c );
        }
    }
    return result;
}

/*
 * @brief to produce a maskbyte based on required no of bits(used by NIA1)
 *
 * Invoked by Snow3gIntg()
 *
 *
 * @param n :positive integer
 */
static u_char Mask8bit ( int n)
{
    return 0xFF ^ ( ( 1<<( 8-n ) ) - 1);
}


/*
 * @brief to perform SNOW3G integrity protection
 *
 * This function is used to perform ZUC integrity protection
 *
 * Invoked by IntegProt()
 *
 * 3GPP TS 38.323 (Rel 15 Ver : 15.2.0)
 * Procedure :
 *
 * @param intKey  :128 bitIntegrity Protection key
 * @param mCnt    :32 bit count of the PDU
 * @param fresh   :32 bit Random input Number
 * @param dir     :Uplink/dolink
 * @param length  :Length of the input Data in Bits
 * @param plnMsg  :Input Data Pointer
 * @param macI    :32 bit MAC-I value generated
 * @returns void
 */
uint32_t Snow3gIntg ( u_char* key, uint32_t mCnt, uint32_t fresh,
                        uint32_t dir, u_char *plnMsg, uint64_t lenBits )
{
    uint32_t wordK[4],initVec[4], z[5];
    uint32_t i=0;
    static u_char macI[4] = { 0,0,0,0 }; /* static memory for the result */
    uint64_t longLen;
    uint64_t rsltEval;
    uint64_t mulOpV;
    uint64_t initP;
    uint64_t initQ;
    uint64_t c;
    uint32_t omacI;
    uint64_t remBitsMD2;
    int32_t rem_bits = 0;

    /* Load the Integrity Key for SNOW3G initialization as in section 4.4. */
    for ( i = 0; i < 4; i++)
    {
        wordK[3-i] = (key[4*i] << 24) ^ (key[4*i+1] << 16) ^
        (key[4*i+2] << 8) ^ (key[4*i+3]);
    }
    /*
     * Prepare the Initialization Vector (initVec) for SNOW3G initialization
     */
    initVec[3] = mCnt;
    initVec[2] = fresh;
    initVec[1] = mCnt ^ ( dir << 31 ) ;
    initVec[0] = fresh ^ (dir << 15);
    z[0] = z[1] = z[2] = z[3] = z[4] = 0;

    /* Run SNOW 3G to produce 5 keystream words z_1, z_2, z_3, z_4 and z_5. */
    Snow3gMain( wordK, initVec, 5, z,plnMsg,lenBits/8);
    initP = (uint64_t) z[0] << 32 | (uint64_t)z[1];
    initQ = (uint64_t) z[2] << 32 | (uint64_t)z[3];

    /* Calculation */
    if ((lenBits % 64) == 0)
    {
        longLen = (lenBits>>6) + 1;
    }
    else
    {
        longLen = (lenBits>>6) + 2;
    }
    rsltEval = 0;
    c = 0x1b;
    for ( i = 0; i < longLen-2 ; i++)
    {
        mulOpV = rsltEval ^ ((uint64_t)plnMsg[8*i]<<56 |
        (uint64_t)plnMsg[8*i+1]<<48|
        (uint64_t)plnMsg[8*i+2]<<40 | (uint64_t)plnMsg[8*i+3]<<32|
        (uint64_t)plnMsg[8*i+4]<<24 | (uint64_t)plnMsg[8*i+5]<<16|
        (uint64_t)plnMsg[8*i+6]<< 8 | (uint64_t)plnMsg[8*i+7] );
        rsltEval = Mul64(mulOpV,initP,c);
    }

    /* for longLen-2 */
    rem_bits = lenBits % 64;
    if (rem_bits == 0)
    {
        rem_bits = 64;
    }
    remBitsMD2 = 0;
    i = 0;
    while (rem_bits > 7)
    {
        remBitsMD2 |= (uint64_t)plnMsg[8*(longLen-2)+i] << (8*(7-i));
        rem_bits -= 8;
        i++;
    }
    if (rem_bits > 0)
    {
        remBitsMD2 |= (uint64_t)(plnMsg[8*(longLen-2)+i] & Mask8bit(rem_bits)) << (8*(7-i));
    }
    mulOpV = rsltEval ^ remBitsMD2;
    rsltEval = Mul64(mulOpV,initP,c);

    /* for longLen-1 */
    rsltEval ^= lenBits;

    /* Multiply by initQ */
    rsltEval = Mul64(rsltEval,initQ,c);

    /*
     * XOR with z_5
     */
    for ( i = 0 ; i < 4 ; i++)
    {   
        /*
         * macI[i] = (mac32 >> (8*(3-i))) & 0xff;
         */
        macI[i] = ( ( rsltEval >> (56-(i*8) ) ) ^ ( z[4] >> (24-(i*8) ) ) ) & 0xff;
    }
    omacI = macI[0];
    omacI = omacI<<8|macI[1];
    omacI = omacI<<8|macI[2];
    omacI = omacI<<8|macI[3];
    return omacI;
}

/* EOF */