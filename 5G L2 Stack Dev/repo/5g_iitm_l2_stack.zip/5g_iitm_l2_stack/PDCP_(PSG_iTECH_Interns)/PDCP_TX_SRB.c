/*
	Date 		:	25-09-2019
	Version		:	2.0
	Authors		:	Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
	Includes	:	Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
	5G Testbed interns
*/

#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include "PDCP_Config.h"
#include "PDCP_base.h"

/*---------------------------Define Constant Varibles--------------------*/

// ROHC_BUFFER_SIZE can be found in PDCP_Config.h

/* Number of bits of Sequence Number (SN) for each DRB - used in shift operations */
#define SN_SIZE_SRB 4

/* 
	Sequence Number Mod value (used to assign SN) - [SN = TX_NEXT % SN_MOD_DRB]  (because 1<<12 = 2^12) 
	This value is also the total number of Sequence numbers (max value of range)		
*/
#define SN_MOD_SRB (1<<SN_SIZE_SRB)

extern uint32_t tx_next; // tx_next starts from 0 and keeps getting incremented throughout the transmission process.

// uint32_t tx_buff[] = {0, 1, 2, 3, 4, 4, 6, 7, 5, 8, 9, 10, 11, 12, 14, 13, 15, 16, 17, 19, 18, 15};
// int i=0;

extern PDCP_Config_t pdcp_config_params;
extern Security_Config_t security_config_params;


void tx_SRB(uint8_t *sdu_packet_pointer, size_t sdu_packet_len,uint8_t **pdu_packet_pointer, size_t *pdu_packet_len)//,uint16_t tx_SN, PDCP_Config_t pdcp_config_params),Security_Config_t security_config_params),bool SDAP_Header,int SRB_type,bool integrity_protection,bool ciphering_disabled,int integrity_algorithm,int cipher_algorithm,uint32_t bearer,uint32_t dir,uint32_t count,uint8_t * key)
{
    uint8_t* temp;
	uint16_t temp_SN;
	uint32_t MAC_I; 

	PDU_data_SRB_t *pdcp_sdu = PDU_data_SRB_t_init();     // initialisation of pointer for transmission purposes

	// tx_next = tx_buff[i++];
	/*--------------------------COUNT Value and Sequence Numbering----------------------------*/

	uint32_t hfn, sn, count; // Hyper Frame Number and Sequence Number for the PDCP PDU

	/* 
		Assign COUNT value according to TX_NEXT 
		 - Store in buffer during buffer implementation.
		 - Right now, we don't need to store it anywhere since it's only a single SDU.
	*/
	hfn = tx_next / SN_MOD_SRB; 
	sn = tx_next % SN_MOD_SRB;
	count = (hfn << SN_SIZE_SRB) & sn;   // Last 12 bits are SN and first 18 bits are hfn for 12bit SN DRB

	/* Random Sequence is assigned to headers for t-reordering testing purposes 
		Should be replaced with TX_NEXT incremented values */

	//tx_next = tx_buff[i++];	// assigning tx_next (out-of-order) values - for testing

	/* 
		Assigning sequence number according to tx_next.
		We perform OR with 0x8000 (preexisting = refer "PDCP_base.h") because D/C bit is 1 (for DATA) in DRB 
	*/
	pdcp_sdu->R_SN |= (tx_next % SN_MOD_SRB);   
	++tx_next;											 // increment tx_next value - for real-time implementation

	pdcp_sdu->data = sdu_packet_pointer;
	pdcp_sdu->data_len = sdu_packet_len;

	
	/* Assign sdu length to pdcp_sdu->data_len. */
	pdcp_sdu->data_len = sdu_packet_len;

	/* Assign sdu data to pdcp_sdu->data. */
	pdcp_sdu->data = sdu_packet_pointer;

	/* Add PDU header to SDU. */
	PDU_data_SRB_t_header_op(pdcp_sdu);                     
	
	printf("\nHEADER ADDED!\n\n");
	/*ROHC need not be performed for SRB SDUs*/

	/* For SRB0 Ciphering and Integrity should not be performed */

	/* For SRB1,SRB2,SRB3 Ciphering and Integrity is optional and is determined by upperlayers */

	if(SRB_1==pdcp_config_params.SRB_type || SRB_2==pdcp_config_params.SRB_type || SRB_3==pdcp_config_params.SRB_type){
		/*--------------------INTEGRITY PROTECTION--------------------;*/

		printf("\n--------------------MAC-I GENERATION--------------------\n ");
        if(pdcp_config_params.integrity_protection==true){					//Check if integrity protection is required

			MAC_I= integrity_op(security_config_params.integrity_algorithm,pdcp_sdu->data,pdcp_sdu->data_len,security_config_params.count, security_config_params.bearer, security_config_params.dir,security_config_params.key);

			printf("\n--------------------MAC-I GENERATED SUCCESSFULLY!!--------------------\n");
			printf("\n\nGenerated MAC : %x\n",MAC_I);
		}
		else{
			printf("\n--------------------INTEGRITY PROTECTION DISABLED--------------------\n");
		}

		/*--------------------Ciphering--------------------*/

		if(pdcp_config_params.ciphering_disabled==false){
			printf("\n--------------------ENCRYPTING--------------------\n");
			/**/
			temp_SN = (*(pdcp_sdu->data) << 8) | *(pdcp_sdu->data + 1);
			pdcp_sdu->data_len-=2;
			
			temp=ciphering_op(security_config_params.ciphering_algorithm,pdcp_sdu->data+2,pdcp_sdu->data_len,security_config_params.count, security_config_params.bearer, security_config_params.dir,security_config_params.key);
			 
			/*Adding PDU header to ciphered data */
			temp-=2;
			pdcp_sdu->data=temp;
			pdcp_sdu->data_len+=2;
			*(pdcp_sdu->data) = temp_SN >> 8;
			*(pdcp_sdu->data + 1) = temp_SN & 0xFF;
			printf("\n--------------------ENCRYPTION SUCCESSFULL!!--------------------\n");
		}
		else
		{
    		printf("\n--------------------ENCRYPTION DISABLED--------------------\n");
			}

	}
	/*Appeding MAC-I at the end of the SDU*/
	if(pdcp_config_params.integrity_protection==true){
		pdcp_sdu->data_len+=4;
		*(pdcp_sdu->data + pdcp_sdu->data_len-4)=MAC_I>>24 ;
		*(pdcp_sdu->data + pdcp_sdu->data_len-3)=MAC_I>>16 ;
		*(pdcp_sdu->data + pdcp_sdu->data_len-2)=MAC_I>>8 ;
		*(pdcp_sdu->data + pdcp_sdu->data_len-1)=MAC_I & 0xFF ;
		printf("\n-------MAC ADDED!----------\n");
	}
	/* Assigning the data length and pointer of the processed sdu to the pdu data length and pointer to be used by lower layer */
	*pdu_packet_pointer=pdcp_sdu->data;
	*pdu_packet_len=pdcp_sdu->data_len;


	free(pdcp_sdu);

	return ;
}