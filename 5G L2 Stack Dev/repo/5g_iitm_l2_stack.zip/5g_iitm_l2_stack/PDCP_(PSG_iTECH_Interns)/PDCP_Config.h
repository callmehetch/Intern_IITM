/*
	Date 		:	25-09-2019
	Version		:	2.0
	Authors		:	Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
	Includes	:	Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
	5G Testbed interns
*/

#ifndef _PDCP_CONFIG_H_
#define _PDCP_CONFIG_H_

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

#define ROHC_BUFFER_SIZE 4096		// Data buffer size - holds the packet data [max size (IPv4 packet) = 65535]

typedef enum {SRB=0,DRB}rb_type_t;	/*  For SRB, rb_type=0
											DRB, rb_type=1
							 			*/

typedef enum {SRB_0=0,SRB_1,SRB_2,SRB_3}SRB_type_t;	/*  For SRB0, SRB_type=0
														SRB1, SRB_type=1
														SRB2, SRB_type=2
														SRB3, SRB_type=3
					 								*/


typedef enum {len_12bits=0,len_18bits}PDCP_SN_Size_t;	/*  For DRB 12bit SN, DRB_type=0
														DRB 18bit SN, DRB_type=1
					 								*/

typedef enum {UM_DRB=0,AM_DRB}DRB_type_t;	/*  For DRB 12bit SN, DRB_type=0
														DRB 18bit SN, DRB_type=1
					 								*/

/* Ciphering algorithm type is given by upper layers */
typedef enum {ciphering_SNOW3G=1, ciphering_AES, ciphering_ZUC}ciphering_algorithm_t;   /*	For EEA1 - Snow3G use ciphering_SNOW3G(1)		
																								EEA2 - AES    use ciphering_AES(2)
																								EEA3 - ZUC    use ciphering_ZUC(3)
																	*/
/* Intergrity algorithm type is given by upper layers */
typedef enum {integrity_protection_SNOW3G=1, integrity_protection_AES, integrity_protection_ZUC}integrity_algorithm_t;
																						/*	For EIA1 - Snow3G use integrity_protection_SNOW3G(1)  	
																								EIA2 - AES    use integrity_protection_AES(2)
																								EIA3 - ZUC    use integrity_protection_ZUC(3)
																						*/
typedef enum {notUsed=0,rohc,uplink_only_rohc}headerCompression_t;

typedef struct  headerCompression_rohc
{	uint16_t maxCID;									//max Context ID (defined in ROHC)
	bool profiles[9];									// boolean array of profiles to be enabled for ROHC (refer the ROHC protocol)
	/*
		profiles SEQUENCE 
			{              
				profile0x0001           BOOLEAN, 	 // ROHC_PROFILE_RTP            
				profile0x0002           BOOLEAN,     // ROHC_PROFILE_UDP 
				profile0x0003           BOOLEAN,     // ROHC_PROFILE_ESP
				profile0x0004           BOOLEAN,     // ROHC_PROFILE_IP
				profile0x0006           BOOLEAN,     // ROHC_PROFILE_TCP
				profile0x0101           BOOLEAN,     // ROHCv2_PROFILE_IP_UDP_RTP        
				profile0x0102           BOOLEAN,     // ROHCv2_PROFILE_IP_UDP
				profile0x0103           BOOLEAN,     // ROHCv2_PROFILE_IP_ESP     
				profile0x0104           BOOLEAN      // ROHCv2_PROFILE_IP          
			 }
	*/
	bool drb_ContinueROHC;								//holds if header compression needs to be performed during re-establishment.
}rohc_t;

typedef struct  headerCompression_uplink_only_rohc
{	uint16_t maxCID;									//max Context ID (defined in ROHC)
	bool profile0x0006;									//IP only profile (to be enabled or not) - uplink Only ROHC
	bool drb_ContinueROHC;								//holds if header compression needs to be performed during re-establishment.
}uplink_only_rohc_t;


typedef union Header_Compression_Configuration
{	bool notUsed;
	rohc_t rohc;
	uplink_only_rohc_t uplink_only_rohc;
}header_comp_config_t;


typedef struct PDCP_Configuration
{	bool SDAP_Header;									//holds if SDAP Header present or not.
	rb_type_t rb_type ;									//holds Radio Bearer type (SRB or DRB).
	SRB_type_t SRB_type;								//holds SRB type.
	PDCP_SN_Size_t PDCP_SN_Size;                        //holds DRB SN type(12 bit or 18 bit).
	DRB_type_t DRB_type;								//holds DRB type(AM or UM).
	headerCompression_t headerCompression;              //holds information of which type header compression to be performed.
	header_comp_config_t header_comp_config;			//holds the information required for header compression.
	bool ciphering_disabled;                            //holds information whether to perform ciphering(True) or not(False).
	bool integrity_protection;                          //holds information whether to check for integrity(True) or not(False).
	bool statusReportRequired;							//flag to indaicate whether status report required or not.
	bool outOfOrderDelivery;							//flag whether to enable out of order delivery for UM DRB or not
	double t_reordering;								//time in seconds (threshold time for t-reordering)

}PDCP_Config_t;

typedef struct  Security_Configuration
{	
	ciphering_algorithm_t ciphering_algorithm;          //holds the type of algorithm for ciphering.
	integrity_algorithm_t integrity_algorithm;          //holds the type of algorithm for MAC generation.
	uint32_t bearer;									//holds QOS flow or Mapped flow.
	uint32_t dir;										//holds direction of dataflow(uplink or downlink).
	uint32_t count;										//holds 32 bit Frame dependent input.
	uint8_t key[16];									//holds 128bit key for ciphering and integrity protection
}Security_Config_t;

#endif