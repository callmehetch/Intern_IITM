/*
	Date 		:	25-09-2019
	Version		:	2.0
	Authors		:	Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
	Includes	:	Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
	5G Testbed interns
*/

/*@brief Snow3G header
 *@details This module contains the structures 
 *and pre defined assignments required by the 
 *PDCP_Snow3G module
 */

#include<string.h>

#define S3G_SBOX_SZ 256
#define S3G_LFSR_SZ 16
#define SFT_24 24
#define SFT_16 16
#define SFT_8 8

/*
 * @brief DS for holding SNOW3G Variables used for operation
 */
typedef struct Snow3gVars
{
    uint32_t lfsrS[S3G_LFSR_SZ];
    uint32_t fsmR[3];
    u_char sBoxR[S3G_SBOX_SZ];
    u_char sBoxQ[S3G_SBOX_SZ];
} Snow3gVarsT,
 *Snow3gVarsP;

void Snow3gMain ( uint32_t* k, uint32_t* IV, uint32_t n, uint32_t *z , uint8_t *d, uint32_t l );

/* EOF */