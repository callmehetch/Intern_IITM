/*
	Date 		:	25-09-2019
	Version		:	2.0
	Authors		:	Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
	Includes	:	Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
	5G Testbed interns
*/

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "PDCP_base.h"
#include "ROHC_base.h"

/*---------------------------Define Constant Varibles--------------------*/

// ROHC_BUFFER_SIZE can be found in PDCP_Config.h

/* Number of bits of Sequence Number (SN) for each DRB - used in shift operations */
#define SN_SIZE_DRB12 4

/* 
	Sequence Number Mod value (used to assign SN) - [SN = TX_NEXT % SN_MOD_DRB]  (because 1<<12 = 2^12) 
	This value is also the total number of Sequence numbers (max value of range)		
*/
#define SN_MOD_DRB12 (1<<SN_SIZE_DRB12)

/*-------------------------Global variables Declaration------------------*/

/*------------------------------TX Variables-------------------------------------*/

// Uses the common global variables declared in the "PDCP_Main.c" file

extern uint32_t tx_next; // tx_next starts from 0 and keeps getting incremented throughout the transmission process.

extern uint8_t rohc_buffer[ROHC_BUFFER_SIZE]; 		// buffer to store the compressed ROHC packet

/*---------------------------------------------------------------------------------*/

/* Random Buffer Sequence Numbers - ONLY FOR TESTING */

// 20 samples - in order - !! CHANGE NO_OF_SAMPLES to 20 !!
// uint32_t tx_buff[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19};

// 20 samples - random numbers (to check algorithm anamolies) - !! CHANGE NO_OF_SAMPLES to 20 !!
//uint32_t tx_buff[] = {0,1,3,2,5,6,8,9,11,4,10,7,12,14,13,15,17,18,19,16};
//uint32_t tx_buff[] = {0, 1, 2, 5, 6, 3, 4, 10, 11, 12, 13, 14, 15, 18, 7, 8, 9, 19, 5, 16 };	
//uint32_t tx_buff[] = {4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 10, 11, 12, 13, 14, 15, 19, 5, 16 };	
//uint32_t tx_buff[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20};

// 22 samples - duplicates, etc (similar to real-time data) - !! CHANGE NO_OF_SAMPLES to 22 !!
uint32_t tx_buff[] = {0, 1, 2, 3, 4, 4, 6, 7, 5, 8, 9, 10, 11, 12, 14, 13, 15, 16, 17, 19, 18, 15};
int i=0;

/*-----------------------------------------------------------------------------------*/

extern PDCP_Config_t pdcp_config_params;
extern Security_Config_t security_config_params;


/*---------------------------Function Definitions-------------------------*/

void tx_DRB_12bit(uint8_t *sdu_packet_pointer, size_t sdu_packet_len, uint8_t **pdu_packet_pointer, size_t *pdu_packet_len, struct timespec ts)
{
	uint8_t* temp;
	uint16_t temp_SN;
	uint32_t MAC_I; 
	
	PDU_data_DRB_12bit_SN_t *pdcp_sdu = PDU_data_DRB_12bit_SN_t_init(); //initialisation of pointer for transmission purposes

	/*------------------------Start discardTimer for each PDU---------------------------------*/

	// discardTimer is not configured because buffer implementation is not done

	/*--------------------------COUNT Value and Sequence Numbering----------------------------*/

	uint32_t hfn, sn, count; // Hyper Frame Number and Sequence Number for the PDCP PDU

	/* 
		Assign COUNT value according to TX_NEXT 
		 - Store in buffer during buffer implementation.
		 - Right now, we don't need to store it anywhere since it's only a single SDU.
	*/
	hfn = tx_next / SN_MOD_DRB12; 
	sn = tx_next % SN_MOD_DRB12;
	count = (hfn << SN_SIZE_DRB12) & sn;   // Last 12 bits are SN and first 18 bits are hfn for 12bit SN DRB

	/* Random Sequence is assigned to headers for t-reordering testing purposes 
		Should be replaced with TX_NEXT incremented values */

	//tx_next = tx_buff[i++];	// assigning tx_next (out-of-order) values - for testing

	/* 
		Assigning sequence number according to tx_next.
		We perform OR with 0x8000 (preexisting = refer "PDCP_base.h") because D/C bit is 1 (for DATA) in DRB 
	*/
	pdcp_sdu->DC_R_SN |= (tx_next % SN_MOD_DRB12);   
	++tx_next;											 // increment tx_next value - for real-time implementation

	pdcp_sdu->data = sdu_packet_pointer;
	pdcp_sdu->data_len = sdu_packet_len;
	pdcp_sdu->ts = ts;


	/*-----------------------ROHC, Integrity protection and ciphering------------------------*/

	// Perform ROHC

	memset(rohc_buffer, 0, sizeof(uint8_t)*ROHC_BUFFER_SIZE);	// reset the buffer

	size_t rohc_len;							// Length of the compressed rohc packet.

	
	//	Function to perform ROHC compression using the single compressor created for this PDCP entity.
	if(ROHC_compress(pdcp_sdu->data, pdcp_sdu->data_len, &ts, rohc_buffer, &rohc_len, ROHC_BUFFER_SIZE) == 0)		// compression was successfull.
	{	
		pdcp_sdu->data = rohc_buffer;				// update the object's data field with compressed packet
		pdcp_sdu->data_len = rohc_len;			// update the compressed packet's length
	}
	else
	{
		fprintf(stderr, "\nROHC compression failed. Continuing transmission with uncompressed packet...\n");
	}

	/*------------------------Add header----------------------------------------*/

	PDU_data_DRB_12bit_SN_t_header_op(pdcp_sdu); //add header

	printf("\nHEADER ADDED!\n");
	printf("%lu bytes data: ", pdcp_sdu->data_len);

	// Integrity (MAC-I Generation)

	printf("\n--------------------MAC-I GENERATION--------------------\n ");
    if(pdcp_config_params.integrity_protection==true)
    {
		MAC_I= integrity_op(security_config_params.integrity_algorithm,pdcp_sdu->data,pdcp_sdu->data_len,security_config_params.count, security_config_params.bearer, security_config_params.dir,security_config_params.key);

		printf("\n--------------------MAC-I GENERATED SUCCESSFULLY!!--------------------\n");
		// printf("\n");
		// printf("%d bytes data: ", pdcp_sdu->data_len);
		// for(int i=0; i< pdcp_sdu->data_len; i++)
		// 	printf("%02X", *(pdcp_sdu->data + i));
		printf("\n\nGenerated MAC-I : %x\n",MAC_I);
	}
	else
	{
		printf("\n--------------------INTEGRITY PROTECTION DISABLED--------------------\n");
	}

	// Ciphering

	if(pdcp_config_params.ciphering_disabled==false)
	{
		printf("\n--------------------CIPHERING--------------------\n");

		temp_SN = (*(pdcp_sdu->data) << 8) | *(pdcp_sdu->data + 1);
		pdcp_sdu->data_len-=2;
		temp=ciphering_op(security_config_params.ciphering_algorithm,pdcp_sdu->data+2,pdcp_sdu->data_len,security_config_params.count, security_config_params.bearer, security_config_params.dir,security_config_params.key);
		//printf("\nError in TX\n");
		temp-=2;
		pdcp_sdu->data=temp;
		pdcp_sdu->data_len+=2;
		*(pdcp_sdu->data) = temp_SN >> 8;
		*(pdcp_sdu->data + 1) = temp_SN & 0xFF;
		printf("\n--------------------CIPHERING SUCCESSFULL!!--------------------\n");
	}
	else
	{
		printf("\n--------------------CIPHERING DISABLED--------------------\n");
	}


	if(pdcp_config_params.integrity_protection==true)
	{
		pdcp_sdu->data_len+=4;
		*(pdcp_sdu->data + pdcp_sdu->data_len-4)=MAC_I>>24 ;
		*(pdcp_sdu->data + pdcp_sdu->data_len-3)=MAC_I>>16 ;
		*(pdcp_sdu->data + pdcp_sdu->data_len-2)=MAC_I>>8 ;
		*(pdcp_sdu->data + pdcp_sdu->data_len-1)=MAC_I & 0xFF ;
		printf("\n-------MAC-I ADDED!----------\n");
	}

	// update the pointer
	*pdu_packet_pointer = pdcp_sdu->data;
	*pdu_packet_len = pdcp_sdu->data_len;

	free(pdcp_sdu);
}
