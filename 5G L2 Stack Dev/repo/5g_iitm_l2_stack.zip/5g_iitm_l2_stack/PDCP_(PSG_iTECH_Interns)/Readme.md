---
---
# LAYER - 2   

### PACKET DATA CONVERGENCE PROTOCOL (PDCP)
---
---
# EXECUTION:
* ##### Install the following Libraries:

    * lpcap 
    ```
   $ sudo apt-get install libpcap-dev
    ```
    * rohc
    ```
    $ wget https://rohc-lib.org/download/rohc-latest.tar.xz
    $ tar xvJf rohc-latest.tar.xz 
    $ cd rohc-X.Y.Z                                  # OpenBSD note: use gtar instead of tar
    $ ./configure --prefix=/usr                      # replace X.Y.Z by the release number
    $ make all
    $ sudo make install
   ```  
   * pthread
   ```
   $ apt-get install libpthread-stubs0-dev
   ```
* ##### Install the following Tools:
   * valgrind
   ```
   $ sudo apt-get install valgrind
   ```
# COMPILE:
```
$ gcc -o TX -Wall   $(pkg-config rohc --cflags)   TX.c   $(pkg-config rohc --libs) -lpcap
$ gcc -o RX -Wall   $(pkg-config rohc --cflags)   RX.c   $(pkg-config rohc --libs) -lpcap -lpthread
```
# RUN: 
##### Note: 
This module uses a high amount of memory in the heap. Hence, it crashes due to insufficient heap memory allocation when run under default conditions. Therefore, when it is executed under valgrind, valgrind acts as a layer between the OS and the code, giving the code all the memory it requires.

##### Note: 
Currently, mutex locks haven't been implemented in the RX part of the code (the RX API), and thus, desynchronization can occur between the server and the client (Server puts multiple packets in the buffer, and the client reads all those packets together as a single packet) - which causes data corruption.
However, this can be fixed by implementing mutex lock for the RX API and also synchronizing server tx and client rx operations (synchronization over socket). 

```
$ sudo valgrind --gen-suppressions=all ./TX
$ sudo valgrind --gen-suppressions=all ./RX
```
**The Working flow is designed based on the flow given in [3GPP TS 38.323 version 15.2.0 Release 15](https://www.etsi.org/deliver/etsi_ts/138300_138399/138323/15.02.00_60/ts_138323v150200p.pdf).**

This is a version of the C code developed by interns from `PSGiTech`, Coimbatore
for the L2 PDCP layer.

> NOTE:

* In real time, there are buffers between the layers like PDCP, SDAP, RLC and so on in order to contain the data and send for processing as all layers work simultaneously.
* In this implementation, the layers donot work simultaneously. Every layer works consecutively after the execution of the preceeding layer.
*  Thus, there are no buffer implementations. The data packets directly flow in, is processed and sent out.

---
#### WORK FLOW:

                                             USER PLANE 
                                                 |
                          --------------------------------------------
                          |                                          |
                      DATA PDU                                  CONTROL PDU
                          |                                          |
            -------------------------------                --------------------
            |                             |               |                   |
           SRB                           DRB         STATUS REPORT       INTERSPERSED ROHC 
            |                             |              |                 FEEDBACK
            |---> SRB-0                 ROHC             |---> D/C          |
            |     (No ciphering/     (optional)          |     (1-bit)      |---> D/C
            |     deciphering.            |              |                  |    (1-bit)
            |     No integrity            |              |                  | 
            |     check)                  |              |---> PDU type     |
            |                        Integrity and       | (3-bit)          |---> PDU type
            |---> SRB-1               ciphering          |                  |     (3-bit)
            |    (optional            (optional)         |---> FMC          |
            |    ciphering/               |              | (32-bit)         |---> Interspersed 
            |    deciphering &            |              |                       ROHC feedback
            |    integrity          Header addition      |---> Bitmap       (Variable length)
            |    check)                   |                (optional)
            |                  		      |		         
            |---> SRB-2           ---------------------
            |     (optional       |                   |
            |     ciphering       |--- D/C 1-bit      |--- D/C 1-bit
            |     deciphering     |--- 12-bit SN      |--- 18 bit SN
            |     & integrity     |--- 3 Reserved     |--- 5 Reserved 
            |     check)                  bits                bits
            |                      
            |---> SRB-3
                 (optional
                 ciphering/
                 deciphering &
                 integrity 
                 check)

-------------------------------------------------------------------------------------------------------------
#### FUNCTIONS PERFORMED: 

The PDCP layer supports the following functions:-    
* transfer of data (user plane).
* PDCP API.
* Header compression and decompression using the ROHC protocol.
* Ciphering and deciphering (Encryption/Decryption).
* Integrity check.
* Timer based SDU discard 
* Reordering (t-reordering)
* Duplicate discarding.   

---

#### PDCP DATA PDU FORMAT:
##### 1. FOR SRB:

![alt text](https://www.rfwireless-world.com/images/PDCP-Data-PDU-SRBs-format.jpg)
##### 2. FOR DRB:

###### 12-bit SN:                                               
![alt text](http://www.sharetechnote.com/html/5G/image/38_323_Fig_6_2_2_2_1.png)
 ######  18-bit SN:
  ![alt text](http://www.sharetechnote.com/html/5G/image/38_323_Fig_6_2_2_3_1.png)
#### PDCP CONTROL PDU FORMAT:
##### 1. FOR PDCP STATUS REPORT:                                               
![alt text](http://www.sharetechnote.com/html/5G/image/38_323_Fig_6_2_3_1_1.png)                                                   
##### 2. FOR INTERSPERSED ROHC FEEDBACK:                                               
![alt text](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAX8AAACDCAMAAABSveuDAAAA1VBMVEX////97+P6zKf19fX7+/v/0Kp9dW9sb3DaspGrim+bm5vo29AKDxEAAAD/8ubHooX0x6OykXdJTVDOqIlGOS/vw58yLixiUEKXfGUXEhBJSkvGurHRxbs5LybPz8/s39Tbz8Xa2toeHBvt7e3CwsK1tbXk5OS0qqL159x9fX0pIRu9sqn/+OunnpZdWFNXV1dyXUw/PDmYkIl/eHIoKCiSkpJWUU1rZWC6urqoqKgmHxlQQTUdFxNsWEiNc141KyNkZGSGhoaOhoBGQj8YGBiDaFE2NjadxWfCAAANn0lEQVR4nO2dC3+iOhOH6wWrYlBfBUWpIF6gIiqIsmq1rVK//0d6JyjetemWrnvOyf+3W5UMM+FJmISs2T48UFFRUVFRUd1LjTiZGZFVPBam2X9Bsbc6iVm7T9RMtWcis9Y7idVDq0lklia6gviIqAs1RkR9o50m67afKubUSMzqHlG8Jlkzjd5IrB6e00RmlRaJVUwlaqa6RdRMzVVIt3BsTcZfDZN/+pHEKmT+Dhn/Chn/CuUfiPLfifL/qkj5O0Te7sK/fwf+tdD4O89pAr1nSKzSz2sis75FZFbpE5k5jyRWI++dxOzdGZGYPYfY/+OxTxWvqZ8bgdmvfoPEbPRG4i32PCKoWixWmZCYNRyyC620CZzF/3z+J/JG8/9XRcffY/1x/gLlf6g//fz10CSKFyNbCmiQmbWJ2px4/YHIW/w91PWHUUjrD1RUVFRUVFRUVFRUVFRUVFRUVFRU/17FqX5DodEfPVL9hiZhff9QXaQI9IFIrELWUylPYjYdEHlDZBf6UiYy+19o//5YYAiURVESs1AVLZWJzIp5ErOcSHShhSeexCwbJv/op8L8/7hywJ/EDPgTmPEi2YU+8QTOKP8DM8r/Z0T5H8Sj/I/NKP+dGeX/M6L8D+JR/sdmlP/OjPL/GVH+B/Eo/2Oz8PnzWFH/Qy4HIXLBp+hn/P0zc7s3+KTNRWA/weGNxVd0xn/j5szslP9lszP+F+t0xj93xewm/1jsyurc+fEdf/5VzKBpqYC9l1NMNF8Sp/Ogyjf5J5/gzJdZluGLvossOEP4TKY88MsREqcvGbS47uKiTvkzMzGTQZ158pjjKX8ezBDqfCSPvZ3y5xE2e1ocoz3lz2SnEFMspqInZjf415+FTCW9L6/vvkbfqJx9VXvPX/zI58tFMcvAhWajZVRKpWYvWWYb7zp/JvmyyOfBNsl3BuBiBi54hE9kFiX/roBSBCUFBjvDx6PM1i1zKyWc8e+U8uB/WjpGdsb/CWLlF+L8pLuf8Yda5wfoJMYp/zxKQfXnKHtidp1/zbPSrWevvzN4rwQNUUE3+EMIhuGfSgyTnPFJVAY6ueKchP/UPxOl+A5eicwVi8f8sSMxhRcN4c6IZgvJPLQID43A51OFq24v8ffXQ/PT4559zh/HYsonNT7n76+HDmZHrXmBfw73ktcFKf9GpY83GjQR9Pp4c1J7aPedpp92ml4/c4s/vgwm9ZJkUh/MAuFqMEEaJeOf66QYv8rJY/7ACEEJU57mGP41n+8UX8VOksl2Xl7R4vqocM4fQ+AXr5/yxz8Hn/OHn8nZ/PhizvnD51xSJOZf2/bx90qs0c+sUbrloTd/60ez1r7Z/33+WTEbHeSZQfEk3s38U85m83NU4Df8wcVl/knoclmRz6MPPjtdMMVSks+L2asp6Iz/69NgMJidjiNn/ItF3+x08D7jXwKz4lliOeM/Hwzm05ckKf8W2uyzaXntUabWGHn1/V5VIv4FvsgD/22gIN5N/kiEIQqy/pZ/5jL/aHTwwZQGTP6Fh/QwS/r/IIUWX+BfHMxR53S2eYk/mJ226yX+MzQ7Gcwv8i+iOX9qdoP/pqSlttcjeK3v8z8J/9SUz84gVSAckSls08Mn/FPJQhLs+dP8M5gf8WfyxSQU5J9yEKeYRYMFKHvV8aX8H82/nDbYpfwfTYmpT/kXGMhl2U/581F+/nTWTFf5N3f5p+FsJj7PhPyD8fcDhjlIeDDu5EqvQbxP8z924Y+/fHEGY/AHjLrJpyBVbPt/7nXwxOP2YaKDOQwY+N/7rj/uXOQPPePkBrjIHwawE7KX+EejJXSaWC7wh0FrdlzNG/xj/X77YTP+9t/g43ONsP+Lg1RqURQL0RI+AvPPcpl0/rm1gvlnKlWe4Ssvo3mqXETBSLnlD1QW+JJm5QFQHKCP1PwsTxyAPeU/9cff0usxsov8IQt1jpFd5A/9bPDZ/If3L594/H2oe+vRxJ9/ttDzpC+00+jX9rGrfot/sTOdvg4KTHLg1yBfmnZKhV28W89fxYD/DLvYnJSaTTvzHdstI3ADk768uOgUgRFffp3OrqefC89ffhJLdha3+Zc2A1nn+JnpjL/oN2PquAOcP3/5n5nF8aT35vNX+33tVCa4vGU5/dpDrVJpb0vWZ3uQz9cfcpsK4PWHHOH6Q9CF9usP/oN7lDk2yeU+XqHP5cVgeeAgwgWdrz8EyxnHZmfrDxfNztcfohfMLqw/bF9ObpPb6w+NWPAm7v8MCs7/s70/uP4G14ZzN76lSRbM/mvrb7fjhbH+mdxMdpJlspU4yv8gXijrzzeXe85E+R/Eo+v/x2aU/86M8v8ZUf4H8Sj/YzPKf2dG+f+MKP+DeJT/sRnlvzOj/H9G/xn+JPtt/t79R7lQ9x9l//j+o3ySQClEYhWyZh9EZk9lEquCSHahrwUis7D4N7wM1deFwvv/Vw2ZpfqiZC08/hJH9VV1q2Hyj1B9URzlf1dR/vcV5X9fUf73FeV/X1H+9xXlf19R/vfV38WfC6sFucCfr937gxjcrvx2cDh6tSCMiv5N/HVN2buQv3FRrKb7/kwsQ+YwbsU0JXjhJIPzQ4F/Tjc2pZvg5oWQXLUakaqXYijG71fw0P8t/u3WpHlYHHz9szb5dfY7aL7Pn5MzWuCCG7q/743TEG5ITkGCZVkZVeI4dozWFlopXDex8oucKseZSLU8tboJ1EPWhQvg3F4k0dMvxLCtb/SQvZsb/OPvyLGQ82t3IL35/n/sDVle5vQL0GHwV7UgY3THCS5ID/vVquB95GqR/9LVPNaH7BmyLEuCy+mup7Fy1bLkbmKMi1hB6lZRQpEVV2X9egtLfZePDlwB/6EbOY/N2Ss5hBR0i38apduN+hvakd7uf/mFmo165flH+He1ni1YZsRGyI0oCccy9a7muo5U7aljI8KOtZ4zhAs3el4P0kJiuVrppuUkoL9Xx2rP4Dh56LhLdctf6gLChNU1kP+ORTbw99+tJX3cwyh1F98rcg+JCR2C9KALbD1yUs9Z9oD/eKn2IHcpQ8Fx8WFX7VW79krXXffCnREW/7rn7zqK480vzYrz2G4h5O9IbeBNAKP+yXkh8TeRZY+RIgmWpguCPQRiJurZktWze57COoI7zCQiVTSGjxI3RkPTQEvb6cGhnj0WpUjCW7qqs+EvaoqiaGjYHTqbEG6PG6pDUEKVWNXcV1g3PdeQMuAVVbklStjCWGat1XIM3WAIVVo5bGRs2cvMuMs6K3uFdOj/iZXy3TvgBv8m2my2SK8bzczbyOnXKs4kMI71T3/zelj8VbYrI6PbS8BbJRKxBdlEeldRbUU3ZEVdQnZBLO54+tjl4E/XFqssa3DQmyN6L6GgapcL+j/ylZC77mpTt+EqMsz0QGPgnzE2k6DND0HrumPw6rosgoZhkaaJele3gD9kLdmzI4Yc0RMiBzXqyq5kW+6a/f6M7zr/SbD/MdN+68Pt8NjY7/+KPzqnA3BY/Mc6pzsmzv9LEYNaKyZ0Xn2JRMsG/jBsKshYraHIGnNjGz6OkTqGmwUfWrsGYjlO2/IXTcVwepCuEsImBPT/xDii67oi7Pq/vMkhgsmtBOzVhZsLXlVzCI3mj78JfKYLeccSPBUayK+sDYP3j/L/td3/O1m3BZyJ4vv9j+0368L+o9D4y+qG/0phFZblTAFSsiSZLhqyG/7V1RKXyBHMn1WqkCaqwhAf0iWY+uz5S92uJA4j3FH+346/es8fV3XL5gL+Cd8rtC9+jSwtKN6Ov5FxglVdszrM6Al8GivbjmQNf5J/XZ34Xb3/Ft/s/40F/NvWhd/tGTJ/uG4DmbpsDnXMXxI0XR73WMdl5aEgJyxJZxOm3//tNVD3jKEKh5amrA5lpbfN/x7MLWGWqXF6bw1TIWkssHv+0ChLgD1E0pZ/d+lhF7YOQXTJlapIk6sq5B+1qhvIqKoG3DaerqGqLq01GH8N0fjB/A/zn0kj1n5EtYdnoR5rOrXR2t/11ai84V8t/AP8kda1Mf8MsEAJ3UWWgMdflYts3ldZxxEE4Kk4aKV6UmSF84+aWWVWsgLTexFYmkhwBG87//fn9mO4G9gVsiwEVTyY/0eWSIVTTD+4Dm0ORisPztHgOBrLEHPtqJB/HJiGu7rsIAt5iNXhSQEJOsz/OVf47jPAzfn/M3JWCE3wdkcI+QgjwlvbbxerUqk8hj7/gUmIwkkafpU42TR1TrJtPN/z87Rhmyyw1gw4BE+umg3lEQ1igqmt6Rw+pMn4Adc2FNPP6bLp3wasjR98wVcVP/9W/Wc83WRxiWmbQQ6H2ODP/4yPG3hcNmypakSqVQV/xEerLC43cDwJ/sr2dydAnzz/TtItvzg2STfhZ8uf/zT934I+CZ+/PxXZ/eV2azb7tRrF07rBMs5RycHrwaJOsPJzbLUvOlz/OXWxLz96KuOC2Pv437riv2n95/Pasta3M+7fpX8W/0hE+e4D51+mfxr/f1fv/+fx/7eJ8r+vKP/7ivK/ryj/+4ryv68o//uK8r+vKP/7ivK/r0Lk7/WGCaovajgOi/9DK031G2qGhJ+KioqKioqKioqKiorqv616+yFebzzEald+kx/Vz2r9+NBGrd1uBqo/rDbu/7GHWJ32fyoqKioqKioqKqrv6/++irrcReh/bQAAAABJRU5ErkJggg==) 

--------------------------------------------------------------------------------------------------------------
### PROCEDURE:

* In order to generate data packets, packet capturing (pcap) is used.
They capture packets which stimulate working on varying size real time data.

* The captured packets are payload for the PDCP layer.
And the type of radio bearers (DRB/SRB) are recieved from the upper layer.

* ####  ARGUMENTS OBTAINED FROM THE RRC (L2 controller): 
    * *PDCP CONFIG:*
        * `SDAP-header` to hold if SDAP header is present or not.
        * `rb_type`to contain the radio bearer type.
        * `srb_type`to hold the SRB type (SRB-0, SRB-1, SRB-2 or SRB-3).
        * `DRB_SN_type`to hold the DRB-SN type (12-bit or 18-bit).
        * `DRB_type`to hold the DRB type (AM or UM). 
        * `ROHC`to hold information whether to perform header compression(True) or not(False).
        * `drb_ContinueROHC`to hold if header compression needs to be performed during re-establishment.
        * `ciphering_disabled`to contain information whether to perform ciphering(True) or not(False).
        * `integrity_protection`to contain information whether to check for integrity(True) or not(False).
   * SECURITY CONFIG:
        * `ciphering_algorithm`to hold the type of algorithm for ciphering.
        * `integrity_algorithm`to hold the type of algorithm for MAC generation.
        * `bearer`to hold information on if it is QOS flow or Mapped flow.
        * `dir`to contain direction of dataflow(uplink or downlink).
        * `count`to contain a 32 bit Frame dependent input.
	    * `key` contains 128-bit main key for ciphering and integrity check.
   * HEADER CONFIG:
        * `notUsed `if true then, No header compression and vise versa.
        * `rohc`                               
        * `uplink_only_rohc`
###### NOTE: 

* headerCompression_rohc
   
   `maxCID`                                    Maximun Context ID.
   `profiles[9]`                               boolean array of proflies to be enabled (reference : https://www.etsi.org/deliver/etsi_ts/138300_138399/138331/15.03.00_60/ts_138331v150300p.pdf) 
   `drb_ContinueROHC`                          holds if header compression needs to be performed during re-establishment.


* headerCompression_uplink_only_rohc
  
  `maxCID`                           Maximun Context ID.
  `profile0x0006`                    profile to be enabled.
  `drb_ContinueROHC`			     holds if header compression needs to be performed during re-establishment.


* All the above mentioned parameters are obtained from the above layer.

* #### ESTABLISHMENT PART:
   Transmitter (TX) and Reciever (RX)
   When upper layers request a PDCP entity establishment for a radio bearer, the UE shall establish a PDCP entity for the radio bearer, set the state variables of the PDCP entity to initial values, and follow the procedures as in [ETSI TS 138 323 V15.2.0  (5.1-5.6)](https://www.etsi.org/deliver/etsi_ts/138300_138399/138323/15.02.00_60/ts_138323v150200p.pdf).

* #### DATA TRANSFER PART
#### Transmitter End:         
     Recieved from upper layer (SDAP). 
     
     Sequence number generation.        
                                       
     PDCP Header addition.             
     
     IPv4 header compression (ROHC).
     
     Integrity check (Generation of MAC-I). 
     
     Ciphering.
     
     Sent to lower layer (RLC).
     
#### Reciever End:
     Recieved from lower layer (RLC).
     
     t-reordering.
     
     IPv4 header decompression.
     
     Deciphering.
     
     Integrity check (Generation of XMAC). 
     
     Sent to upper layer (SDAP).

* In case of DRB, header compression, Ciphering/Deciphering and Integrity check are optional.
   In case of SRB, no header compression is performed and Ciphering/Deciphering, Integrity check are optional.

* For Integrity check, both MAC-I and XMAC generated are compared.
   If they are similar, then Integrity is verified.
   Else the data is corrupted.
   MAC-I is generated before ciphering the payload.
   XMAC is generated after deciphering the data.
---
### ROBUST HEADER COMPRESSION (ROHC)

* It is a standard method for compressing IP, UDP, TCP headers of internet packets.
* Overhead for IPv4 = 40 bytes.
* Overhead for IPv6 = 60 bytes.
* ROHC compresses the overhead of 40 or 60 bytes to approximately 1 or 3 bytes.
* The first set of compressed packets are larger in size than the consequently compressed packets due to the presence of redundant information.
* The consequent header compressed packets donot contain redundant information. Thus, they are comparitively smaller in size.
   For better compression, the packets are classified into streams before compressing. 
   This classification takes advantage of inter-packet redundancy.
   Once a stream of packets is classified, suitable compression profile is chosen.
   Compression Profile: defines way to compress different fields in the network headers.
   
* Various compression profiles available are:
    * Uncompressed
    * IP-only
    * UDP/IP
    * UDP-Lite/IP
    * ESP/IP
    * RTP/UDP/IP
    * RTP/UDP-Lite/IP
    * TCP/IP

##### MODES OF OPERATION:
* Unidirectional mode (U-mode)
* Bidirectional Optimistic mode (O-mode)
* Bidirectional Reliable mode (R-mode)

COMPRESSOR/DECOMPRESSOR STATES:
           
> COMPRESSOR STATES

* Initialization and Refresh (IR) state
* First Order (FO) state
* Second Order (SO) state

>  DECOMPRESSOR STATES    

* No Context State
* Static Context State
* Full Context State

`@ref:` [ROHC-Wiki](https://en.wikipedia.org/wiki/Robust_Header_Compression)
###### ADAVNTAGE OF ROHC OVER OTHER COMPRESSION TECHNIQUES:

_Packet loss rate is minimal._

---
### REORDERING:

* Reordering is done based on Sequence Numbering.
* COUNT [HFN,SN] value is determined for the incoming packets based on window size. (Similar to Sliding Window protocol)
 
   * COUNT: 
      The count value is composed of HFN and PDCP SN.

        | HFN        | PDCP SN          |
        | ------------- |:-------------:|


   * HFN:
      Hyper Frame Number
      The size of HFN part in bits is length of PDCP SN subtracted from 32.
`COUNT = length of PDCP SN + HFN`
`HFN = 32 - length of PDCP SN`
             
* The window size is set at half the size of the available sequence numbers
   (For 12 bit sequence numbers, window size = 2048 and size of available sequence number = 4096).
* t-reordering timer is set up, and based on that, it’s decided whether to wait for the packets or send them to upper layers.
* When t-reordering timer expires, all the available PDUs are sent to upper layers in ascending order of the COUNT value.

###### T-REORDERING:

* If t-Reordering is running, and if RX_DELIV >= RX_REORD,
    * stop and reset t-reordering.

* If t-Reordering is not running (includes the case when t-Reordering is stopped due to actions above), and
   RX_DELIV < RX_NEXT:
   * update RX_REORD to RX_NEXT.
   * start t-Reordering.

* When t-Reordering expires, the receiving PDCP entity shall:
   * deliver to upper layers in ascending order of the associated COUNT value after performing header
     decompression, if not decompressed before.
   * update RX_DELIV to the COUNT value of the first PDCP SDU which has not been delivered to upper layers, with COUNT value >= RX_REORD.
    * if RX_DELIV < RX_NEXT:
        * update RX_REORD to RX_NEXT;
        * start t-Reordering

* When the value of the t-Reordering is reconfigured by upper layers while the t-Reordering is running, the receiving PDCP entity shall:
    * update RX_REORD to RX_NEXT.
    * stop and restart t-Reordering. 

---
### SRB AND DRB: (DATA PDU)
##### SRB:

* In case of SRB, header compression (ROHC) is not necessary.
* There are 4 types of SRB:
   * SRB-0
   * SRB-1
   * SRB-2
   * SRB-3
* For SRB-0, No Integrity check and no Ciphering/Deciphering.
* For SRB-1, SRB-2, SRB-3, Integrity check as well as Ciphering/Deciphering are optional.

##### DRB:
* For DRB, header compression (ROHC) is optional.
* Integrity check as well as Ciphering/Deciphering are optional.
* Then, PDCP header is added.
###### NOTE:
* In control PDU D/C bit = 0
* In data PDU D/C bit = 1
* Status report is only for Acknowledged mode DRB (AM-DRB) and not for unaknowledged mode DRB (UM-DRB).
### CONTROL PDU:

   * Status Report
   * Interspersed ROHC feedback

`The given code is designed only for data PDU and not for control PDU.`
 
---
### TX MODULE:

Included modules:
- PDCP_Main.c

##### DESCRIPTION:

* This module sets all required parameters from upper layer.
* PDCP_tx_establish function establishes PDCP entity.
* PDCP_TX function accepts SDU from upper layer and builds a PDCP PDU to be delivered to the lower layers.

* `@params:`
   PDCP_Config_t      : holds information about SDU.
   Security_Config_t  : holds information about Security parameters.
   sdu_packet_pointer : holds the SDU to be processed.
   sdu_packet_len     : holds SDU length.
   pdu_packet_pointer : holds the processed PDU.
   pdu_packet_len     : holds PDU length.

---
### RX MODULE:

##### Included modules:
- PDCP_Main.c

##### DESCRIPTION:

* This module sets all required parameters from upper layer.
* PDCP_rx_establish function establishes PDCP entity.
* PDCP_RX function accepts PDU from lower layer and delivers PDCP SDU to upper layers.

* `@params:`
   PDCP_Config_t      : holds information about PDU.
   Security_Config_t  : holds information about Security parameters.
   sdu_packet_pointer : holds the processed SDU.
   sdu_packet_len     : holds SDU length.
   pdu_packet_pointer : holds the PDU to be processed.
   pdu_packet_len     : holds PDU length.

---
### PDCP_MAIN MODULE:

Included modules:
- PDCP_Config.h
- PDCP_base.h
- PDCP_Encryption_and_Integrity_Ctrl.c
- PDCP_RX_SRB.c
- PDCP_TX_SRB.c

##### DESCRIPTION:

* This module contains the definition of the function PDCP_tx_establish,PDCP_rx_establish, PDCP_TX and PDCP_RX.
 
---
### PDCP_TX_SRB MODULE:

##### DESCRIPTION: 

* Recieves packets from upper layers and performs sequence numbering, addition of PDU header, MAC-I generation, ciphering and appending of MAC-I.

* `@params`
   temp_SN 		: to store Sequence number.
   MAC_I	        : to store MAC-I recerived from the TX side.
   integrity_algorithm 	: holds type of algorithm to be used for ciphering/deciphering.
   pdcp_sdu->data_len 	: length of sdu packet without pdu header attached.
   pdcp_sdu->data 	: pointer to sdu packet with 2 byte offset(Because only the data part of the SDU is to be ciphered ) .
   bearer		: holds QOS flow or Mapped flow.
   dir  	        : holds direction of dataflow(uplink or downlink).
   count 		: holds 32 bit Frame dependent input.
   key			: holds 128bit key for ciphering and integrity protection.

---
### PDCP_RX_SRB MODULE:

##### DESCRIPTION: 

* Recieves packets from lower layers and performs extraction of PDU header and MAC-I, deciphering, XMAC generation, 
   integrity verification and t-reordering.

* `@params`
   temp_SN 		: to store Sequence number.
   XMAC		        : to store XMAC generated at the RX side.
   MAC_I	        : to store MAC-I recerived from the TX side.
   integrity_algorithm 	: holds type of algorithm to be used for ciphering/deciphering.
   pdcp_sdu->data_len 	: length of sdu packet without pdu header attached.
   pdcp_sdu->data 	: pointer to sdu packet with 2 byte offset(Because only the data part of the SDU is to be ciphered ) .
   bearer		: holds QOS flow or Mapped flow.
   dir  	        : holds direction of dataflow(uplink or downlink).
   count 		: holds 32 bit Frame dependent input.
   key			: holds 128bit key for ciphering and integrity protection.

---
### PDCP_TX_DRB12 MODULE:

##### DESCRIPTION: 

* Recieves packets from upper layers and performs header compression, sequence numbering, addition of PDU header, MAC-I generation, 
   ciphering and appending of MAC-I.

---
### PDCP_RX_DRB12 MODULE:

##### DESCRIPTION: 

* Recieves packets from lower layers and performs header decompression, extraction of PDU header and MAC-I, deciphering, XMAC generation, integrity verification and t-reordering.

---
## NOTE: 
18 bit DRB is not yet implemented. However, it is very similar to 12 bit DRB and an exact replication of the functionalities need to be performed, with just the Sequence number of bits as 18, and the corresponding data PDU structure (structure is already defined and included in code).

### PDCP_TX_DRB18 MODULE:

##### DESCRIPTION: 

* Recieves packets from upper layers and performs header compression, sequence numbering, addition of PDU header, MAC-I generation, ciphering and appending of MAC-I.

---
### PDCP_RX_DRB18 MODULE:

##### DESCRIPTION: 

* Recieves packets from lower layers and performs header decompression, extraction of PDU header and MAC-I, deciphering, XMAC generation, integrity verification and t-reordering.
---
### CIPHERING_DECIPHERING_INTEGRITY_CTRL MODULE:

##### Included modules:
- PDCP_Snow3G.c
- PDCP_AES.c
- PDCP_ZUC.c

##### DESCRIPTION:

* This module contains the function definition of ciphering_op and integrity_op.

* ciphering_op:

   `@params:` 
   ciphering_type  : holds the type of algorithm for Ciphering/Deciphering.
   payload         : points to input payload.
   data_length     : length of input payload in bytes.
   bearer          : information about QOS or mapped flow.
   direction       : uplink or downlink.
   count           : 32 bit Frame dependent input.
   key             : 128-bit main key for Ciphering/Deciphering.

   `@details:`
   calls the functions Snow3gCiph or AesCiph or ZucCiph according to the type of algorithm specified.

* integrity_op:
   
   `@params:`
   integrity_type  : holds the type of algorithm for Integrity check.
   payload         : points to input payload.
   data_length     : length of input payload in bytes.
   bearer          : information about QOS or mapped flow.
   direction       : uplink or downlink.
   count           : 32 bit Frame dependent input.
   key             : 128-bit main key for Integrity check.

   `@details:`
   calls the functions Snow3gIntg or AesCmac or ZucIntg according to the type of algorithm specified an stores the 
   value of MAC-I returned by the function.

---
### PDCP_SNOW3G MODULE:

##### Included modules:
- PDCP_Snow3G.h 

The header module (PDCP_Snow3G.h) contains the structures and pre defined assignments required by the PDCP_Snow3G module.

##### DESCRIPTION:

* This module is for performing Ciphering/Deciphering and Integrity check by using Snow3G algorithm.
---
### PDCP_AES MODULE:

##### Included modules:
- PDCP_AES.h 

The header module (PDCP_AES.h) contains the structures and pre defined assignments required by the PDCP_AES module.

##### DESCRIPTION:

* This module is for performing Ciphering/Deciphering and Integrity check by using AES algorithm.
---
### PDCP_ZUC MODULE:

##### Included modules:
- PDCP_ZUC.h 

The header module (PDCP_ZUC.h) contains the structures and pre defined assignments required by the PDCP_ZUC module.

##### DESCRIPTION:

* This module is for performing Ciphering/Deciphering and Integrity check by using ZUC algorithm.
---

