/*
    Date        :   25-09-2019
    Version     :   2.0
    Authors     :   Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
    Includes    :   Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
    5G Testbed interns
*/

#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include "PDCP_Main.c"


//#include "PDCP_Config.h"

/*---------------------------Define Constant Varibles--------------------*/

#define SERVER_ADDRESS "127.0.0.1"
//#define SERVER_ADDRESS "192.168.1.8"
#define PORT_NUMBER 7891

#define BUFFER_SIZE 4096

/*--------------------------------Global Variables-----------------------------*/

bool RX_complete = false;       // Flag that will be set when the receiving is complete (No more packets to receive)

/*
    Flags -
    PDU_available - Flag to notify the L2 Controller (RX) that the pdcp layer has a PDU ready to send to upper layers.
    PDU_read - Flag to notify the PDCP module that the PDU has been read and sent to upper layers, so it can proceed with other functionalities

    are available in "pdcp.c" (Main API File) which is imported here.
*/

uint8_t *pdcp_pdu_ptr;              // Pointer which contains the beginning address of the PDCP PDU (processed packet)
size_t pdu_len;         // Length of the PDCP PDU (header decompressed, deciphered, etc)


/*------------------------------Function Definitions---------------------------*/

// To be run in a seperate thread - Listens to PDCP layer (RX) for packets it has to send to upper layers.
void *read_from_PDCP_buffer(void *vargs)
{
    while( ! RX_complete )
    {
        if(PDU_available)
        {
            uint8_t *pdcp_pdu_buffer = malloc( sizeof(uint8_t) * pdu_len );

            for(int i=0; i<pdu_len; i++)
                pdcp_pdu_buffer[i] = pdcp_pdu_ptr[i];

            // Print packet available in controller
            printf("\nPacket to be sent to upper layer : ");
            for(int i=0; i<pdu_len; i++)
                printf("%02x",pdcp_pdu_buffer[i]);
            printf("\n-----------------------------------------------------------------------------\n");
            
            // Now, a local copy of the packet exists in the Controller. From here, it can again control the flow.
            // Right now, we are only printing it and deallocating the memory

            free(pdcp_pdu_buffer);

            // Indicate to PDCP RX Entity that L2 controller is done with reading from the buffer.
            PDU_read = true;
        }

        // check every 0.001 seconds (persistent check)
        // Implement Mutex or something similar
        sleep(0.01);
    }

    return NULL;
}


void main()
{
	PDCP_Config_t pdcp_config_params;
    Security_Config_t security_config_params;
    pdcp_config_params.SDAP_Header=false;
    pdcp_config_params.rb_type = DRB;
    pdcp_config_params.SRB_type = SRB_1;
    pdcp_config_params.PDCP_SN_Size = len_12bits;
    pdcp_config_params.DRB_type = AM_DRB;
    pdcp_config_params.headerCompression = rohc;            // Code only done for ROHC mode
    pdcp_config_params.header_comp_config.rohc.maxCID = 15;  // max for small CID type

    // This array method doesn't work as of now - IP-Only Profile is enabled by default

    for(int i=0; i<9; i++)
    {
        pdcp_config_params.header_comp_config.rohc.profiles[i] = 0;
    }
    pdcp_config_params.header_comp_config.rohc.profiles[3] = 1;      // enabling only the IP-only profile (profile0x0004)


    pdcp_config_params.header_comp_config.rohc.drb_ContinueROHC = false;

    pdcp_config_params.integrity_protection = true;
    pdcp_config_params.ciphering_disabled = false;

    security_config_params.ciphering_algorithm = ciphering_ZUC;
    security_config_params.integrity_algorithm = integrity_protection_ZUC;
    security_config_params.bearer = 0x00000018;
    security_config_params.dir = 0x00000000;
    security_config_params.count = 0x38a6f056;
    security_config_params.key[0]=0x2B;
    security_config_params.key[1]=0xD6;
    security_config_params.key[2]=0x45;
    security_config_params.key[3]=0x9F;
    security_config_params.key[4]=0x82;
    security_config_params.key[5]=0xC5;
    security_config_params.key[6]=0xB3;
    security_config_params.key[7]=0x00;
    security_config_params.key[8]=0x95;
    security_config_params.key[9]=0x2C;
    security_config_params.key[10]=0x49;
    security_config_params.key[11]=0x10;
    security_config_params.key[12]=0x48;
    security_config_params.key[13]=0x81;
    security_config_params.key[14]=0xFF;
    security_config_params.key[15]=0x48;


    if(pdcp_config_params.headerCompression==rohc){
        pdcp_config_params.header_comp_config.rohc.maxCID=15;
        for(int i=0;i<9;i++){
            pdcp_config_params.header_comp_config.rohc.profiles[i]=true;         
        }  
        pdcp_config_params.header_comp_config.rohc.drb_ContinueROHC=true;     
    }
    else if(pdcp_config_params.headerCompression==uplink_only_rohc){
        pdcp_config_params.header_comp_config.uplink_only_rohc.maxCID=15;
        pdcp_config_params.header_comp_config.uplink_only_rohc.profile0x0006=true;         
        pdcp_config_params.header_comp_config.uplink_only_rohc.drb_ContinueROHC=true;     
    }
    else{
        pdcp_config_params.header_comp_config.notUsed=true;
    }


    int l,i;

    // Used to keep track of the discarded packets
    // Will not be used in final code (only for testing purposes) - Hence, size hardcoded.
    uint32_t discard_buf[100];
    int discard_idx=0; 

    /*client-server connection establishment*/
    int clientSocket;
    int reuse_addr = 1;

    uint8_t buffer[BUFFER_SIZE];

    struct sockaddr_in serverAddr;
    socklen_t addr_size;

    clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    setsockopt(clientSocket, SOL_SOCKET, SO_REUSEADDR, &reuse_addr, sizeof(int));

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT_NUMBER);
    serverAddr.sin_addr.s_addr = inet_addr(SERVER_ADDRESS);
    memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);  

    addr_size = sizeof serverAddr;
    connect(clientSocket, (struct sockaddr *) &serverAddr, addr_size);


    pthread_t pdcp_rx_read_thread;

    int rc;
    pthread_attr_t attr;
    struct sched_param param;

    rc = pthread_attr_init (&attr);
    rc = pthread_attr_getschedparam (&attr, &param);
    (param.sched_priority)++;
    rc = pthread_attr_setschedparam (&attr, &param);

    pthread_create(&pdcp_rx_read_thread, &attr, read_from_PDCP_buffer, NULL);

    PDCP_rx_establish(pdcp_config_params, security_config_params, discard_buf, &discard_idx, &pdcp_pdu_ptr, &pdu_len);

    // Create a UNIX based timestamp instance to store the timestamp of the received package (for ROHC)
    struct timespec ts;

    while((l = recv(clientSocket, buffer, BUFFER_SIZE, 0)))
    {
        //l = recv(clientSocket, buffer, BUFFER_SIZE, 0);  // receiving packets

        // Record the timestamp of the captured packet
        clock_gettime(CLOCK_REALTIME, &ts);

        // print received packet (without reordering)
        printf("\nRECEIVED PACKET : \n");
        for(i=0; i<l; i++)
            printf("%02x",buffer[i]);


        PDCP_rx(buffer, l, ts);
    }

    /* 
        This function is called to release the PDCP entity.
        The PDCP entity will send all the packets it has stored in the buffer to L2 Controller in ascending order of COUNT.
        Thus, the left out packets in t-reordering are handled here.
    */
    pdcp_rx_release();

    /*
        Set the flag when RX loop is done receiving, so that the thread can complete executing.
        It's important to set this flag only AFTER pdcp_rx_release, otherwise the unordered PDUs will not be delivered.
    */
    RX_complete = true;

    // Wait for the thread to complete executing.
    pthread_join(pdcp_rx_read_thread, NULL); 

    // Print out the Discarded packets COUNT numbers (for testing)

    printf("\nDiscarded COUNT values (Number of discarded frames = %d)\n", discard_idx); // printing dbuf for cross checking. not needed finally.
    for (i = 0; i < discard_idx; ++i)
        printf("%08x, ", discard_buf[i]);
    printf("\n");

    close(clientSocket);
    
    return;
}
