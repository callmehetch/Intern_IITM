/*
    Date        :   25-09-2019
    Version     :   2.0
    Authors     :   Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
    Includes    :   Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
    5G Testbed interns
*/

#ifndef _ROHC_BASE_H_
#define _ROHC_BASE_H_

#include <time.h>               /* required by time() */
#include <rohc/rohc_buf.h>      /* for the rohc_buf_*() functions */
#include <rohc/rohc_comp.h>     /* for rohc_comp_*() functions */
#include <rohc/rohc_decomp.h>   /* for rohc_decomp_*() functions */
#include <sys/time.h>           /* for struct timespec (timestamp) */

struct rohc_comp *compressor;  /* the ROHC compressor */
struct rohc_decomp *decompressor;

/*-----------------------Functions to decode the packet--------------------------*/

/* return a random number every time it is called */
static int gen_random_num(const struct rohc_comp *const comp, void *const user_context)
{
   return rand();
}

int rohc_compressor_init(uint16_t max_cid, bool *profiles)
{
    /* initialize the random generator with the current time */
    srand(time(NULL));

    // If compressor instance already exists
    if(compressor)  
    {
        fprintf(stderr, "compressor instance already exists\n");
        /* leave with an error code */
        return 1;
    }

    /*---------------------create a ROHC compressor with default parameters---------------------*/

    // Choose whether LARGE or SMALL CID (Context ID) is required - refer ROHC doumentation

    // LARGE CID - for many contexts (data coming from many sources at the same time)
    // compressor = rohc_comp_new2(ROHC_LARGE_CID, ROHC_LARGE_CID_MAX, gen_random_num, NULL);

    // SMALL CID - only 15 contexts (max) - data coming from limited sources
    compressor = rohc_comp_new2(ROHC_SMALL_CID, ROHC_SMALL_CID_MAX, gen_random_num, NULL);

    /*-----------------------------------------------------------------------------------------*/
    printf("\nCreated compressor\n");
    if(compressor == NULL)
    {
        fprintf(stderr, "failed create the ROHC compressor\n");
        /* leave with an error code */
        return 2;
    }

    /* enable the IP-only compression profile */
    printf("\nEnabled IP-only profile\n");
    if(!rohc_comp_enable_profile(compressor, ROHC_PROFILE_IP))
    {
        fprintf(stderr, "failed to enable the IP-only profile\n");
        /* leave with an error code */
        return 3;
    }


    /* Enable profiles according to pdcp-config array (9 profiles) */  
    // Bug with this (check)

    // rohc_profile_t profiles_arr[] = 
    //                 {
    //                     ROHC_PROFILE_RTP,           
    //                     ROHC_PROFILE_UDP, 
    //                     ROHC_PROFILE_ESP,
    //                     ROHC_PROFILE_IP,
    //                     ROHC_PROFILE_TCP,
    //                     ROHCv2_PROFILE_IP_UDP_RTP,        
    //                     ROHCv2_PROFILE_IP_UDP,
    //                     ROHCv2_PROFILE_IP_ESP,    
    //                     ROHCv2_PROFILE_IP 
    //                 };

    // for(int i=0; i<9; i++)
    //     printf(" %d ",profiles[i]);

    // for(int i=0; i<9; i++)
    // {
    //     if(profiles[i])     // check boolean array for flag
    //     {
    //         printf("inside");
    //         if(!rohc_comp_enable_profile(compressor, profiles_arr[i]))      // enable profile
    //         {
    //             fprintf(stderr, "failed to enable profile %04x\n", profiles_arr[i]);
    //             /* leave with an error code */
    //             return 3;
    //         }
            
    //     }
    // }

    return 0;
}

void rohc_compressor_dest()
{
    if(compressor)
    { 
        //printf("destroy the ROHC compressor\n");
        rohc_comp_free(compressor);
    }
    else
        fprintf(stderr, "compressor instance does not exist");
}

int rohc_decompressor_init(uint16_t max_cid, bool *profiles)
{
    if(decompressor)  
    {
        fprintf(stderr, "decompressor instance already exists\n");
        /* leave with an error code */
        return 1;
    }

    /*---------------------create a ROHC decompressor with default parameters------------------*/

    // Choose whether LARGE or SMALL CID (Context ID) is required - refer ROHC doumentation

    // LARGE CID - for many contexts (data coming from many sources at the same time)
    // decompressor = rohc_decomp_new2(ROHC_LARGE_CID, ROHC_LARGE_CID_MAX, ROHC_U_MODE);

    // SMALL CID - only 15 contexts (max) - data coming from limited sources
    decompressor = rohc_decomp_new2(ROHC_SMALL_CID, ROHC_SMALL_CID_MAX, ROHC_U_MODE);

     /*----------------------------------------------------------------------------------------*/

    printf("\nCreated decompressor\n");
    if(decompressor == NULL)
    {
        fprintf(stderr, "failed create the ROHC decompressor\n");
        /* leave with an error code */
        return 2;
    }

    /* enable the IP-only compression profile */
    printf("\nEnabled IP-only profile\n");
    if(!rohc_decomp_enable_profile(decompressor, ROHC_PROFILE_IP))
    {
        fprintf(stderr, "failed to enable the IP-only profile\n");
        /* leave with an error code */
        return 3;
    }

     /* Enable profiles according to pdcp-config array (9 profiles) */  
    // Bug with this (check)

    // rohc_profile_t profiles_arr[] = 
    //                 {
    //                     ROHC_PROFILE_RTP,           
    //                     ROHC_PROFILE_UDP, 
    //                     ROHC_PROFILE_ESP,
    //                     ROHC_PROFILE_IP,
    //                     ROHC_PROFILE_TCP,
    //                     ROHCv2_PROFILE_IP_UDP_RTP,        
    //                     ROHCv2_PROFILE_IP_UDP,
    //                     ROHCv2_PROFILE_IP_ESP,    
    //                     ROHCv2_PROFILE_IP 
    //                 };


    // for(int i=0; i<9; i++)
    //     printf(" %d ",profiles[i]);

    // for(int i=0; i<9; i++)
    // {
    //     if(profiles[i])     // check boolean array for flag
    //     {
    //         printf("inside");
    //         if(!rohc_comp_enable_profile(compressor, profiles_arr[i]))      // enable profile
    //         {
    //             fprintf(stderr, "failed to enable profile0x%04x\n", profiles_arr[i]);
    //             /* leave with an error code */
    //             return 3;
    //         }
            
    //     }
    // }

    return 0;
}

void rohc_decompressor_dest()
{
    if(decompressor)
    {
        //printf("destroy the ROHC decompressor\n");
        rohc_decomp_free(decompressor);
    }
    else
        fprintf(stderr, "decompressor instance does not exist");
}


/**
* Function to perform ROHC compression using the single compressor created for this PDCP entity.
* @param  ip_buffer       contains the uncompressed packet 
* @param  packet_len      length of uncompressed packet
* @param  ts              timestamp of the captured packet
* @param  rohc_buffer     buffer to store the compressed ROHC packet
* @param  rohc_len        length of the compressed packet
* @param  max_buf_size    maximum buffer length (BUFFER_SIZE)
*/

int ROHC_compress(uint8_t *ip_buffer, size_t packet_len, struct timespec *ts, uint8_t *rohc_buffer, size_t *rohc_len, size_t max_buf_size)
{
    // Create ROHC timestamp for the captured packet
    struct rohc_ts rohc_timestamp;
    rohc_timestamp.sec = ts->tv_sec;
    rohc_timestamp.nsec = ts->tv_nsec;

    /* the packet that will contain the IPv4 packet to compress */
    struct rohc_buf ip_packet = rohc_buf_init_full(ip_buffer, packet_len, rohc_timestamp);

    /* the packet that will contain the resulting ROHC packet */
    struct rohc_buf rohc_packet = rohc_buf_init_empty(rohc_buffer, max_buf_size);

    rohc_status_t rohc_status;

    /* compress the packet */
    rohc_status = rohc_compress4(compressor, ip_packet, &rohc_packet);

    if(rohc_status != ROHC_STATUS_OK)
    {
      fprintf(stderr, "compression of IP packet failed: %s (%d)\n",
              rohc_strerror(rohc_status), rohc_status);
      /* leave with an error code */
      return 1;
    }

    // update the length of the ROHC packet to rohc_len variable
    *rohc_len = rohc_packet.len;

    /* dump the ROHC packet on terminal */
    // printf("\nROHC packet resulting from the ROHC compression:\n");
    // for(size_t i = 0; i < rohc_packet.len; i++)
    // {
    //   printf("%02x", rohc_buf_byte_at(rohc_packet, i));
    // }
    // printf("\n");

    /* leave the program with a success code */
    return 0;
}

int ROHC_decompress(uint8_t *ip_buffer, size_t packet_len, uint8_t *ip_decomp_buffer,
                 size_t *ip_decomp_len, size_t max_buf_size, struct timespec *ts)
{
    // Create ROHC timestamp for the captured packet
    struct rohc_ts rohc_timestamp;
    rohc_timestamp.sec = ts->tv_sec;
    rohc_timestamp.nsec = ts->tv_nsec;

    // create a rohc_buf object for the ip buffer (compressed packet)
    struct rohc_buf rohc_packet = rohc_buf_init_full(ip_buffer, packet_len, rohc_timestamp);
    
    // create a rohc_buf object to store the decompressed packet
    struct rohc_buf ip_decomp_packet = rohc_buf_init_empty(ip_decomp_buffer, max_buf_size);

    /* we do not want to handle feedback right now*/
    struct rohc_buf *rcvd_feedback = NULL;
    struct rohc_buf *feedback_send = NULL;

    rohc_status_t rohc_status;

    rohc_status = rohc_decompress3(decompressor, rohc_packet, &ip_decomp_packet,
                          rcvd_feedback, feedback_send);

    if(rohc_status != ROHC_STATUS_OK)
    {
        fprintf(stderr, "decompression of IP packet failed: %s (%d)\n",
              rohc_strerror(rohc_status), rohc_status);
        /* leave with an error code */
        return 1;
    }

    // update the length of the ROHC packet to rohc_len variable
    *ip_decomp_len = ip_decomp_packet.len;

    /* dump the ROHC packet on terminal */
    // printf("\nIP packet resulting from the ROHC decompression:\n");
    // for(size_t i = 0; i < ip_decomp_packet.len; i++)
    // {
    //   printf("%02x", rohc_buf_byte_at(ip_decomp_packet, i));
    // }
    // printf("\n");

    /* leave the program with a success code */
    return 0;
}

#endif
