
/*
	Date 		:	23-05-2019
	Version		: 	1.0
	Authors 	:	Viknesh, Ganesh, Nanda
	Includes	: 	PDU Data Structures, initializations, Reordering
	5G Testbed summer interns
*/


#include <stdio.h>
#include <stdbool.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include "pcap_packet_fetch.c"
#include "PDCP_Encryption_and_Authentication_Ctrl.c"
#include "ROHC_base.h"
#include "PDCP_Config.h"

/*---------------------------Define Constant Varibles--------------------*/

#define SERVER_ADDRESS "192.168.0.15"
#define PORT_NUMBER 7891

#define SN_MOD_DRB12 (1<<SN_SIZE_DRB12)
#define SN_MOD_DRB18 (1<<SN_SIZE_DRB18)

#define NO_OF_SAMPLES 20 		// Number of packet samples to test with.
#define BUFFER_SIZE 4096		// Data buffer size - holds the packet data [max size (IPv4 packet) = 65535]

/* Number of bits of Sequence Number (SN) for each DRB - used in shift operations */
/* Sequence Number Mod value (used to assign SN) - [SN = TX_NEXT % (1<<SN_SIZE_DRB)]  (because 1<<12 = 2^12) */
//#define SN_SIZE_DRB12 4
//#define SN_SIZE_DRB18 18

#define WINDOW_SIZE_DRB12 (1 << (SN_SIZE_DRB12-1)) // window size = 2^(n-1) = [half of number of seq numbers]
#define WINDOW_SIZE_DRB18 (1 << (SN_SIZE_DRB18-1))  

/*-------------------------Global variables Declaration------------------*/

//captured_packet_info_t* packet_info;
 /* Holds captured packet info - 
					Declared globally because address needs to stay allocated and it's also used in packet fetch */


/*---------------------------Function Definitions-------------------------*/

/* Generates a random sequence of sequence numbers for testing purposes 
	Gives values equivalent to tx_next, not COUNT value */

uint8_t rohc_buffer[BUFFER_SIZE]; 

void operate_on_server_DRB12b(uint8_t *sdu_packet_pointer, size_t sdu_packet_len, uint8_t **pdu_packet_pointer, size_t *pdu_packet_len,,uint16_t tx_SN,PDCP_Config_t pdcp_config_params,Security_Config_t security_config_params,struct timespec ts)
{
	
	PDU_data_DRB_18bit_SN_t *pdcp_sdu = PDU_data_DRB_18bit_SN_t_init(); //initialisation of pointer for transmission purposes

	/*------------------------Start discardTimer for each PDU---------------------------------*/

	// discardTimer is not configured because buffer implementation is not done

	/*--------------------------COUNT Value and Sequence Numbering----------------------------*/

	uint32_t hfn, sn, count; // Hyper Frame Number and Sequence Number for the PDCP PDU

	/* 
		Assign COUNT value according to TX_NEXT 
		 - Store in buffer during buffer implementation.
		 - Right now, we don't need to store it anywhere since it's only a single SDU.
	*/
	hfn = tx_next / SN_MOD_DRB18; 
	sn = tx_next % SN_MOD_DRB18;
	count = (hfn << SN_SIZE_DRB18) & sn;   // Last 12 bits are SN and first 18 bits are hfn for 12bit SN DRB

	/* Random Sequence is assigned to headers for t-reordering testing purposes 
		Should be replaced with TX_NEXT incremented values */

	tx_next = tx_buff[i++];	// assigning tx_next (out-of-order) values - for testing

	/* 
		Assigning sequence number according to tx_next.
		We perform OR with 0x8000 (preexisting = refer "PDCP_base.h") because D/C bit is 1 (for DATA) in DRB 
	*/
	pdcp_sdu->DC_R_SN |= (tx_next % SN_MOD_DRB12);   
	//++tx_next;											 // increment tx_next value - for real-time implementation

	pdcp_sdu->data = sdu_packet_pointer;
	pdcp_sdu->data_len = sdu_packet_len;
	pdcp_sdu->ts = ts;

	printf("%lu bytes data: ", pdcp_sdu->data_len);
	for(int j=0; j< pdcp_sdu->data_len; j++)
		printf("%02x", *(pdcp_sdu->data + j));

	/*-----------------------ROHC, Integrity protection and ciphering------------------------*/

	// Perform ROHC

	memset(rohc_buffer, 0, sizeof(uint8_t)*BUFFER_SIZE);	// reset the buffer

	size_t rohc_len;							// Length of the compressed rohc packet.

	/*
		Function to perform ROHC compression using the single compressor created for this PDCP entity.
		@param 	pdcp_sdu->data 		contains the uncompressed packet 
		@param 	pdcp_sdu->data_len 	length of uncompressed packet
		@param 	ts 				timestamp of the captured packet
		@param 	ROHC_buffer		buffer to store the compressed ROHC packet
		@param 	rohc_len		length of the compressed packet
		@param	max_buf_size	maximum buffer length (BUFFER_SIZE)
	*/
	if(ROHC_compress(pdcp_sdu->data, pdcp_sdu->data_len, &ts, rohc_buffer, &rohc_len, BUFFER_SIZE) == 0)		// compression was successfull.
	{	
		pdcp_sdu->data = rohc_buffer;				// update the object's data field with compressed packet
		pdcp_sdu->data_len = rohc_len;			// update the compressed packet's length
	}
	else
	{
		fprintf(stderr, "\nROHC compression failed. Continuing transmission with uncompressed packet...\n");
	}

	// Integrity protection and ciphering functions to be called here

	/*------------------------Add header and transmit----------------------------------------*/

	printf("\n%lu bytes data: ", pdcp_sdu->data_len);
	for(int j=0; j< pdcp_sdu->data_len; j++)
		printf("%02x", *(pdcp_sdu->data + j));

	printf("\n");
	PDU_data_DRB_18bit_SN_t_header_op(pdcp_sdu); //add header

	printf("\nHEADER ADDED!\n");
	printf("%lu bytes data: ", pdcp_sdu->data_len);
	printf("\n--------------------MAC-I GENERATION--------------------\n ");
            if(pdcp_config_params.integrity_protection==true){
				MAC_I= integrity_op(security_config_params.integrity_algorithm,pdcp_sdu->data,pdcp_sdu->data_len,security_config_params.count, security_config_params.bearer, security_config_params.dir,security_config_params.key);

				printf("\n--------------------MAC-I GENERATED SUCCESSFULLY!!--------------------\n");
				// printf("\n");
				// printf("%d bytes data: ", pdcp_sdu->data_len);
				// for(int i=0; i< pdcp_sdu->data_len; i++)
				// 	printf("%02X", *(pdcp_sdu->data + i));
				printf("\n\nGenerated MAC : %x\n",MAC_I);
			}
			else{
				printf("\n--------------------INTEGRITY PROTECTION DISABLED--------------------\n");
			}

			if(pdcp_config_params.ciphering_disabled==false){
				printf("\n--------------------ENCRYPTING--------------------\n");
				pdcp_sdu->DC_R_SN = *(pdcp_sdu->data);
				temp_SN = (*(pdcp_sdu->data + 1) << 8) | *(pdcp_sdu->data + 2);
				pdcp_sdu->data_len-=3;
				temp=ciphering_op(security_config_params.cipher_algorithm,pdcp_sdu->data+3,pdcp_sdu->data_len,security_config_params.count, security_config_params.bearer, security_config_params.dir,security_config_params.key);
				//printf("\nError in TX\n");
				temp-=3;
				pdcp_sdu->data=temp;
				pdcp_sdu->data_len+=3;
				*(pdcp_sdu->data) = pdcp_sdu->DC_R_SN;
				*(pdcp_sdu->data + 1) = temp_SN >> 8;
				*(pdcp_sdu->data + 2) = temp_SN & 0xFF;
				printf("\n--------------------ENCRYPTION SUCCESSFULL!!--------------------\n");
			}
			else
    		{
        		printf("\n--------------------ENCRYPTION DISABLED--------------------\n");
   			}

		
		/**/
		if(pdcp_config_params.integrity_protection==true){
			pdcp_sdu->data_len+=4;
			*(pdcp_sdu->data + pdcp_sdu->data_len-4)=MAC_I>>24 ;
			*(pdcp_sdu->data + pdcp_sdu->data_len-3)=MAC_I>>16 ;
			*(pdcp_sdu->data + pdcp_sdu->data_len-2)=MAC_I>>8 ;
			*(pdcp_sdu->data + pdcp_sdu->data_len-1)=MAC_I & 0xFF ;
			printf("\n-------MAC ADDED!----------\n");
		}
		// printf("\n-------MAC ADDED!----------\n");
			printf("\n");
			printf("%d bytes data: ", pdcp_sdu->data_len);
			for(int i=0; i< pdcp_sdu->data_len; i++)
				printf("%02X", *(pdcp_sdu->data + i));

	// update the pointer
	*pdu_packet_pointer = pdcp_sdu->data;
	*pdu_packet_len = pdcp_sdu->data_len;

	printf("\n%lu bytes data: ", *pdu_packet_len);
	for(int j=0; j< *(pdu_packet_len); j++)
		printf("%02x", *(*pdu_packet_pointer + j));	
	
	return ;
}
