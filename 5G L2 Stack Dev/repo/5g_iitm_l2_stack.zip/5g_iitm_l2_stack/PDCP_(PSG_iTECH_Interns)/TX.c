/*
    Date        :   25-09-2019
    Version     :   2.0
    Authors     :   Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
    Includes    :   Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
    5G Testbed interns
*/

#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdbool.h>
#include "PDCP_Main.c"
#include "pcap_packet_fetch.c"


/*---------------------------Define Constant Varibles--------------------*/

#define SERVER_ADDRESS "127.0.0.1"
//#define SERVER_ADDRESS "192.168.0.5"
#define PORT_NUMBER 7891
#define NO_OF_SAMPLES 22        // Max value = 2^12 (i.e 4096)

/*-------------------------Global variables Declaration------------------*/

captured_packet_info_t* packet_info; /* Holds captured packet info - 
                    Declared globally because address needs to stay allocated and it's also used in packet fetch */

void main()
{
	PDCP_Config_t pdcp_config_params;
    Security_Config_t security_config_params;
	pdcp_config_params.SDAP_Header=false;
    pdcp_config_params.rb_type = DRB;
	pdcp_config_params.SRB_type = SRB_1;
	pdcp_config_params.PDCP_SN_Size = len_12bits;
	pdcp_config_params.DRB_type = AM_DRB;
    pdcp_config_params.headerCompression = rohc;            // Code only done for ROHC mode
    pdcp_config_params.header_comp_config.rohc.maxCID = 15;  // max for small CID type

    // This array method doesn't work as of now - IP-Only Profile is enabled by default

    for(int i=0; i<9; i++)
    {
        pdcp_config_params.header_comp_config.rohc.profiles[i] = 0;    
    }
    pdcp_config_params.header_comp_config.rohc.profiles[3] = 1;      // enabling only the IP-only profile (profile0x0004)

    pdcp_config_params.header_comp_config.rohc.drb_ContinueROHC = false;


	pdcp_config_params.integrity_protection = true;
	pdcp_config_params.ciphering_disabled = false;

	security_config_params.ciphering_algorithm = ciphering_ZUC;
	security_config_params.integrity_algorithm = integrity_protection_ZUC;
	security_config_params.bearer = 0x00000018;
    security_config_params.dir = 0x00000000;
    security_config_params.count = 0x38a6f056;
    security_config_params.key[0]=0x2B;
    security_config_params.key[1]=0xD6;
    security_config_params.key[2]=0x45;
    security_config_params.key[3]=0x9F;
    security_config_params.key[4]=0x82;
    security_config_params.key[5]=0xC5;
    security_config_params.key[6]=0xB3;
    security_config_params.key[7]=0x00;
    security_config_params.key[8]=0x95;
    security_config_params.key[9]=0x2C;
    security_config_params.key[10]=0x49;
    security_config_params.key[11]=0x10;
    security_config_params.key[12]=0x48;
    security_config_params.key[13]=0x81;
    security_config_params.key[14]=0xFF;
    security_config_params.key[15]=0x48;


    if(pdcp_config_params.headerCompression==rohc){
        pdcp_config_params.header_comp_config.rohc.maxCID=15;
        for(int i=0;i<9;i++){
            pdcp_config_params.header_comp_config.rohc.profiles[i]=true;         
        }  
        pdcp_config_params.header_comp_config.rohc.drb_ContinueROHC=true;     
    }
    else if(pdcp_config_params.headerCompression==uplink_only_rohc){
        pdcp_config_params.header_comp_config.uplink_only_rohc.maxCID=15;
        pdcp_config_params.header_comp_config.uplink_only_rohc.profile0x0006=true;         
        pdcp_config_params.header_comp_config.uplink_only_rohc.drb_ContinueROHC=true;     
    }
    else{
        pdcp_config_params.header_comp_config.notUsed=true;
    }

    /*client-server connection establishment*/
    // /*client-server connection establishment*/
    int welcomeSocket, newSocket;
    struct sockaddr_in serverAddr;
    struct sockaddr_storage serverStorage;
    socklen_t addr_size;

    
    int reuse_addr=1;

    welcomeSocket = socket(PF_INET, SOCK_STREAM, 0);
    setsockopt(welcomeSocket, SOL_SOCKET, SO_REUSEADDR, &reuse_addr, sizeof(int));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT_NUMBER);
    serverAddr.sin_addr.s_addr = inet_addr(SERVER_ADDRESS);
        memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);  
    bind(welcomeSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));
    
    if( listen(welcomeSocket,5) == 0 )
        printf("Listening\n");
    else
        printf("Error\n");
    
    addr_size = sizeof serverStorage;
    newSocket = accept(welcomeSocket, (struct sockaddr *) &serverStorage, &addr_size);

    setsockopt(newSocket, SOL_SOCKET, SO_REUSEADDR, &reuse_addr, sizeof(int));

    // Variables for PDU processing
    uint8_t *sdu_packet_pointer;
    size_t sdu_packet_len;
    uint8_t *pdu_packet_pointer;
    size_t pdu_packet_len;

    // Establish a pdcp entity (Transmisssion)
    PDCP_tx_establish(pdcp_config_params, security_config_params);
    
    printf("\n");

    for (int i = 0; i < NO_OF_SAMPLES; i++)          //Should be replaced with receive function, receive from SDAP
    {
        
        // Create a UNIX timestamp for the captured packet
        struct timespec ts;
        
        /* Used to capture IP Packet from network for simulation using real time data. */
        packet_info = malloc (sizeof(captured_packet_info_t));
       
        // Packet Capturing - should be replaced with the received packet
        /*
             Writes the packet info into "packet_info" pointer and records the timestamp of the captured packet.
            - function can be found in "pcap_packet_fetch.c" 
        */
        capture_packet( &ts ); 
        
        /* Assign captured packet length to sdu->data_len. */
        sdu_packet_len = packet_info->payload_size;
      
        /* Assign captured data to sdu->data. */
        sdu_packet_pointer = packet_info->payload_pointer;

        printf("\nPDCP SDU:%p\n",sdu_packet_pointer );

        for(int j=0; j<sdu_packet_len; j++)
            printf("%02x",sdu_packet_pointer[j]);
        printf("\n");
        

        PDCP_tx(sdu_packet_pointer, sdu_packet_len, &pdu_packet_pointer, &pdu_packet_len, ts);//,pdcp_config_params,security_config_params);

        printf("\nPDCP PDU:%p\n",pdu_packet_pointer );
  
        for(int j=0; j<pdu_packet_len; j++)
            printf("%02x",pdu_packet_pointer[j]);
        printf("\n");
        

        printf("\nSent %ld bytes successfully!\n", send(newSocket,pdu_packet_pointer,pdu_packet_len,0)); // sending packets
        printf("-----------------------------------------\n");
  
        free(packet_info);

        // No need to free the pdcp_pdu pointer because that memory is allocated by pcap function which automatically manages memory.

        // Give time for the receiver to finish processing.
        // Gaps between sending packets.
        // WARNING - Implement mutex or something similar between server and client.
        //sleep(1);

    }

    pdcp_tx_release();
    
    
    close(newSocket);
    close(welcomeSocket);

    return;
}
