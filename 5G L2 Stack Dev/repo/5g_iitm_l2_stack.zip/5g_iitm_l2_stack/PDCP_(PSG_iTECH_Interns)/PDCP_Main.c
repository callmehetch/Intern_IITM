/*
	Date 		:	25-09-2019
	Version		:	2.0
	Authors		:	Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
	Includes	:	Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
	5G Testbed interns
*/

#include "PDCP_Config.h"
#include "PDCP_Encryption_and_Integrity_Ctrl.c"

#include "PDCP_TX_SRB.c"
#include "PDCP_RX_SRB.c"
#include "PDCP_TX_DRB12.c"
#include "PDCP_RX_DRB12.c"
//#include "PDCP_TX_DRB18.c"
//#include "PDCP_RX_DRB18.c"

// ROHC_BUFFER_SIZE can be found in PDCP_Config.h

/*------------------------------------------Global Variables---------------------------------------------*/

/*--------------------------------Global Flags---------------------------------*/

bool PDU_available = false;		// Flag to notify the L2 Controller (RX) that the pdcp layer has a PDU ready to send to upper layers.
bool PDU_read = false;			// Flag to notify the PDCP module that the PDU has been read and sent to upper layers, so it can proceed with other functionalities

/*------------------------------TX Variables-------------------------------------*/

uint32_t tx_next; // tx_next starts from 0 and keeps getting incremented throughout the transmission process.

uint8_t rohc_buffer[ROHC_BUFFER_SIZE]; 		// buffer to store the compressed ROHC packet

/*------------------------------RX Variables------------------------------------*/

// Used to keep track of the discarded packets
// Will not be used in final code (only for testing purposes)
// Pointer passed from RX controller and assigned to this global variable
uint32_t *discard_buf;
int *discard_idx;

/* 
	Reception Buffer (rec_buf) is a double pointer (Array of structure pointers) 
	It contains SN_MOD_DRB12 (number of sequence numbers) pointers, 
	each pointing to a structure (PDU) if received, (or) pointing to NULL if not received. 
*/
PDU_data_DRB_12bit_SN_t **rec_buf_drb12b;
PDU_data_SRB_t **rec_buf_srb;

// Pointer concerning to the PDCP PDU in RX operation
uint8_t **pdcp_pdu;
size_t *pdcp_pdu_len;

// start variable records the time of enitity establshment. 
// It's used as a point of reference while t-reordering.
// It's value is assigned in pdcp_rx_establish() function which establishes the PDCP Receiver Entity
clock_t start; 

/* Initialization of rx_deliv, rx_reord and rx_next */
uint32_t rx_deliv_sn = 0, rx_deliv_hfn = 0, rx_deliv = 0, rx_reord = 0, rx_next = 0;

// rcvd_sn and rcvd_hfn should be able to house values upto 2^20 (HFN is 20 bits, when SN is 12 bits)
// COUNT is always 32 bits
uint32_t rcvd_sn, rcvd_hfn, rcvd_count; 	

bool outOfOrderDelivery = false;

// t-reordering related variables
bool t_reord_running = false;
bool t_reord_reconfig = false;
double t_reord_start_time, t_reord_threshold_time = 0.000192; //t_reord_threshold_time = 0.000064;

/*--------------------------------Config Params----------------------------------------------*/

PDCP_Config_t pdcp_config_params;
Security_Config_t security_config_params;

/*--------------------------------------------------------------------------------------------*/

void PDCP_tx_establish(PDCP_Config_t PDCP_Config_info, Security_Config_t Security_Config_info)
{	
	pdcp_config_params = PDCP_Config_info;
	security_config_params = Security_Config_info;

	// set tx_next to initial value
	tx_next = 0;

	// initialize the compressor instance for the single PDCP Entity
	if(pdcp_config_params.rb_type==DRB){

		for(int i=0; i<9; i++)
    {
        printf(" %d ",PDCP_Config_info.header_comp_config.rohc.profiles[i]);
    }

		rohc_compressor_init(pdcp_config_params.header_comp_config.rohc.maxCID, 
							pdcp_config_params.header_comp_config.rohc.profiles);
	}
}

void PDCP_rx_establish(PDCP_Config_t PDCP_Config_info,Security_Config_t Security_Config_info, 
	uint32_t *d_buf, int *d_idx, uint8_t **pdu, size_t *len)
{
	pdcp_config_params=PDCP_Config_info;
	security_config_params=Security_Config_info;

	start = clock(); // start of PDCP entity (time recorded)

	
	// Assign discard buffer and discard index pointers - Testing only
	discard_buf = d_buf;
	discard_idx = d_idx;

	pdcp_pdu = pdu;
	pdcp_pdu_len = len;

	// initialize all flags
	if(pdcp_config_params.rb_type==SRB){

		rec_buf_srb = (PDU_data_SRB_t**) malloc (SN_MOD_SRB * sizeof(PDU_data_SRB_t*));
		
		for(i = 0; i < SN_MOD_SRB; i++)
		{
			// Initialization - When the pointer is pointing to NULL, it means that particular PDU is not received yet.
			rec_buf_srb[i] = NULL;
		}
	}
	if(pdcp_config_params.rb_type==DRB){

		rohc_decompressor_init(
			pdcp_config_params.header_comp_config.rohc.maxCID, 
							pdcp_config_params.header_comp_config.rohc.profiles);

		rec_buf_drb12b = (PDU_data_DRB_12bit_SN_t**) malloc (SN_MOD_DRB12 * sizeof(PDU_data_DRB_12bit_SN_t*));
	
		for(i = 0; i < SN_MOD_DRB12; i++)
		{
		// Initialization - When the pointer is pointing to NULL, it means that particular PDU is not received yet.
			rec_buf_drb12b[i] = NULL;
		}
	}
}

void PDCP_tx(uint8_t *sdu_packet_pointer, size_t sdu_packet_len,uint8_t **pdu_packet_pointer, size_t *pdu_packet_len, struct timespec ts)//,PDCP_Config_t pdcp_config_params,Security_Config_t security_config_params)
{	
	//operate on SRB
	if(pdcp_config_params.rb_type==SRB)
	{
			
			tx_SRB(
				sdu_packet_pointer,
				sdu_packet_len,
				pdu_packet_pointer,
				pdu_packet_len
				);

	}
	//operate on DRB
	else{
		if(pdcp_config_params.PDCP_SN_Size==len_12bits){
			tx_DRB_12bit(
				sdu_packet_pointer,
				sdu_packet_len,
				pdu_packet_pointer,
				pdu_packet_len,
				ts);



		}
		else{
			//process DRB 18b
		}
	}
	
}

void PDCP_rx(uint8_t *sdu_packet_pointer, size_t sdu_packet_len, struct timespec ts)//,PDCP_Config_t pdcp_config_params,Security_Config_t security_config_params)
{	
	//operate on SRB
	if(pdcp_config_params.rb_type==SRB){
			rx_SRB(			
				sdu_packet_pointer,
				sdu_packet_len);
			
	}
	//operate on DRB
	else{
		if(pdcp_config_params.PDCP_SN_Size==len_12bits){
				rx_DRB_12bit(
				sdu_packet_pointer,
				sdu_packet_len,
				ts);
			}
			else{
			//process DRB 18b
			}
	}
}

void pdcp_tx_release()
{
	// discard everything in buffer - for transmitter

	// Destroy the ROHC compressor for this single PDCP entity
	rohc_compressor_dest();

	// release PDCP Entity
}

void pdcp_rx_release()
{
	// if(AM_DRB || UM_DRB)
	// {
		
	// 	//	deliver the PDCP SDUs stored in the receiving PDCP entity to upper layers in ascending order of associated COUNT values
	//  //		after performing header compression for each PDU.

		// function will trigger the condition to send to upper layers.
	 	

	// }

	// deallocate memory for the reception buffer.
	if(pdcp_config_params.rb_type==DRB){
			t_reordering_drb12b(true);	
			free(rec_buf_drb12b);
			rohc_decompressor_dest();

		}
	else{
			t_reordering_srb(true);
			free(rec_buf_srb);
		}
	// Destroy the ROHC decompressor for this single PDCP entity
	
	// release PDCP Entity
}

//void pdcp_tx_re_establish(pdcp_config_t configParams)
void pdcp_tx_re_establish()
{
	// if( ! configParams.drb_ContinueROHC )
	// {
	// 	// reset the header compression protocol for uplink and start with an IR (Initialization and Reset) state in U-mode
	// 	rohc_compressor_dest();
	// 	rohc_compressor_init();
	// }
	// if(UM_DRB || SRB)
	// {
	// 	tx_next = 0;
	// }
	// if(SRB)
	// {
	// 	// clear transmission buffer (discard everything)
	// }

	// // set all flags
	
	// if(UM_DRB)
	// {
	// 	/*
	// 		- send everything in buffer to lower layers in ascending order of COUNT
	// 	 	- don't restart the discardTimer
	// 	*/
	// }
	// if(AM_DRB)
	// {
	// 	/* 
	// 		According to TS - "from the first PDCP SDU for which the successful delivery of the corresponding PDCP Data
	// 		PDU has not been confirmed by lower layers, perform retransmission or transmission of all the PDCP SDUs
	// 		already associated with PDCP SNs in ascending order of the COUNT values associated to the PDCP SDU"

	// 		(i.e)

	// 		Send everything in buffer (for which ack has not been received) to lower layers after performing 
	// 		- header compression
	// 		- integrity and ciphering
	// 	*/
	// }
}

//void pdcp_rx_re_establish(pdcp_config_t configParams)
void pdcp_rx_re_establish()
{
	// process the PDCP Data PDUs that are received from lower layers 

	// if(SRB)
	// {
	// 	// clear reception buffer (discard everything)
	// }
	// if(UM_DRB || SRB)
	// {
	// 	// stop and reset t-reordering
	// 	t_reord_running = false;
	// 	t_reord_start_time = 0;

	// 	if(UM_DRB)
	// 	{
	// 		/*
	// 			deliver all stored PDCP SDUs to the upper layers in ascending order of associated COUNT
	// 			values after performing header decompression 
	// 		*/

	// 	}
	// }

	// if( ! configParams.drb_ContinueROHC )
	// {
	// 	if(AM_DRB)
	// 	{
	// 		// perform header decompression for all stored PDCP SDUs
	// 	}
	// 	if(UM_DRB || AM_DRB)
	// 	{
	// 		// reset the header compression protocol for downlink and start with NC (No Context) state in U-mode
	// 		rohc_decompressor_dest();
	// 		rohc_decompressor_init();
	// 	}
	// }
	
	// if(UM_DRB || SRB)
	// {
	// 	rx_next = 0;
	// 	rx_deliv = 0;
	// }

	// set all flags

}