/*
	Date 		:	25-09-2019
	Version		:	2.0
	Authors		:	Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
	Includes	:	Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
	5G Testbed interns
*/

/*@brief AES header
 *@details This module contains the structures 
 *and pre defined assignments required by the 
 *PDCP_AES module
 */

#include<string.h>

#define AES_BLCK_LEN 16                                //Block length in bytes AES is 128-bit block only.
#define AES_SBOX_SZ 256                                //Size of SBOX. 
#define AES_KEY_EXP_SZ 176                             //Max AES Key expansion size. 
#define NO_OF_COLUMNS 4                                //The Number of Columns in AES State Matrix. 
#define NO_OF_ROWS 4                                   //The Number of Rows in AES State Matrix. 
#define NO_WORDS_KEY 4                                 //The number of (32 bit) words in a key.
#define NO_ROUNDS 10                                   //The number of rounds in AES Cipher.
#define AES_BLK_LEN 16                                 //Length of Block in bytes for processing.
#define AES_SBOX_LEN 256                               //AES S-box length.

/*
 * State - array matrix holding the bytes of the Block.The AES operation
 * is performed with this block
 * TODO: use better alternative, if possible e.g. Structure
 */
typedef uint8_t aesStateMat[NO_OF_ROWS][NO_OF_COLUMNS];

/*
 * @brief DS for holding AES Context Variables such as Roundkey and IV
 */
typedef struct AesCtx
{
    uint8_t roundKey[AES_KEY_EXP_SZ];
    uint8_t initVec[AES_BLCK_LEN];
} AesCtxT,
 *AesCtxP;

typedef struct AesCmacVars
{
    uint8_t sBox[AES_SBOX_LEN];
} AesCmacVarsT,
 *AesCmacVarsP;

/*
 * @brief DS for holding AES Counter Variable used for operation
 */
typedef struct AesCtrVars
{
    uint8_t sBox[AES_SBOX_SZ];
} AesCtrVarsT,
 *AesCtrVarsP;

 /* EOF */