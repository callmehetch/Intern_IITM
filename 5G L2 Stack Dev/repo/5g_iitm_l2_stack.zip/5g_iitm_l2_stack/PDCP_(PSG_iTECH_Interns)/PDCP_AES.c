/*
    Date        :   25-09-2019
    Version     :   2.0
    Authors     :   Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
    Includes    :   Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
    5G Testbed interns
*/


/*@brief AES Encryption Decryption and Integrity protection
 *
 *@details To perform AES Encryption decryption 
 *and Integrity protection
 */

#include "PDCP_AES.h"

/* @brief To Get SBOX value from the SBOX
 *
 * @param idx      :index of the SBOX
 * @param AesVarsP :Pointer to AES variable structures
 */
static u_char AesCtrSbox ( u_char idx, AesCtrVarsP aesVarst )
{
    return aesVarst->sBox [ (uint8_t) idx ];
}

/*
 * @brief To Perform Multiplication of a value with a constant
 *
 * Invoked by AesCtrMixClms()
 *
 * @param x :8 bit input value
 */
static uint8_t AesCtrMultime ( uint8_t x )
{
    return ( ( x<<1 ) ^ ( ( ( x>>7 ) & 1) * 0x1b) ) ;
}

/*
 * @brief To Perform AES Key expansion and corresponding Round keys
 *
 * @details This function produces NO_OF_COLUMNS(NO_ROUNDS+1) round keys.
 * The round keys are used in each round to decrypt the states.
 *
 * Invoked by AesIVInit()
 *
 * @param roundKey :Pointer to the Round Key
 * @param key      :initial 128 bit key
 * @param AesVarsP :Pointer to AES variable structures
 */
static void AesCtrKeyExp ( uint8_t* roundKey, const uint8_t* key, AesCtrVarsP  aesVarst)
{
      unsigned i, j, k;
      uint8_t tempa[4];                                                   //Used for the column/row operations
      static const uint8_t rCon[11] = {
                                          0x8d, 0x01, 0x02, 0x04, 0x08, 0x10,
                                          0x20, 0x40, 0x80, 0x1b, 0x36
                                      };

      /* The first round key is the key itself.*/
      for ( i = 0; i < NO_WORDS_KEY; ++i)
      {
        roundKey[ ( i * 4 ) + 0] = key[ ( i * 4 ) + 0];
        roundKey[ ( i * 4 ) + 1] = key[ ( i * 4 ) + 1];
        roundKey[ ( i * 4 ) + 2] = key[ ( i * 4 ) + 2];
        roundKey[ ( i * 4 ) + 3] = key[ ( i * 4 ) + 3];
      }

      /* All other round keys are found from the previous round keys */
      for ( i = NO_WORDS_KEY; i < NO_OF_COLUMNS * (NO_ROUNDS + 1); ++i)
      {
          k = (i - 1) * 4;
          tempa[0] = roundKey[k + 0];
          tempa[1] = roundKey[k + 1];
          tempa[2] = roundKey[k + 2];
          tempa[3] = roundKey[k + 3];
        if ( i % NO_WORDS_KEY == 0)
        {
            /*
             * This function shifts the 4 bytes in a word to the left once.
             * [a0,a1,a2,a3] becomes [a1,a2,a3,a0]
             */
            const uint8_t u8tmp = tempa[0];
            tempa[0] = tempa[1];
            tempa[1] = tempa[2];
            tempa[2] = tempa[3];
            tempa[3] = u8tmp;
            /*
             * SubWord() is a function that takes a four-byte input word and
             * applies the S-box to each of the four bytes to produce an output
             * word.
             */
            tempa[0] = AesCtrSbox (tempa[0], aesVarst);
            tempa[1] = AesCtrSbox (tempa[1], aesVarst);
            tempa[2] = AesCtrSbox (tempa[2], aesVarst);
            tempa[3] = AesCtrSbox (tempa[3], aesVarst);
            tempa[0] = tempa[0] ^ rCon[i/NO_WORDS_KEY];
        }

        j = i * 4;
        k = ( i - NO_WORDS_KEY ) * 4;
        roundKey[j + 0] = roundKey[k + 0] ^ tempa[0];
        roundKey[j + 1] = roundKey[k + 1] ^ tempa[1];
        roundKey[j + 2] = roundKey[k + 2] ^ tempa[2];
        roundKey[j + 3] = roundKey[k + 3] ^ tempa[3];
      }
}

/*
 * @brief To Calculate Round Key and add round key to the state matrix
 *
 * @details This function adds the round key to state.
 * The round key is added to the state by an XOR function.
 *
 * Invoked by AesCipher()
 *
 * @param round     :Number of the Round
 * @param state     :state array matrix containing data/IV
 * @param roundKey  :roundKey to operated with state matrix
 */
static void AesCtrAddRndKey ( uint8_t round,aesStateMat* state, uint8_t* roundKey )
{
    uint8_t i,j;
    for ( i=0; i < 4; ++i )
    {
        for ( j=0; j < 4; ++j )
        {
            (*state)[i][j] ^= roundKey[(round * NO_OF_COLUMNS * 4) + (i * NO_OF_COLUMNS) + j];
        }
    }
}

/*
 * @brief To Perform Byte Substitution in AES operation from S_BOX
 *
 * @details The AesCtrSubBytes Function Substitutes the values in the
 * state matrix with values in an S-box.
 *
 * Invoked by AesCipher()
 *
 * @param state state array matrix containing data/IV
 * @param AesVarsP Pointer to AES variable structures
 */
static void AesCtrSubBytes ( aesStateMat* state, AesCtrVarsP  aesVarst )
{
    uint8_t i, j;
    for ( i=0; i < 4; ++i )
    {
        for ( j=0; j < 4; ++j )
        {
            ( *state )[j][i] = AesCtrSbox ( ( *state )[j][i], aesVarst );
        }
    }
}

/*
 * @brief To Perform Shift Row in AES operation
 *
 * @details The AesCtrSftRow() function shifts the rows in the state
 * to the left.Each row is shifted with different offset.
 * Offset = Row number. So the first row is not shifted.
 *
 * Invoked by AesCipher()
 *
 * @param state :state array matrix containing data/IV
 */

static void AesCtrSftRow ( aesStateMat* state )
{
    uint8_t temp;

    /* Rotate first row 1 columns to left*/
    temp           = (*state)[0][1];
    (*state)[0][1] = (*state)[1][1];
    (*state)[1][1] = (*state)[2][1];
    (*state)[2][1] = (*state)[3][1];
    (*state)[3][1] = temp;

    /* Rotate second row 2 columns to left*/
    temp           = (*state)[0][2];
    (*state)[0][2] = (*state)[2][2];
    (*state)[2][2] = temp;

    temp           = (*state)[1][2];
    (*state)[1][2] = (*state)[3][2];
    (*state)[3][2] = temp;

    /* Rotate third row 3 columns to left*/
    temp           = (*state)[0][3];
    (*state)[0][3] = (*state)[3][3];
    (*state)[3][3] = (*state)[2][3];
    (*state)[2][3] = (*state)[1][3];
    (*state)[1][3] = temp;
}

/*
 * @brief To Perform Mix Column operation in AES operation
 *
 * @details AesCtrMixClms function mixes the columns of the state matrix
 *
 * Invoked by AesCipher()
 *
 * @param state :state array matrix containing data/IV
 */
static void AesCtrMixClms ( aesStateMat* state )
{
    uint8_t i;
    uint8_t tmp, tm, t;
    for ( i=0; i < 4; ++i )
    {
        t   = (*state)[i][0];
        tmp = (*state)[i][0] ^ (*state)[i][1] ^
              (*state)[i][2] ^ (*state)[i][3];
        tm  = (*state)[i][0] ^ (*state)[i][1];
        tm = AesCtrMultime (tm);
        (*state)[i][0] ^= tm ^ tmp ;
        tm  = (*state)[i][1] ^ (*state)[i][2] ;
        tm = AesCtrMultime (tm);
        (*state)[i][1] ^= tm ^ tmp ;
        tm  = (*state)[i][2] ^ (*state)[i][3] ;
        tm = AesCtrMultime (tm);
        (*state)[i][2] ^= tm ^ tmp ;
        tm  = (*state)[i][3] ^ t ;
        tm = AesCtrMultime (tm);
        (*state)[i][3] ^= tm ^ tmp ;
    }
}

/*
 * @brief To Perform AESBased ciphering
 *
 * @details Implement the AES Based algorithm for Ciphering input data
 *
 * Invoked by AesCip()
 *
 * @param state    :state array matrix containing data/IV
 * @param roundKey :roundKey used for operation
 * @param AesVarsP :Pointer to AES variable structures
 */
static void AesCipher ( aesStateMat* state, uint8_t* roundKey, AesCtrVarsP  aesVarst )
{
    uint8_t round = 0;

    /*Add the First round key to the state before starting the rounds.*/
    /* Pre Transformation round */
    AesCtrAddRndKey ( 0, state, roundKey );

    /* There will be 10 rounds.
     * The first 9 rounds are identical.
     * These 9 rounds are executed in the loop below.
     */
    for (round = 1; round < NO_ROUNDS; ++round )
    {
        AesCtrSubBytes ( state, aesVarst );
        AesCtrSftRow ( state );
        AesCtrMixClms ( state );
        AesCtrAddRndKey ( round, state, roundKey );
    }

    /*
     * The last round is given below.
     * The AesCtrMixClms function is not here in the last round.
     */
    AesCtrSubBytes ( state, aesVarst  );
    AesCtrSftRow ( state );
    AesCtrAddRndKey ( NO_ROUNDS, state, roundKey );
}

/*
 * @brief Function to fill AES-Counter Variables used in functions
 *
 * @param AesVarsP :Pointer to AES variable structures
 */
static void AesCtrFillVars ( AesCtrVarsP  aesVarst)
{
    /* S-BOX Table */
    uint8_t sBox[256] = {
                             0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5,
                             0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
                             0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0,
                             0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
                             0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc,
                             0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
                             0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a,
                             0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
                             0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0,
                             0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
                             0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b,
                             0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
                             0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85,
                             0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
                             0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5,
                             0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
                             0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17,
                             0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
                             0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88,
                             0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
                             0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c,
                             0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
                             0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9,
                             0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
                             0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6,
                             0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
                             0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e,
                             0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
                             0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94,
                             0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
                             0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68,
                             0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
                        };
    memcpy ( &aesVarst->sBox, sBox, sizeof(sBox) );
}

/*
 * @brief To Initialize AES Context structure with the IV and Key
 *
 * @details This function adds the initial IV and Key/ROundkey to the structure
 *
 * Invoked by AesCip()
 *
 * @param ctx      :Pointer to AES Context DS containing IV and roundKey arrays
 * @param key      :key to be added to the AES Context Structure
 * @param iv       :iv to be added to the AES Context Structure
 * @param AesVarsP :Pointer to AES variable structures
 */
static void AesIVInit ( AesCtxP ctx, const uint8_t* key, const uint8_t* iv, AesCtrVarsP  aesVarst )
{
  AesCtrKeyExp ( ctx->roundKey, key, aesVarst );
  memcpy ( ctx->initVec, iv, AES_BLCK_LEN );
}

/*
 * @brief To Perform AES Counter Based ciphering
 *
 * @details Implement the AES Counter Based algorithm for Ciphering input data
 *
 * Invoked by NEA2()
 *
 * @param ctx      :Pointer to AES Structure containing IV and roundKey arrays
 * @param plnMsg   :Pointer to input data
 * @param cipMsg   :Pointer to output data
 * @param length   :length of data in Bits
 * @param aesVarst :Pointer to Structure containing aes Variables
 */

static void AesCtrCrypt ( AesCtxP ctx, uint8_t* plnMsg ,uint8_t* cipMsg, uint32_t length, AesCtrVarsP  aesVarst )
{
    uint8_t buffer[AES_BLCK_LEN];
    uint32_t i;
    int32_t bi;
    uint32_t lastBits = (8-(length%8)) % 8;
    uint32_t lenb = (length+7)/8;
    for (i = 0, bi = AES_BLCK_LEN; i < lenb; ++i, ++bi)
    {
        if (bi == AES_BLCK_LEN)
        {
            memcpy(buffer, ctx->initVec, AES_BLCK_LEN);
            AesCipher ( (aesStateMat*)buffer, ctx->roundKey, aesVarst);

            /* Increment initVec till 255 for aes counter operation and
             * handle overflow
             */
            for (bi = ( AES_BLCK_LEN - 1); bi >= 0; --bi)
            {
                /* if increment overflows */
                if (ctx->initVec[bi] == 255)
                {
                    ctx->initVec[bi] = 0;
                    continue;
                }
                ctx->initVec[bi] += 1;
                break;
            }
            bi = 0;
       }
       cipMsg[i] = (plnMsg[i] ^ buffer[bi]);
    }
    if (lastBits)
    {
       cipMsg[length/8] &= 256 - (1<<lastBits);
    }
}

/*
 * @brief Main Function performing AES-CTR operations
 *
 * Invoked by NEA2()
 *
 * @param cipKey   :Key used for encryption
 * @param iv Init  :vector used for AES counter operation
 * @param plnMsg   :Pointer to input data
 * @param cipMsg   :Pointer to output data
 * @param lenBits  :length of data in Bits
 */
void AesCtrMain (const uint8_t* cipKey, const uint8_t* iv, u_char* plnMsg, u_char* cipMsg, uint32_t lenBits )
{
    AesCtxT ctx;
    AesCtrVarsT aesVarst;
    AesCtrFillVars(&aesVarst);
    AesIVInit ( &ctx, cipKey, iv, &aesVarst);
    AesCtrCrypt ( &ctx, (uint8_t*) plnMsg, (uint8_t*) cipMsg, lenBits, &aesVarst);
}

/*
 * @brief To Perform 128 Bit XOR operation for Rnd key Gen & cipher text Gen
 *
 * Invoked by AesCmac ()/AesMain ()/AesGenSubKey ()
 *
 * @param wordA  :Pointer to 128 Bit input 1
 * @param wordB  :Pointer to 128 Bit input 2
 * @param opWord :Pointer to 128 Bit output
 */
static void Aes128Xor ( u_char *wordA, u_char *wordB, u_char *opWord )
{
    int32_t i;
    for ( i = 0; i < 16; i++)
    {
        opWord[i] = wordA[i] ^ wordB[i];
    }
}

/*
 * @brief To Perform 32 Bit XOR operation in mix column opr and in key gen opr
 *
 * Invoked by AesCmacMixClm ()/AesCmacNxtKey ()
 *
 * @param wordA   :Pointer to 32 Bit input 1
 * @param wordB   :Pointer to 32 Bit input 2
 * @param opWord  :Pointer to 32 Bit output
 */
static void Aes32Xor ( u_char *wordA, u_char *wordB, u_char *opWord )
{
    uint32_t i;
    for ( i = 0; i < 4; i++)
    {
        opWord[i] = wordA[i] ^ wordB[i];
    }
}

/*
 * @brief To Get SBOX value from the SBOX
 *
 * Invoked by AesCmacByteSub ()
 *
 * @param idx      :index of the SBOX
 * @param AesVarsP :Pointer to AES variable structures
 */
static u_char AesCmacSbox ( u_char idx, AesCmacVarsP aesVarst )
{ 
    return aesVarst->sBox [ (uint8_t) idx ];
}

/*
 * @brief To Generate RoundKey for the next round
 *
 * Invoked by AesMain ()
 *
 * @param key      :Pointer to 128 Bit input key
 * @param round    :No of the round
 * @param AesVarsP :Pointer to AES variable structure
 */
static void AesCmacNxtKey ( u_char *key, uint32_t round, AesCmacVarsP aesVarst )
{
    u_char rCon;
    u_char sBoxKey[4];
    u_char rConTbl[12] = {
                          0x01, 0x02, 0x04, 0x08, 0x10, 0x20,
                          0x40, 0x80, 0x1b, 0x36, 0x36, 0x36
                          };

    sBoxKey[0] = AesCmacSbox ( key[13], aesVarst );
    sBoxKey[1] = AesCmacSbox ( key[14], aesVarst );
    sBoxKey[2] = AesCmacSbox ( key[15], aesVarst );
    sBoxKey[3] = AesCmacSbox ( key[12], aesVarst );

    rCon = rConTbl[round];

    Aes32Xor( &key[0], sBoxKey, &key[0] );
    key[0] = key[0] ^ rCon;

    Aes32Xor ( &key[4], &key[0], &key[4] );
    Aes32Xor ( &key[8], &key[4], &key[8] );
    Aes32Xor ( &key[12], &key[8], &key[12] );
}

/*
 * @brief To Perform Byte Substitution in AES operation from S_BOX
 *
 * Invoked by AesMain ()
 *
 * @param in      :Pointer to 128 Bit input data block
 * @param out     :Pointer to 128 Bit output data block
 * @param AesVarsP:Pointer to AES variable structure
 */
static void AesCmacByteSub ( u_char *in, u_char *out, AesCmacVarsP aesVarst )
{
    int32_t i;
    for ( i = 0; i < 16; i++)
    {
        out[i] = AesCmacSbox ( in[i], aesVarst );
    }
}

/*
 * @brief To Perform Shift Row operation in AES operation
 *
 * @details In AES Operation input is visualized to be stored in a
 * 4x4 matrix. The Row of the matrix are shifted in shift row operations.
 *
 * Invoked by AesMain()
 *
 * @param in  :Pointer to 128 Bit input data block
 * @param out :Pointer to 128 Bit output data block
 */
static void AesCmacSftRow ( u_char *in, u_char *out )
{
    out[0] =  in[0];
    out[1] =  in[5];
    out[2] =  in[10];
    out[3] =  in[15];
    out[4] =  in[4];
    out[5] =  in[9];
    out[6] =  in[14];
    out[7] =  in[3];
    out[8] =  in[8];
    out[9] =  in[13];
    out[10] = in[2];
    out[11] = in[7];
    out[12] = in[12];
    out[13] = in[1];
    out[14] = in[6];
    out[15] = in[11];
}

/*
 * @brief To Perform Mix Column operation in AES operation
 *
 * @details In AES Operation input is visualized to be stored in a
 * 4x4 matrix. The columns of the matrix are Substituted and shifted
 * in mix column operations.
 *
 * Invoked by AesMain ()
 *
 * @param in  :Pointer to 128 Bit input data block
 * @param out :Pointer to 128 Bit output data block
 */
static void AesCmacMixClm ( u_char *in, u_char *out )
{
    uint32_t i;
    u_char add1B[4];
    u_char add1BF7[4];
    u_char rotLf[4];
    u_char swapHlfs[4];
    u_char and7F[4];
    u_char rotRt[4];
    u_char temp[4];
    u_char tempB[4];

    for ( i = 0 ; i < 4; i++)
    {
        if ( ( in[i] & 0x80) == 0x80 )
        {
             add1B[i] = 0x1b;
        }
        else
        {
            add1B[i] = 0x00;
        }
    }

    swapHlfs[0] = in[2];                                                  // Swap halfs
    swapHlfs[1] = in[3];
    swapHlfs[2] = in[0];
    swapHlfs[3] = in[1];

    rotLf[0] = in[3];                                                     // Rotate left 8 bits 
    rotLf[1] = in[0];
    rotLf[2] = in[1];
    rotLf[3] = in[2];

    and7F[0] = in[0] & 0x7f;
    and7F[1] = in[1] & 0x7f;
    and7F[2] = in[2] & 0x7f;
    and7F[3] = in[3] & 0x7f;

    for ( i = 3; i > 0 ; i--)                                             //logical shift left 1 bit
    {
        and7F[i] = and7F[i] << 1;
        if ( ( and7F[i-1] & 0x80) == 0x80 )
        {
            and7F[i] = ( and7F[i] | 0x01 );
        }
    }
    and7F[0] = and7F[0] << 1;
    and7F[0] = and7F[0] & 0xfe;
    Aes32Xor ( add1B, and7F, add1BF7 );
    Aes32Xor ( in, add1BF7, rotRt );
    temp[0] = rotRt[0];                                                   //Rotate right 8 bits
    rotRt[0] = rotRt[1]; 
    rotRt[1] = rotRt[2];
    rotRt[2] = rotRt[3];
    rotRt[3] = temp[0];
    Aes32Xor ( add1BF7, rotRt, temp );
    Aes32Xor ( swapHlfs, rotLf,tempB );
    Aes32Xor ( temp, tempB, out );
}

/*
 * @brief To Perform AES algo to input data and produce cipher result
 *
 * @details Perform AES operation 10 round for a input block 128 Bits
 * and produces output cipher text block of 128 Bits
 *
 * Invoked by AesCmac ()
 *
 * @param key       :Pointer to 128 Bit Integrity Protection Key
 * @param data      :Pointer to 128 Bit input data block
 * @param ciphertext:Pointer to 128 Bit output data block
 * @param AesVarsP  :Pointer to AES variable structure
 */

static void AesMain ( u_char *key, u_char *data, u_char* ciphertext,  AesCmacVarsP  aesVarst )
{
    uint32_t round;
    int32_t i;
    u_char byteSubrslt[AES_BLK_LEN];
    u_char sftRowrlst[AES_BLK_LEN];
    u_char rndKey[AES_BLK_LEN];

    /* The AES Operation is done below Consists of 10 +1(iniitial) Rounds */
    for( i = 0; i < 16; i++)
    {
        rndKey[i] = key[i];
    }

    for ( round = 0; round < 11; round++)
    {
        if (round == 0)
        {
            /* AES Pre-round Transformation */
            Aes128Xor ( rndKey, data, ciphertext );
            AesCmacNxtKey ( rndKey, round,aesVarst );
        }
        else if (round == 10)
        {
            /* Last Round */
            AesCmacByteSub (ciphertext, byteSubrslt, aesVarst );
            AesCmacSftRow ( byteSubrslt, sftRowrlst );
            Aes128Xor ( sftRowrlst, rndKey, ciphertext );
        }
        else/* 1 - 9 */
        {
            /* Rounds 1-9 Byte sub, Mix clm and Shft row opns are done here */
            AesCmacByteSub ( ciphertext, byteSubrslt, aesVarst );
            AesCmacSftRow ( byteSubrslt, sftRowrlst );
            AesCmacMixClm ( &sftRowrlst[0], &byteSubrslt[0] );
            AesCmacMixClm ( &sftRowrlst[4], &byteSubrslt[4] );
            AesCmacMixClm ( &sftRowrlst[8], &byteSubrslt[8] );
            AesCmacMixClm ( &sftRowrlst[12], &byteSubrslt[12] );
            Aes128Xor ( byteSubrslt, rndKey, ciphertext );
            AesCmacNxtKey ( rndKey, round, aesVarst );
        }
    }
}

/*
 * @brief To Left shift one bit and detect overflow for Sub Key Generation
 *
 * Invoked by AesGenSubKey ()
 *
 * @param input    :Pointer to input data
 * @param output   :Pointer to output data
 * @param AesVarsP :Pointer to AES variable structure
 */
static void AesCmacLSftOnebit ( u_char *input, u_char *output )
{
    int32_t i;
    u_char overflow = 0;
    for ( i = 15; i >= 0; i-- )
    {
        output[i] = input[i] << 1;
        output[i] |= overflow;
        overflow = ( input[i] & 0x80 ) ? 1 : 0;
    }
    return;
}

/*
 * @brief To Generate subkeys K1 and K2 based on input key
 *
 * @details Generates subkeys K1 and K2
 *
 * Invoked by AesCmac ()
 *
 * @param key       :Pointer to 128 Bit Integrity Protection Key
 * @param K1        :Pointer to 128 Bit SubKey K1
 * @param K2        :Pointer to 128 Bit SubKey K2
 * @param AesVarsP  :Pointer to AES variable structure
 */
static void AesGenSubKey ( u_char *key, u_char *K1, u_char *K2 , AesCmacVarsP  aesVarst)
{
    u_char L[AES_BLK_LEN];
    u_char Z[AES_BLK_LEN];
    u_char cnstRb[16] =
                        {
                            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x87
                        };
    /* Z and L are Temporary variables used for Key Generation */
    u_char tmp[AES_BLK_LEN];
    int32_t i;

    for ( i = 0 ; i < 16; i++ )
    {
         Z[i] = 0;
    }

    AesMain ( key, Z, L, aesVarst );

    if ( ( L[0] & 0x80 ) == 0 )
    {   /* If MSB(L) = 0, then K1 = L << 1 */
        AesCmacLSftOnebit ( L, K1 );
    }
    else
    {   /* Else K1 = ( L << 1 ) (+) Rb */
        AesCmacLSftOnebit ( L, tmp );
        Aes128Xor ( tmp, cnstRb, K1 );
    }

    if ( (K1[0] & 0x80) == 0 )
    {
        AesCmacLSftOnebit ( K1, K2 );
    }
    else
    {
        AesCmacLSftOnebit( K1, tmp );
        Aes128Xor( tmp, cnstRb, K2 );
    }
}

/*
 * @brief Function to fill AES-CMAC Variables used in functions
 *
 * @param AesVarsP :Pointer to AES variable structure
 */
static void AesFillVars ( AesCmacVarsP  aesVarst)
{
    /* SBOX Table */
    u_char sBox[AES_SBOX_LEN] = {
                            0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5,
                            0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
                            0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0,
                            0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
                            0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc,
                            0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
                            0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a,
                            0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
                            0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0,
                            0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
                            0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b,
                            0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
                            0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85,
                            0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
                            0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5,
                            0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
                            0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17,
                            0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
                            0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88,
                            0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
                            0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c,
                            0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
                            0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9,
                            0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
                            0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6,
                            0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
                            0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e,
                            0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
                            0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94,
                            0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
                            0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68,
                            0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
                        };
    memcpy(&aesVarst->sBox,sBox,sizeof(sBox));
}

/*
 * @brief To Perform Padding to the last block of input data
 *
 * @details Pads a '1' bit folloed by n 0 'bits' to last block
 * so that block is complete i.e. Block is complete
 *
 * Invoked by AesCmac ()
 *
 * @param lastB    :Pointer to the last byte/block of input data
 * @param padRsl   :Pointer to padded output block
 * @param lenBits  :length of input data in Bits
 * @param numBlcks :number of Blocks of input data
 */
static void AesPadding ( u_char *lastB, u_char *padRsl, uint32_t lenBits, uint32_t numBlcks )
{
    uint32_t  j;
    uint32_t lenByte = ( ( lenBits / 8 ) -( (numBlcks-1) * AES_BLK_LEN) );
    uint32_t modLen = lenBits % 8;
    for ( j = 0; j < 16; j++ )
    {
        if ( j < lenByte )
        {
            padRsl[j] = lastB[j];
        }
        else if ( j == lenByte )
        {
            if( modLen == 0 )
            {
                padRsl[j] = 0x80;
            }
            else
            {
                padRsl[j] = ( lastB[j] & 0xff ) | ( 0x80 >> modLen );
            }
        }
        else
        {
            padRsl[j] = 0x00;
        }
    }
}

/*
 * @brief To Perform AES CMAC Based MAC Generation
 *
 * @details Implement the AES Based CMAC algorithm for Generation
 * of MAC for the input data
 *
 * Invoked by AesInt()
 *
 * @param key     :Pointer to 128 Bit Integrity Protection Key
 * @param inMsg   :Pointer to input data
 * @param lenBits :length of input data in Bits
 * @param mac     :pointer to generated MAC Value
 */
uint32_t AesCmac ( u_char *key, u_char *inMsg, uint32_t lenBits, uint32_t *mac)
{
    u_char X[AES_BLK_LEN];
    u_char Y[AES_BLK_LEN];
    AesCmacVarsT aesVarst;

    /* X and Y are Temporary variable -Block results are stored in this */
    u_char lastMsgBlk[AES_BLK_LEN];
    u_char K1[AES_BLK_LEN];
    u_char K2[AES_BLK_LEN];

    /* K1 and K2 SubKeys K1 and K2 */
    u_char padRslt[AES_BLK_LEN];
    uint32_t  n, i, flag;
    AesFillVars(&aesVarst);

    /* Generation of Sub-Keys K1 and K2 */
    AesGenSubKey ( key , K1 , K2, &aesVarst );

    /* memory allocation for mac array */
    uint32_t  lenByt = ( (lenBits+7) / 8 );
    n = ( lenByt + 15 ) / 16;                                             //n is number of rounds 

    if ( n == 0 )
    {
        n = 1;
        flag = 0;
    }
    else
    {
        if ( (lenBits%128) == 0 )
        {
            /* last block is a complete block */
            flag = 1;
        }
        else
        {
            /* last block is not complete block */
            flag = 0;
        }
    }
    if ( flag )
    {
        /* last block is complete block */
        Aes128Xor ( &inMsg[AES_BLK_LEN*(n-1)], K1, lastMsgBlk );
    }
    else
    {
        /* Padding is done to incomplete block */
        AesPadding ( &inMsg[AES_BLK_LEN*(n-1)], padRslt, lenBits, n );
        Aes128Xor ( padRslt, K2, lastMsgBlk );
    }
    for ( i = 0; i < 16; i++ )
    {
        X[i] = 0;
    }
    for ( i = 0; i < n-1; i++ )
    {
        Aes128Xor ( X, &inMsg[AES_BLK_LEN*i], Y);                         // Y = Msgi (Exor) X  
        AesMain ( key, Y, X, &aesVarst);                                  // X = AES-128(KEY, Y); 
    }

    Aes128Xor ( X, lastMsgBlk, Y );
    AesMain ( key, Y, X, &aesVarst );


    *mac = X[0];
    *mac = *mac<<8|X[1];
    *mac = *mac<<8|X[2];
    *mac = *mac<<8|X[3];
    return *mac;
}

/* Main function for AES Encryption-Decryption */
void AesCiph ( u_char *cipKey, uint32_t mCnt, uint32_t rbId, uint32_t dir, uint32_t lenBits, u_char *plnMsg, u_char *cipMsg)
{
    uint8_t iv[16];
    memset(iv, 0x00, 16);
    iv[0] = (uint8_t) (mCnt>>24);
    iv[1] = (uint8_t) (mCnt>>16);
    iv[2] = (uint8_t) (mCnt>>8);
    iv[3] = (uint8_t) (mCnt);
    iv[4] = (uint8_t) (rbId<<3);
    iv[4] |= (uint8_t) (dir<<2);
    AesCtrMain( cipKey, iv, plnMsg, cipMsg, lenBits);
}

/* EOF */