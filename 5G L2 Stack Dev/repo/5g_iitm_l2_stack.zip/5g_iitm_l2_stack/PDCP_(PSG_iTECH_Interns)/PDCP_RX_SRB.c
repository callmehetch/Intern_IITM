/*
	Date 		:	25-09-2019
	Version		:	2.0
	Authors		:	Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
	Includes	:	Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
	5G Testbed interns
*/


#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <time.h>
#include "PDCP_Config.h"
#include "PDCP_base.h"
/*---------------------------Define Constant Varibles--------------------*/

/* Number of bits of Sequence Number (SN) for each DRB - used in shift operations */
#define SN_SIZE_SRB 4

/* 
	Sequence Number Mod value (used to assign SN) - [SN = TX_NEXT % SN_MOD_DRB]  (because 1<<12 = 2^12) 
	This value is also the total number of Sequence numbers (max value of range)		
*/
#define SN_MOD_SRB (1<<SN_SIZE_SRB)

#define WINDOW_SIZE_SRB (1 << (SN_SIZE_SRB-1)) // window size = 2^(n-1) = [half of number of seq numbers] 

// ROHC_BUFFER_SIZE can be found in PDCP_Config.h

/*------------------------------RX Variables------------------------------------*/

/*
	All vaiables are declared as extern because the original declaration is done 
	in PDCP_Main.c file. (Common for all Types of Radio Bearers)
*/

// Used to keep track of the discarded packets
// Will not be used in final code (only for testing purposes)
// Pointer passed from RX controller and assigned to this global variable
extern uint32_t *discard_buf;
extern int *discard_idx;

/* 
	Reception Buffer (rec_buf_srb) is a double pointer (Array of structure pointers) 
	It contains SN_MOD_SRB (number of sequence numbers) pointers, 
	each pointing to a structure (PDU) if received, (or) pointing to NULL if not received. 
*/
extern PDU_data_SRB_t **rec_buf_srb;

extern uint8_t **pdcp_pdu;
extern size_t *pdcp_pdu_len;

// start variable records the time of enitity establshment. 
// It's used as a point of reference while t-reordering.
// It's value is assigned in pdcp_rx_establish() function which establishes the PDCP Receiver Entity
extern clock_t start; 

/* Initialization of rx_deliv, rx_reord and rx_next */
extern uint32_t rx_deliv_sn, rx_deliv_hfn, rx_deliv, rx_reord , rx_next ;

// rcvd_sn and rcvd_hfn should be able to house values upto 2^20 (HFN is 20 bits, when SN is 12 bits)
// COUNT is always 32 bits
extern uint32_t rcvd_sn, rcvd_hfn, rcvd_count; 	

extern bool outOfOrderDelivery;

// t-reordering related variables
extern bool t_reord_running;
extern bool t_reord_reconfig;
extern double t_reord_start_time, t_reord_threshold_time; //t_reord_threshold_time = 0.000064;

/*---------------------------------------------------------------------------------*/

extern PDCP_Config_t pdcp_config_params;
extern Security_Config_t security_config_params;

extern bool PDU_available;
extern bool PDU_read;


// Sends the PDU to upper layer
// Accepts the offset from the reception buffer start as argument (index)
// The PDU to send to SDAP is stored in rec_buf_srb[i]
void send_to_SDAP_srb(uint32_t i)
{
	

	// Send to L2 Controller to send to SDAP
	// Update the PDU pointers, so that L2 Controller can read.
	*pdcp_pdu = rec_buf_srb[i]->data;
	*pdcp_pdu_len = rec_buf_srb[i]->data_len; 

	// Notify L2 controller to read from buffer
	PDU_available = true;

	// Loop (wait) till PDU is not read in the L2 Controller
	// Implement Mutex or something similar
	while( ! PDU_read );

	// Reset the flags, so that L2 controller can wait for the next packet.
	PDU_read = false;
	PDU_available = false;

	// free memory from reception buffer (pointer pointing to PDU that we sent to SDAP)
	free(rec_buf_srb[i]->data);
	free(rec_buf_srb[i]);

	// assign NULL, so that next sequence's SDU can occupy (next HFN, same SN)
	rec_buf_srb[i] = NULL;

}

// returns the first unreceived index between starting index m and n
uint32_t find_FMC_srb(uint32_t m, uint32_t n) 
{
	for (uint32_t i = m; i < n; ++i)
	{
		if ( rec_buf_srb[i % SN_MOD_SRB] == NULL )		// return first unreceived index found
		{
			return i;
		}
	}
	return n;			// if FMC not within range, return last value, so that PDUs till the last can be sent.
}

// Module to perform t-reordering
/*
	The flag 'send_all_available_PDUs' is set to true when it's required to send all the availabe PDUs 
	in the reception buffer to upper layers (set as true and called from pdcp_rx_release)
*/
void t_reordering_srb(bool send_all_available_PDUs)
{ 
	/*
		==> current_time_interval(start) 
			-	function can be found in "PDCP_base.h"
			-	returns time interval between current time and the starting time
	*/

	if( t_reord_running && rx_deliv >= rx_reord )
	{
		t_reord_running = false;
	}
	if ( !(t_reord_running) && (rx_deliv < rx_next) )
	{
		rx_reord = rx_next;

		// start t-reordering timer
		t_reord_running = true;
		t_reord_start_time = current_time_interval(start);	// assigning current time to start
	}
	// if t-reordering timer expires
	int i;
	if( send_all_available_PDUs || 
		( t_reord_running && (current_time_interval(start) - t_reord_start_time > t_reord_threshold_time) ) )
	{
		// Send all stored PDCP SDU(s) with associated COUNT value(s) < RX_REORD
		for (i = rx_deliv; i < rx_reord; i++)
		{
			if ( rec_buf_srb[i % SN_MOD_SRB] != NULL )
			{
				printf("\nsend_to_SDAP 2 : [t-reordering timer expired - rx_deliv to rx_reord] \n");

				printf("\nSENT COUNT : %08x", i);

				send_to_SDAP_srb( i % SN_MOD_SRB );
			}
		}

		// update RX_DELIV to the COUNT value of the first PDCP SDU which has not been delivered to upper layers with COUNT value >= RX_REORD
		// if FMC==NO_OF_SAMPLES, then the last packet has been received, Therefore, update rx_deliv to last value, so that every PDU till that can be sent.
										
		rx_deliv = find_FMC_srb(rx_reord, rx_deliv + WINDOW_SIZE_SRB);

		// Send all stored PDCP SDU(s) with consecutively associated COUNT value(s) starting from RX_REORD
		for (i = rx_reord; i < rx_deliv; i++)
		{
			printf("\nsend_to_SDAP 3 : [t-reordering timer expired - rx_reord to rx_deliv] \n");

			printf("\nSENT COUNT : %08x", i);

			send_to_SDAP_srb( i % SN_MOD_SRB );
		}

		if( rx_deliv < rx_next )
		{
			rx_reord = rx_next;
			t_reord_running = true;
			t_reord_start_time = current_time_interval(start);
		}
	}

	// t-reordering reconfigred
	if( t_reord_reconfig )
	{ 
		rx_reord = rx_next;
		t_reord_reconfig = false;
		t_reord_running = true;
		t_reord_start_time = current_time_interval(start);
	}
}


void rx_SRB(uint8_t *sdu, size_t sdu_len )//uint8_t *sdu, size_t sdu_len, PDCP_Config_t pdcp_config_params,Security_Config_t security_config_params)//bool SDAP_Header,int SRB_type,bool integrity_protection,bool ciphering_disabled,int integrity_algorithm,int ciphering_algorithm,uint32_t bearer,uint32_t dir,uint32_t count,uint8_t *key)
{
	
	double loop = 0; //loop time variable. for checking purpose. not reqd for reorder function

	uint32_t XMAC;			//to store XMAC generated at the RX side.
	uint32_t MAC_I;			//to store MAC-I recerived from the TX side.

	/* Memory allocation to be valid throughout server run-time */
	PDU_data_SRB_t *pdcp_pdu = PDU_data_SRB_t_init(); //initialisation of temp. pointer to store data
		

	
	/* Assign pdu length to pdcp_pdu->data_len. */
	pdcp_pdu->data_len = sdu_len;
	
	pdcp_pdu->set = true;
	/* Assign pdu pointer to pdcp_sdu->data. */
	pdcp_pdu->data = sdu;

	PDU_data_SRB_t_header_op(pdcp_pdu); //remove header
	
	printf(" \nSN: %0x\n",pdcp_pdu->R_SN );

	printf("\n-------HEADER REMOVED----------\n");

	rx_deliv_hfn = rx_deliv >> SN_SIZE_SRB;
	rx_deliv_sn = rx_deliv & ((1<<SN_SIZE_SRB)-1);	// last 12 bits is SN in DRB12 (AND with 12 ones)

	// printf("\nRECEIVED!");
	// printf("\nrx_deliv_hfn : %0x",rx_deliv_hfn );
	// printf("\nrx_deliv_sn : %0x",rx_deliv_sn);

	rcvd_sn = pdcp_pdu->R_SN & ((1<<SN_SIZE_SRB)-1);	// last 12 bits is SN in DRB12 (AND with 12 ones)

	// printf("\nrcvd_sn : %0x",rcvd_sn);
	

	// Finding HFN - for COUNT value. 
	// typecast for signed comparison, because all are unsigned variables.
	if((signed) rcvd_sn < (signed) (rx_deliv_sn - WINDOW_SIZE_SRB))
		rcvd_hfn = rx_deliv_hfn + 1;
	else if((signed) rcvd_sn >= (signed) (rx_deliv_sn + WINDOW_SIZE_SRB))
		rcvd_hfn = rx_deliv_hfn - 1;
	else
		rcvd_hfn = rx_deliv_hfn;

	// printf("\nrcvd_hfn : %0x",rcvd_hfn);

	if(rcvd_hfn == -1)
	{
		// when hfn is at 0, and a packet with small SN is received very late, hfn goes to -1 (ERROR) -> reset to 0.
		rcvd_hfn = 0;
	}

	// count value (Last 12 bits is SN in DRB12 and first 20 are HFN)
	rcvd_count = (rcvd_hfn << SN_SIZE_SRB) | rcvd_sn;	

	printf("\nRCVD_COUNT : %08x\n",rcvd_count);

	/*Remove MAC-I from pdu and store it for integrity verification*/	
	if(pdcp_config_params.integrity_protection==true){
		MAC_I = (*(pdcp_pdu->data + pdcp_pdu->data_len - 4) << 24) | (*(pdcp_pdu->data + pdcp_pdu->data_len - 3) << 16) | (*(pdcp_pdu->data + pdcp_pdu->data_len - 2) << 8) | *(pdcp_pdu->data + pdcp_pdu->data_len - 1);
		pdcp_pdu->data_len -= 4;

		printf("\n-------MAC REMOVED----------\n");
		printf("\nMAC-I:  %0x\n",MAC_I);
	}

	if(pdcp_config_params.ciphering_disabled==false){
		printf("\n--------------------DECRYPTING--------------------\n");
		/*
			Function to perform ciphering/deciphering .
			@param 	integrity_algorithm 	type of algorithm to be used for ciphering/deciphering.
			@param 	pdcp_sdu->data_len 		length of sdu packet without pdu header attached.
			@param  pdcp_sdu->data 			pointer to sdu packet with 2 byte offset(Because only the data part of the SDU is to be ciphered ) .
			@param 	bearer					holds QOS flow or Mapped flow.
			@param  dir;		            holds direction of dataflow(uplink or downlink).
			@param  count;					holds 32 bit Frame dependent input.
			@param  key						holds 128bit key for ciphering and integrity protection.
			
			*/
		pdcp_pdu->data=ciphering_op(security_config_params.ciphering_algorithm, pdcp_pdu->data, pdcp_pdu->data_len,security_config_params.count, security_config_params.bearer, security_config_params.dir,security_config_params.key);

		
		printf("\n--------------------DECRYPTION SUCCESSFULL!!--------------------\n");
	}
	else{
		printf("\n--------------------DECRYPTION DISABLED--------------------\n");
	}
		
		
	
	if(pdcp_config_params.integrity_protection==true){ 
		printf("\n--------------------XMAC GENERATION--------------------\n ");
		/*Add pdu header to deciphered data for XMAC Generation*/
		pdcp_pdu->data-=2;
		pdcp_pdu->data_len+=2;
		*(pdcp_pdu->data) = pdcp_pdu->R_SN >> 8;
		*(pdcp_pdu->data + 1) = pdcp_pdu->R_SN & 0xFF;
		/*
			Function to perform integrity protection.
			@param 	integrity_algorithm 	type of algorithm to be used for mac generation
			@param 	pdcp_sdu->data_len 		length of sdu packet with pdu header attached.
			@param  pdcp_sdu->data 			pointer to sdu packet
			@param 	bearer					holds QOS flow or Mapped flow.
			@param  dir;		            holds direction of dataflow(uplink or downlink).
			@param  count;					holds 32 bit Frame dependent input.
			@param  key						holds 128bit key for ciphering and integrity protection
			
			*/
		XMAC= integrity_op(security_config_params.integrity_algorithm ,pdcp_pdu->data, pdcp_pdu->data_len,security_config_params.count, security_config_params.bearer, security_config_params.dir,security_config_params.key);

		printf("\n--------------------XMAC GENERATED SUCCESSFULLY!!--------------------\n");

		printf("\nXMAC:%x\n",XMAC);
		/*If XMAC and MAC-I are equal then data is not corrupted*/
		if(XMAC == MAC_I){
			printf("\n--------------------INTEGRITY VERIFIED!--------------------\n");
		}
		else{
			printf("\n--------------------DATA CORRUPTED!!--------------------\n");
		}

	}
	else{
			printf("\n--------------------INTEGRITY PROTECTION DISABLED--------------------\n");
	}
	//Remove PDU Header.
	pdcp_pdu->data+=2;
	pdcp_pdu->data_len-=2;

	
	uint32_t i,j;
	if( rcvd_count < rx_deliv || rec_buf_srb[rcvd_sn] != NULL )
	{
		printf("\nCOUNT : %08x discarded!\n",rcvd_count);
		/* discard condition 
			- if previously delivered packet received (or)
			- if duplicate packet received
		 */
		discard_buf[(*discard_idx)++] = rcvd_count;
	}
	else
	{
		rec_buf_srb[rcvd_sn] = malloc(sizeof(PDU_data_DRB_12bit_SN_t));

		// Stored in reception buffer offset by received packet COUNT value.
		rec_buf_srb[rcvd_sn]->R_SN = pdcp_pdu->R_SN;
		rec_buf_srb[rcvd_sn]->data_len = pdcp_pdu->data_len;
		rec_buf_srb[rcvd_sn]->set = pdcp_pdu->set;
		rec_buf_srb[rcvd_sn]->MAC = pdcp_pdu->MAC;

		// store data (make a copy from pdcp_pdu, because pdcp_pdu will be overwritten for each packet)
		
		rec_buf_srb[rcvd_sn]->data = malloc(pdcp_pdu->data_len * sizeof(uint8_t));

		for (j = 0; j < pdcp_pdu->data_len; ++j)
		{
			*(rec_buf_srb[rcvd_sn]->data + j) = *(pdcp_pdu->data +j);
		}
	}

	if (rcvd_count >= rx_next)
	{
		rx_next = rcvd_count + 1; //update rx_next based on rcvd_count
	}
	if( outOfOrderDelivery )
	{
		// if outOfOrderDelivery is configured, Send to Upper Layers and break the flow
	}
	if (rcvd_count == rx_deliv)
	{
		// printf("Entered rcvd_count = rx_deliv\n");

		uint32_t fmc = find_FMC_srb(rx_deliv, rx_deliv + WINDOW_SIZE_SRB);		// FMC - First Missing Count (within WINDOW)

		//printf("\nFMC: %x\n", fmc);

		for (i = rx_deliv; i < fmc; i++)
		{
			printf("\nsend_to_SDAP 1 : [rcvd_count==rx_deliv] \n");

			printf("\nSENT COUNT : %08x", i);

			send_to_SDAP_srb( i % SN_MOD_SRB );
		}
		rx_deliv = fmc;
	}

	//free(pdcp_pdu);

	// Call t-reordering here
	t_reordering_srb(false);
    free(pdcp_pdu);
	return ;
}