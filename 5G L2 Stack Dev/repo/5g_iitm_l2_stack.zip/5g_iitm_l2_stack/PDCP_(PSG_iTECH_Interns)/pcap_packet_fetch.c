/*
	Date 		:	25-09-2019
	Version		:	2.0
	Authors		:	Dr. Sumathi, Balasiddharth, Arunprasath, Sheeba
	Includes	:	Header Compression, Ciphering, Integrity Protection, PDCP RX and TX API, t-reordering and duplicate discarding
	5G Testbed interns
*/

/* Frame Capture and analyze - for feeding Ipv4 packet payloads to PDCP Layer.
   - Module for testing purposes only ( PDCP receives payload from upper-layers in real time ) */

// Other necessary headers are included in the server file, where this will be included.
#include <stdio.h>
#include <pcap.h>

/*-------------------------Define Variable declarations--------------------------*/

#define SIZE_ETHERNET 14
#define ETHER_ADDR_LEN 6

/*--------------------Structure Declarations for frame decoding------------------*/

/* Ethernet header */
struct sniff_ethernet {
	u_char ether_dhost[ETHER_ADDR_LEN]; /* Destination host address */
	u_char ether_shost[ETHER_ADDR_LEN]; /* Source host address */
	u_short ether_type; /* IP? ARP? RARP? etc */
};

/* Wifi 802.11 header not required because we are not using monitor mode.
   The packets received are always encapsulated with Ethernet II (802.3) headers  */

/* IPv4 header */
struct sniff_ip {
	u_char ip_vhl;		/* version << 4 | header length >> 2 */
	u_char ip_tos;		/* type of service */
	u_short ip_len;		/* total length */
	u_short ip_id;		/* identification */
	u_short ip_off;		/* fragment offset field */			// 3_13 -> 3 flag bits and 13 offset bits
#define IP_RF 0x8000		/* reserved fragment flag */
#define IP_DF 0x4000		/* dont fragment flag */
#define IP_MF 0x2000		/* more fragments flag */
#define IP_OFFMASK 0x1fff	/* mask for fragmenting offset bits */
	u_char ip_ttl;		/* time to live */
	u_char ip_p;		/* protocol */
	u_short ip_sum;		/* checksum */
	struct in_addr ip_src,ip_dst; /* source and dest address */
};
#define IP_HL(ip)		(((ip)->ip_vhl) & 0x0f)
#define IP_V(ip)		(((ip)->ip_vhl) >> 4)
#define IP_OFFSET(ip)	(((ip)->ip_off) & IP_OFFMASK)

/* Include Ipv6 header if necessary */


/* Captured Packet info*/
typedef struct captured_packet_info
{	
	u_char *payload_pointer;
	size_t payload_size;
}captured_packet_info_t;

/*-----------------------Functions to decode the packet--------------------------*/



int packet_decode(const u_char *packet, const struct pcap_pkthdr *header, struct timespec *ts)
{

	// Record the timestamp of the captured packet
    clock_gettime(CLOCK_REALTIME, ts);

	//const struct sniff_ethernet *ethernet; /* The ethernet header */
	const struct sniff_ip *ip; /* The IP header */
	//const u_char *payload; /* Packet payload */ 

	extern captured_packet_info_t *packet_info; /* Declared golbally in 'server_drb1.c' 
						Will be used for fetching packet info from server_drb1 */
	
	size_t size_ip; /* ip header size */

	/* Typecast and store in structure */
	//ethernet = (struct sniff_ethernet*)(packet);
	ip = (struct sniff_ip*)(packet + SIZE_ETHERNET);
	
	/* Calculate ip header size */
	size_ip = IP_HL(ip)*4;

	/* Discard Runt Frames */
	if (size_ip < 20) {
		//printf("   * Invalid IP header length: %u bytes\n", size_ip);
		return 0;
	}

	
	packet_info->payload_pointer = (u_char *) (packet + SIZE_ETHERNET); //+ size_ip);
	packet_info->payload_size = header->caplen - SIZE_ETHERNET; //- size_ip;

	return 1;
}

/*----------------------------------Main Controller-------------------------------*/

void capture_packet(struct timespec *ts)
{
	pcap_t *handle;         /* Session handle */
	char *dev;         /* Th6e device to sniff on */
	char errbuf[PCAP_ERRBUF_SIZE];  /* Error string */
	bpf_u_int32 mask;       /* Our netmask */
	bpf_u_int32 net;        /* Our IP */
	struct pcap_pkthdr header;  /* The header that pcap gives us */
	const u_char *packet;       /* The actual packet */

	/* Define the device */				// For pcap versions above 1.9.0 
	// pcap_if_t *interfaces;
	// if(pcap_findalldevs(&interfaces,errbuf)==PCAP_ERROR)
	// {
	// 	fprintf(stderr, "Couldn't find devices: %s\n", errbuf);
	// 	return;
	// }
	// dev = interfaces->name;

	/* Define the device */ 			// Works for pcap versions below 1.9.0 - deprecated starting from 1.9.0
	dev = pcap_lookupdev(errbuf);
	if (dev == NULL) {
	    fprintf(stderr, "Couldn't find default device: %s\n", errbuf);
	    return;
	}

	//printf("Device : %s\n",dev);

	/* Find the properties for the device */
	if (pcap_lookupnet(dev, &net, &mask, errbuf) == -1) {
	    fprintf(stderr, "Couldn't get netmask for device %s: %s\n", dev, errbuf);
	    net = 0;
	    mask = 0;
	}

	/* Open the session in promiscuous mode */
	handle = pcap_open_live(dev, BUFSIZ, 1, 1000, errbuf);
	if (handle == NULL) {
	    fprintf(stderr, "Couldn't open device %s: %s\n", dev, errbuf);
	    return;
	}


	/* Capture a packet and upload information in the 'packet_info' structure pointer */

	packet_capture_label: while(!(packet = pcap_next(handle, &header)));	// Keep looping while packet = NULL

	if( ! packet_decode(packet, &header, ts) )		// Invalid IP header -> packet_decode() returns 0.
		goto packet_capture_label;					// Capture another packet

	

	/* And close the session */
	pcap_close(handle);
}

