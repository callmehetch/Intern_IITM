
/*
	Date 		:	23-05-2019
	Version		: 	1.0
	Authors 	:	Viknesh, Ganesh, Nanda
	Includes	: 	PDU Data Structures, initializations, Reordering
	5G Testbed summer interns
*/


/*
	INSTUCTIONS -
		*	Memory Structures are defined as per the PDU Format given in 3GPP TS 38.323 version 15.2.0 Release 15
		*	Bit-wise split-up of certain data-variables are given in comments beside them.
*/

#ifndef _PDCP_BASE_H_
#define _PDCP_BASE_H_

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>

double current_time_interval(clock_t start); 

typedef struct PDU_data_SRB
{
	uint16_t R_SN; //4_12
	uint8_t *data;
	size_t data_len; 	// Total length of the payload (includes IPv4 header)
	uint32_t MAC;	
	bool set; // If false - remove header, Else add header. (used for encapsulation and decapsulaion)
}PDU_data_SRB_t;

PDU_data_SRB_t* PDU_data_SRB_t_init(void);  //initialisation
void PDU_data_SRB_t_data(PDU_data_SRB_t *ob);  //generate data
void PDU_data_SRB_t_header_op(PDU_data_SRB_t *ob);  //operation on header based on set variable
void PDU_data_SRB_t_MAC_I(PDU_data_SRB_t *ob, bool set); //operation on MAC-I
void PDU_data_SRB_t_cipher(PDU_data_SRB_t *ob); //ciphering
void PDU_data_SRB_t_int_proc(PDU_data_SRB_t *ob, uint8_t *key, uint32_t count, uint32_t bearer, uint32_t dir); //integrity protection
// for reorder
void reord_srb(PDU_data_SRB_t *A, PDU_data_SRB_t *p, int dbuf[], int *discard_idx, clock_t start);
int zero_srb(PDU_data_SRB_t *A, int m, int n);

typedef struct PDU_data_DRB_12bit_SN
{
	uint16_t DC_R_SN; //1_3_12
	uint8_t *data;
	size_t data_len; 	// Total length of the payload (includes IPv4 header)
	uint32_t MAC;
	bool set; // If false - remove header, Else add header. (used for encapsulation and decapsulaion)
	struct timespec ts;	// to store the timestamp of the PDU (on tx side and rx side)
}PDU_data_DRB_12bit_SN_t;

PDU_data_DRB_12bit_SN_t* PDU_data_DRB_12bit_SN_t_init(void);  //initialisation
void PDU_data_DRB_12bit_SN_t_data(PDU_data_DRB_12bit_SN_t *ob);  //generate data
void PDU_data_DRB_12bit_SN_t_header_op(PDU_data_DRB_12bit_SN_t *ob);  //operation on header based on set variable
void PDU_data_DRB_12bit_SN_t_MAC_I(PDU_data_DRB_12bit_SN_t *ob, bool set); //operation on MAC-I
void PDU_data_DRB_12bit_SN_t_cipher(PDU_data_DRB_12bit_SN_t *ob); //ciphering
void PDU_data_DRB_12bit_SN_t_int_proc(PDU_data_DRB_12bit_SN_t *ob, uint8_t *key, uint32_t count, uint32_t bearer, uint32_t dir); //integrity protection
// for reorder
void reord_drb1(PDU_data_DRB_12bit_SN_t *A, PDU_data_DRB_12bit_SN_t *p, int dbuf[], int *discard_idx, clock_t start);
int zero_drb1(PDU_data_DRB_12bit_SN_t *A, int m, int n);

typedef struct PDU_data_DRB_18bit_SN
{
	uint8_t DC_R_SN; //1_5_2
	uint16_t SN;
	uint8_t *data;
	size_t data_len; 	// Total length of the payload (includes IPv4 header)
	uint32_t MAC;
	bool set; // If false - remove header, Else add header. (used for encapsulation and decapsulaion)
}PDU_data_DRB_18bit_SN_t;

PDU_data_DRB_18bit_SN_t* PDU_data_DRB_18bit_SN_t_init(void);  //initialisation
void PDU_data_DRB_18bit_SN_t_data(PDU_data_DRB_18bit_SN_t *ob);  //generate data
void PDU_data_DRB_18bit_SN_t_header_op(PDU_data_DRB_18bit_SN_t *ob);  //operation on header based on set variable
void PDU_data_DRB_18bit_SN_t_MAC_I(PDU_data_DRB_18bit_SN_t *ob, bool set); //operation on MAC-I
void PDU_data_DRB_18bit_SN_t_cipher(PDU_data_DRB_18bit_SN_t *ob); //ciphering
void PDU_data_DRB_18bit_SN_t_int_proc(PDU_data_DRB_18bit_SN_t *ob, uint8_t *key, uint32_t count, uint32_t bearer, uint32_t dir); //integrity protection
//for reorder
void reord_drb2(PDU_data_DRB_18bit_SN_t *A, PDU_data_DRB_18bit_SN_t *p, int dbuf[], int *discard_idx, clock_t start);
int zero_drb2(PDU_data_DRB_18bit_SN_t *A, int m, int n);

typedef struct PDU_control_Status_report
{
	uint8_t DC_Type_R; //1_3_4
	uint32_t FMC;
	uint8_t *BitMap;
	size_t BitMap_len;
}PDU_control_status_report_t;

PDU_control_status_report_t* PDU_control_status_report_t_init(void);  //initialisation

typedef struct PDU_control_ROHC
{
	uint8_t DC_Type_R; //1_3_4
	uint8_t *ROHCfb;
	size_t ROHCfb_len;
}PDU_control_ROHC_t;

PDU_control_ROHC_t* PDU_control_ROHC_t_init(void);  //initialisation


/*-----------------------------------initialisation------------------------------------*/

PDU_data_SRB_t* PDU_data_SRB_t_init(void)  
{
	PDU_data_SRB_t* p = malloc(sizeof(PDU_data_SRB_t));
	p->R_SN = 0;
	p->set = false;
	return p;
}

PDU_data_DRB_12bit_SN_t* PDU_data_DRB_12bit_SN_t_init(void)  
{
	PDU_data_DRB_12bit_SN_t* p = malloc(sizeof(PDU_data_DRB_12bit_SN_t));
	p->DC_R_SN = 1<<15;		// D/C bit set to 1 and other bits to 0
	p->set = false;
	return p;
}

PDU_data_DRB_18bit_SN_t* PDU_data_DRB_18bit_SN_t_init(void)  
{
	PDU_data_DRB_18bit_SN_t* p = malloc(sizeof(PDU_data_DRB_18bit_SN_t));
	p->DC_R_SN = 1<<7;		// D/C bit set to 1 and other bits to 0
	p->SN = 0;
	p->set = false;
	return p;
}

PDU_control_status_report_t* PDU_control_status_report_t_init(void)  
{
	PDU_control_status_report_t* p = malloc(sizeof(PDU_control_status_report_t));
	p->DC_Type_R = 0;
	return p;
}

PDU_control_ROHC_t* PDU_control_ROHC_t_init(void)  
{
	PDU_control_ROHC_t* p = malloc(sizeof(PDU_control_ROHC_t));
	p->DC_Type_R = 1<<4;
	return p; 
}


/*-----------------------------------data generation------------------------------------*/

void PDU_data_SRB_t_data(PDU_data_SRB_t *ob)  
{
	srand(time(0));
	// ob->data_len = rand()%8 + 1;
	ob->data_len = 8;

	uint8_t* p;
	p = (uint8_t*)malloc(ob->data_len * sizeof(uint8_t));

	for (int i = 0; i < ob->data_len; ++i)
		*(p + i) = rand() & 0xFF; 

	ob->data = p; 
}

void PDU_data_DRB_12bit_SN_t_data(PDU_data_DRB_12bit_SN_t *ob)  
{
	srand(time(0));
	// ob->data_len = rand()%8 + 1;
	ob->data_len = 8;

	uint8_t* p;
	p = (uint8_t*)malloc(ob->data_len * sizeof(uint8_t));

	for (int i = 0; i < ob->data_len; ++i)
		*(p + i) = rand() & 0xFF; 

	ob->data = p; 
}

void PDU_data_DRB_18bit_SN_t_data(PDU_data_DRB_18bit_SN_t *ob)  
{
	srand(time(0));
	// ob->data_len = rand()%8 + 1;
	ob->data_len = 8;

	uint8_t* p;
	p = (uint8_t*)malloc(ob->data_len * sizeof(uint8_t));

	for (int i = 0; i < ob->data_len; ++i)
		*(p + i) = rand() & 0xFF; 

	ob->data = p; 
}

/*------------------------- operation on header based on set variable----------------------------*/

void PDU_data_SRB_t_header_op(PDU_data_SRB_t *ob)  
{
	if (!ob->set)
	{
		// Add Header to data
		ob->data -= 2;
		ob->data_len += 2;
		ob->set = true;
		*(ob->data) = ob->R_SN >> 8;
		*(ob->data + 1) = ob->R_SN & 0xFF;
	}
	else
	{
		// Remove Header from data
		ob->R_SN = (*(ob->data) << 8) | *(ob->data + 1);
		ob->data += 2;
		ob->data_len -= 2;
		ob->set = false;
	}
}

void PDU_data_DRB_12bit_SN_t_header_op(PDU_data_DRB_12bit_SN_t *ob)  
{
	if (!ob->set)
	{
		// Add Header to data (Encapslation)
		ob->data -= 2;
		ob->data_len += 2;
		ob->set = true;
		*(ob->data) = ob->DC_R_SN >> 8;
		*(ob->data + 1) = ob->DC_R_SN & 0xFF;
	}
	else
	{
		// Remove Header from data (Decapsulation)
		ob->DC_R_SN = (*(ob->data) << 8) | *(ob->data + 1);
		ob->data += 2;
		ob->data_len -= 2;
		ob->set = false;
	}
}

void PDU_data_DRB_18bit_SN_t_header_op(PDU_data_DRB_18bit_SN_t *ob)  
{
	if (!ob->set)
	{
		// Add Header to data
		ob->data -= 3;
		ob->data_len += 3;
		ob->set = true;
		*(ob->data) = ob->DC_R_SN;
		*(ob->data + 1) = ob->SN >> 8;
		*(ob->data + 2) = ob->SN & 0xFF;
		}
	else
	{
		// Remove Header from data
		ob->DC_R_SN = *(ob->data);
		ob->SN = (*(ob->data + 1) << 8) | *(ob->data + 2);
		ob->data += 3;
		ob->data_len -= 3;
		ob->set = false;
	}
}

/*------------------------- operation on header based on set variable----------------------------*/
void PDU_data_SRB_t_MAC_I(PDU_data_SRB_t *ob, bool set)
{
	if (set)
	{
		// Add MAC to data
		*(ob->data + ob->data_len) = ob->MAC >> 24;
		*(ob->data + ob->data_len + 1) = (ob->MAC >> 16) & 0xFF;
		*(ob->data + ob->data_len + 2) = (ob->MAC >> 8) & 0xFF;
		*(ob->data + ob->data_len + 3) = ob->MAC & 0xFF;
		ob->data_len += 4;
	}
	else
	{
		// Remove MAC from data
		ob->MAC = (*(ob->data + ob->data_len - 4) << 24) | (*(ob->data + ob->data_len - 3) << 16) | (*(ob->data + ob->data_len - 2) << 8) | *(ob->data + ob->data_len - 1);
		ob->data_len -= 4;
	}
}

/*--------------------------------------- t-reordering ----------------------------------------------------*/
double current_time_interval(clock_t start) //returns the duration between current time and start
{
	double seconds;
	clock_t end = clock();
	seconds = (double)(end-start)/CLOCKS_PER_SEC;
	return seconds;
}

#endif