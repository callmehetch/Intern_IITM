# 5G_IITM_L2_STACK
Support for user plane data.
4 Layers
1. SDAP -   Service Data Adaptation Protocol
2. PDCP -   Packet Data Convergence Protocol
3. RLC  -   Radio Link Control
4. MAC  -   Medium Access Control

