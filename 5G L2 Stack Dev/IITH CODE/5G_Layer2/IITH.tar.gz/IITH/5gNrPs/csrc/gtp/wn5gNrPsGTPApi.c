/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wn5gNrPsGTPApi.c
 * @author Venkat Rahul, Nikita Mudkanna
 * @breif GTP Data plane protocol for data transfer
 *
 */

#include "wn5gNrPsGTPApi.h"


/**
 * @brief To allocates memory for GTP Header
 *
 * @param pktBuf
 * @returns wnGTPv1UP or WN_RET_NULL
 */
wnGTPv1UP wnGTPv1UAlloc( ngPkt *pktBuf )
{
    /** Variable for GTPv1U */
    wnGTPv1UP GTPv1UP;
    /** Allocated Memory for GTPv1U in mBuf using prepend */
    GTPv1UP = ( wnGTPv1UP )rte_pktmbuf_prepend( pktBuf, sizeof( wnGTPv1UP ) );
    if( NULL == GTPv1UP )
    {
        WN_LOG_DEBUG( "Memory Allocation failed" );
        return WN_RET_NULL;  /** Memory Allocation Failed */
    }
    else
        return GTPv1UP;     /** Memory Allocation Successful */
}


/**
 * @brief To Initialize GTP Header
 *
 * @param GTPv1UP
 * @param version
 * @param ProtocolTypeFlag
 * @param Spare
 * @param ExtensionFlag
 * @param SequenceNumberFLAG
 * @param NpduNumberFlag
 * @param MessageType
 * @param Length
 * @param TEID
 * @param SequenceNumber
 * @param NPDUNumber
 * @param NextExtensionHeaderType
 * @returns wnGTPv1UP or WN_RET_NULL
 */
wnGTPv1UP wnGTPv1UInit( wnGTPv1UP GTPv1UP, wnUInt8 version,\
wnUInt8 ProtocolTypeFlag, wnUInt8 Spare, wnUInt8 ExtensionFlag,\
wnUInt8 SequenceNumberFLAG, wnUInt8 NpduNumberFlag, wnUInt8 MessageType,\
wnUInt16 Length, wnUInt32 TEID, wnUInt16 SequenceNumber, wnUInt8 NPDUNumber,\
wnUInt8 NextExtensionHeaderType )
{
    /** Initialize Fields in GTPv1U Header */
    GTPv1UP->version                     = version;
    GTPv1UP->ProtocolTypeFlag            = ProtocolTypeFlag;
    GTPv1UP->Spare                       = Spare;
    GTPv1UP->ExtensionFlag               = ExtensionFlag;
    GTPv1UP->SequenceNumberFLAG          = SequenceNumberFLAG;
    GTPv1UP->NpduNumberFlag              = NpduNumberFlag;
    GTPv1UP->MessageType                 = MessageType;
    GTPv1UP->Length                      = Length;
    GTPv1UP->TEID                        = TEID;
    GTPv1UP->SequenceNumber              = SequenceNumber;
    GTPv1UP->NPDUNumber                  = NPDUNumber;
    GTPv1UP->NextExtensionHeaderType     = NextExtensionHeaderType;

    if (!(NULL == GTPv1UP ))                                
        return GTPv1UP;           /** Success */
    else
        return WN_RET_NULL;       /** Fail */
}


/**
 * @brief To allocates memory for GTP Header
 *
 * @param pktBuf
 * @returns PDUSessionContainerP or WN_RET_NULL
 */
wnPDUSessionContainerP wnPDUSessionContainerAlloc( ngPkt *pktBuf )
{
    wnPDUSessionContainerP PDUSessionContainerP;
    /** Allocated Memory for GTPv1U in mBuf using prepend */
    PDUSessionContainerP = ( wnPDUSessionContainerP )rte_pktmbuf_prepend
                           ( pktBuf, sizeof( wnPDUSessionContainerP ) );
    if( NULL == PDUSessionContainerP )
    {
        WN_LOG_DEBUG( "\nMemory Allocation failed\n" );
        return WN_RET_NULL;            /** Memory Allocation Failed */
    }
    else
        return PDUSessionContainerP;  /** Memory Allocation Successful */
}


/**
 * @brief To initialize extension of GTP Header
 *
 * @param PDUSessionContainerP
 * @param LengthInOctet
 * @param PDUSSessionContainer1
 * @param PDUSSessionContainer2
 * @param PDUSSessionContainer3
 * @param NextExtensionHeaderType
 * @returns PDUSessionContainerP or WN_RET_NULL
 */
wnPDUSessionContainerP wnPDUSessionContainerInit 
( wnPDUSessionContainerP PDUSessionContainerP, wnUInt8 LengthInOctet,\
  wnUInt8 PDUSSessionContainer1, wnUInt8 PDUSSessionContainer2,\
  wnUInt32 PDUSSessionContainer3, wnUInt8 NextExtensionHeaderType )
{
    /** Initialize Fields in PDUSessionContainer Header */
    PDUSessionContainerP->LengthInOctet              = LengthInOctet;
    PDUSessionContainerP->PDUSSessionContainer1      = PDUSSessionContainer1;
    PDUSessionContainerP->PDUSSessionContainer2      = PDUSSessionContainer2;
    PDUSessionContainerP->PDUSSessionContainer3      = PDUSSessionContainer3;
    PDUSessionContainerP->NextExtensionHeaderType    = NextExtensionHeaderType;
       
    if (!(NULL == PDUSessionContainerP ))                                
        return PDUSessionContainerP;           /** Success */
    else
        return WN_RET_NULL;                   /** Fail */
}

/** EOF */  
