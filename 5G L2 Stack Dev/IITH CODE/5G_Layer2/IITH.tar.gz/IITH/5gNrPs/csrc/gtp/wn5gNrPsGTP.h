/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wn5gNrPsGTP.h
 * @author keval
 * @breif GTP Data plane protocol for data transfer
 * @see
 * @see
 */

#ifndef __WN_NR_PS_GTP_H__
#define __WN_NR_PS_GTP_H__


#include "../common/inc/wnBsPsDataTypes.h"
#include "../common/inc/wnBsPsErrTypes.h"
#include "../common/inc/wnBsPsFwk.h"
#include "../common/ngPkt/wnNgPktApi.h"


#define VERSION                     0
#define PROTOCOL_TYPE_FLAG          0
#define SPARE                       1
#define EXTENSION_FLAG              0
#define SEQ_NUM_FLAG                0
#define NPDU_NUM_FLAG               1
#define MESSAGE_TYPE                0
#define LENGTH                      0 
#define TEID_BIT                    1
#define SEQ_NUM                     0
#define NPDU_NUM                    0
#define NXT_EXTENSION_HDR_TYPE      1
#define LENGTH_IN_OCTET             0
#define PDUS_SESSION_CONTAINER1     0
#define PDUS_SESSION_CONTAINER2     1
#define PDUS_SESSION_CONTAINER3     0



typedef struct WN_PACKED wnGTPv1U{
    wnUInt8  version                :3;
    wnUInt8  ProtocolTypeFlag       :1;
    wnUInt8  Spare                  :1;
    wnUInt8  ExtensionFlag          :1;
    wnUInt8  SequenceNumberFLAG     :1;
    wnUInt8  NpduNumberFlag         :1;
    wnUInt8  MessageType;
    wnUInt16 Length;
    wnUInt32 TEID;
    wnUInt16 SequenceNumber;
    wnUInt8  NPDUNumber;
    wnUInt8  NextExtensionHeaderType;
} wnGTPv1UT,
 *wnGTPv1UP;

typedef struct wnPDUSessionContainer{
    wnUInt8  LengthInOctet;
    wnUInt8  PDUSSessionContainer1;
    wnUInt8  PDUSSessionContainer2;
    wnUInt32 PDUSSessionContainer3;
    //wnUInt32 PDUSSessionContainer4:24;
    wnUInt8  NextExtensionHeaderType;
} wnPDUSessionContainerT,
 *wnPDUSessionContainerP;

typedef struct concate{
    wnGTPv1UT n1;
    wnPDUSessionContainerT n2;
} concateT,
 *concateP;

/*
wnGTPv1UT * EncodeGTP();
wnPDUSessionContainerT * GetPduSessionInfo();
*/

#endif  /* __WN_NR_PS_GTP_H__  */

/** EOF */  
