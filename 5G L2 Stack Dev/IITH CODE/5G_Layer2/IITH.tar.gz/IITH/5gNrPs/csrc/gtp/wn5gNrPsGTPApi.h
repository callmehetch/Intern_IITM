/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/

/**
 * @file wn5gNrPsGTPApi.h
 * @author Venkat Rahul, Nikita Mudkanna
 * @breif GTP Data plane protocol for data transfer
 *
 */

#ifndef __WN_5G_NR_PS_GTP_API_H__
#define __WN_5G_NR_PS_GTP_API_H__


#include "wn5gNrPsGTP.h"

/** Prototypes for GTP header APIs */

wnGTPv1UP wnGTPv1UAlloc( ngPkt *pktBuf );
wnGTPv1UP wnGTPv1UInit ( wnGTPv1UP GTPv1UP, wnUInt8 version,\
              wnUInt8 ProtocolTypeFlag, wnUInt8 Spare, wnUInt8 ExtensionFlag,\
              wnUInt8 SequenceNumberFLAG, wnUInt8 NpduNumberFlag, wnUInt8 MessageType,\
              wnUInt16 Length, wnUInt32 TEID, wnUInt16 SequenceNumber, wnUInt8 NPDUNumber,\
              wnUInt8 NextExtensionHeaderType );

wnPDUSessionContainerP wnPDUSessionContainerAlloc( ngPkt *pktBuf );
wnPDUSessionContainerP wnPDUSessionContainerInit ( wnPDUSessionContainerP \
              PDUSessionContainerP, wnUInt8 LengthInOctet,wnUInt8 PDUSSessionContainer1,\
              wnUInt8 PDUSSessionContainer2, wnUInt32 PDUSSessionContainer3,\
              wnUInt8 NextExtensionHeaderType );


#endif  /**__WN_5G_NR_PS_GTP_API_H__ */

/** EOF */  
