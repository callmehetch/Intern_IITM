/*copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/
/**
 * @file wn5gNrPsMacApi.h
 * @author Nikita Mudkanna
 * @brief file containing prototypes of APIs for mac Protocol Header
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/mac/mac
 */

#ifndef __WN_5G_NR_PS_MAC_API_H__
#define __WN_5G_NR_PS_MAC_API_H_

#include "wn5gNrPsMacHeader.h"


/** Prototypes of APIs for MAC sublayer protocol Header */

wnMacSch8bSbHdrP wnMac8bHdrAlloc( ngPkt **pktBuf );
wnMacSch8bSbHdrP wnMac8bHdrInit ( wnMacSch8bSbHdrP *macDl8bHdr, 
	                          wnUInt8 format, wnUInt8 lcid, wnUInt8 len );
wnUInt8 wnMac8bHdrFrmt ( wnMacSch8bSbHdrP mac, wnUInt8 format );
wnUInt8 wnMac8bHdrLcid( wnMacSch8bSbHdrP mac, wnUInt8 lcid );
wnUInt8 wnMac8bHdrLen ( wnMacSch8bSbHdrP mac, wnUInt8 len );

wnMacSch16bSbHdrP wnMac16bHdrAlloc ( ngPkt **pktBuf );
wnMacSch16bSbHdrP wnMac16bHdrInit ( wnMacSch16bSbHdrP *macDl16bHdr, 
               wnUInt8 format, wnUInt8 lcid, wnUInt8 lenmsb, wnUInt8 lenlsb );
wnUInt8 wnMac16bHdrFrmt ( wnMacSch16bSbHdrP mac, wnUInt8 format );
wnUInt8 wnMac16bHdrLcid ( wnMacSch16bSbHdrP mac, wnUInt8 lcid );
wnUInt8 wnMac16bHdrLenlsb ( wnMacSch16bSbHdrP mac, wnUInt8 lenlsb );
wnUInt8 wnMac16bHdrLenmsb ( wnMacSch16bSbHdrP mac, wnUInt8 lenmsb );

wnMacFixedSbHdrP wnMacFixedHdrAlloc ( ngPkt **pktBuf );
wnUInt8 wnMacFixedHdrInit ( wnMacFixedSbHdrP macDlHdr, wnUInt8 lcid );
wnUInt8 wnMacFixedHdrLcid ( wnMacFixedSbHdrP mac, wnUInt8 lcid );

#endif /** __WN_5G_NR_PS_MAC_API_H_ */

/** EOF */
