/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
* @file wn5gNrPsPdcp.c
* @author Manoj Kumar
* @brief PDCP APIs for Framework(Initial Version) it's common to both gNB & UE
*
* @see http://git.wisig.com/root/5gNrBsPs/wikis/README
* @see http://git.wisig.com/root/5gNrBsPs/wikis/pdcp/pdcp
*/

#include <string.h>
#include "wn5gNrPdcp.h"
#include "wn5gNrPsPdcpHdr.h"

/**
 * @brief To Allocate memory for 18-bit DRB header of PDCP
 *
 * @aram pktBuf : ngPkt
 * @returns pdcpUHdr12Drb or NULL
 */
wnPdcpUHdr18DrbP wn5gNrPdcpUHdr18DrbAlloc ( ngPkt **pktBuf)
{
    wnPdcpUHdr18DrbP pdcpUHdr18Drb;
    hdrInfoP p;

    /** Allocates memory for 18-bit DRB header */
    pdcpUHdr18Drb = ( wnPdcpUHdr18DrbP ) ngPktPrepend ( *pktBuf,
                                            sizeof ( wnPdcpUHdr18DrbT ));
    if( NULL == pdcpUHdr18Drb ) {
        WN_LOG_DEBUG("");
        return WN_RETNULL;
    }

    p = wnGetHdrInfoFromMbuf(*pktBuf);
    //memset(p, 0, sizeof(hdrInfoT));
    p->hdrmap |= PDCPHDR_PRSNT;
    p->hdrLoc[PDCPHDR_LOC] = pdcpUHdr18Drb;

    return pdcpUHdr18Drb;
}


/**
 * @brief To ALlocates memory and initialize the 18-bit DRB header of PDCP
 *
 * @param pdcpUHdr18Drb : Pointer of PDCP header
 * @param d_c  : To check user data or control data
 * @param res  : Reserve bit
 * @param sn   : Sequence number
 * @returns pdcpUHdr18Drb as pointer
 */
wnPdcpUHdr18DrbP wn5gNrPdcpUHdr18DrbInit ( wnPdcpUHdr18DrbP pdcpUHdr18Drb,
                                       wnUInt8 d_c, wnUInt8 res, wnUInt32 sn )
{
    wnInt8 ret;

    if (NULL == pdcpUHdr18Drb) {
        WN_LOG_DEBUG("");
        return WN_RETNULL;
    }

    /** 1-bit for data or control */
    ret = wn5gNrPdcpSetDcBit ((void *)pdcpUHdr18Drb, d_c, WN_PDCP_HDR_DRB18_E );
    /** Reserve 5-bits */
    ret = wn5gNrPdcpSetResBits ( (void *)pdcpUHdr18Drb, res, WN_PDCP_HDR_DRB18_E);
    /** 18-bit sequence number */
    ret = wn5gNrPdcpSetSeqNo ( (void *)pdcpUHdr18Drb, sn, WN_PDCP_HDR_DRB18_E);
    if(ret!=0)
    {
        WN_LOG_DEBUG("HEADER INIT FAILURE");
    }
    /** returns as pdcpUHdr18DrbP pointer */
    return pdcpUHdr18Drb;
}


/**
 * @brief To Allocate memory for 12-bit DRB header of PDCP
 *
 * @aram pktBuf : ngPkt
 * @returns pdcpUHdr12Drb or NULL
 */

wnPdcpUHdr12DrbP wn5gNrPdcpUHdr12DrbAlloc ( ngPkt ** pktBuf)
{
    wnPdcpUHdr12DrbP pdcpUHdr12Drb;
    hdrInfoP p;

    /** Allocates memory for 12-DRB header */
    pdcpUHdr12Drb = ( wnPdcpUHdr12DrbP ) ngPktPrepend ( *pktBuf,
                                           sizeof ( wnPdcpUHdr12DrbT) );
    if ( NULL == pdcpUHdr12Drb) {
        WN_LOG_DEBUG("");
        return WN_RETNULL;
    }

    p = wnGetHdrInfoFromMbuf(*pktBuf);
    //memset(p, 0, sizeof(hdrInfoT));
    p->hdrmap |= PDCPHDR_PRSNT;
    p->hdrLoc[PDCPHDR_LOC] = pdcpUHdr12Drb;

    return pdcpUHdr12Drb;
}


/**
 * @brief To initialize the 12-bit DRB header of PDCP
 *
 * @param pktBuf : Pointer of rte_mbuf
 * @param pdcpUHdr12DrbP : Pointer of PDCP header
 * @param d_c  : To check user data or control data
 * @param res  : Reserve bits
 * @param sn   : Sequence number
 * @returns pdcpUHdr12Drb
 */
wnPdcpUHdr12DrbP wn5gNrPdcpUHdr12DrbInit ( wnPdcpUHdr12DrbP pdcpUHdr12Drb,
                                   wnUInt8 d_c, wnUInt8 res, wnUInt16 sn )
{
    wnInt8 ret;

    if (NULL == pdcpUHdr12Drb) {
        WN_LOG_DEBUG("");
        return WN_RETNULL;
    }
    /** 1-bit for data or control */
    ret = wn5gNrPdcpSetDcBit ((void *)pdcpUHdr12Drb, d_c, WN_PDCP_HDR_DRB12_E );
    /** Reserve 3-bits */
    ret = wn5gNrPdcpSetResBits ( (void *)pdcpUHdr12Drb, res, WN_PDCP_HDR_DRB12_E);
    /** 12-bits sequence number */
    ret = wn5gNrPdcpSetSeqNo ( (void *)pdcpUHdr12Drb, sn, WN_PDCP_HDR_DRB12_E);
    /** returns as pdcpUHdr12DrbP pointer */
    if(ret!=0)
    {
        WN_LOG_DEBUG("HEADER INIT FAILURE");
    }
    return pdcpUHdr12Drb;
}


/**
 * @brief To Allocate memory for 12-bit SRB header of PDCP
 *
 * @aram pktBuf : ngPkt
 * @returns pdcpUHdr12Drb or NULL
 */

wnPdcpCHdr12SrbP wn5gNrPdcpCHdr12SrbAlloc ( ngPkt **pktBuf )
{
    wnPdcpCHdr12SrbP pdcpCHdr12Srb;
    hdrInfoP p;

    /** Allocates memory for 12-bit SRB header */
    pdcpCHdr12Srb = ( wnPdcpCHdr12SrbP ) ngPktPrepend ( *pktBuf,
                                            sizeof( wnPdcpCHdr12SrbT ));
    if ( NULL == pdcpCHdr12Srb ) {
        WN_LOG_DEBUG("");
        return WN_RETNULL;
    }

    p = wnGetHdrInfoFromMbuf(*pktBuf);
    //memset(p, 0, sizeof(hdrInfoT));
    p->hdrmap |= PDCPHDR_PRSNT;
    p->hdrLoc[PDCPHDR_LOC] = pdcpCHdr12Srb;
    return pdcpCHdr12Srb;
}


/**
* @brief To initialize the 12-bit SRB header of PDCP
*
* @param pdcpCHdr12SrbP : Pointer of PDCP header
* @param res  : Reserve bit
* @param sn   : Sequence Number
* @returns pdcpCHdr12SrbP or NULL
*/
wnPdcpCHdr12SrbP wn5gNrPdcpCHdr12SrbInit ( wnPdcpCHdr12SrbP pdcpCHdr12Srb,
 wnUInt8 res, wnUInt16 sn )
{
    wnInt8 ret;

    if (NULL ==  pdcpCHdr12Srb) {
        WN_LOG_DEBUG("");
        return WN_RETNULL;
    }

    /** Reserve 4-bit */
    ret = wn5gNrPdcpSetResBits ( (void *)pdcpCHdr12Srb, res, WN_PDCP_HDR_SRB12_E);
    /** 12-bit sequence number */
    ret = wn5gNrPdcpSetSeqNo ( (void *)pdcpCHdr12Srb, sn, WN_PDCP_HDR_SRB12_E);
    /** return as pdcpCHdr12SrbP pointer */
    if(ret!=0)
    {
        WN_LOG_DEBUG("HEADER INIT FAILURE");
    }
    return pdcpCHdr12Srb;
}


/**
 * @brief To Allocate memory for status report header of PDCP
 *
 * @aram pktBuf : ngPkt
 * @returns pdcpUHdr12Drb or NULL
 */
wnPdcpCStatusRepP wn5gNrPdcpCStsRepAlloc ( ngPkt **pktBuf )
{
    wnPdcpCStatusRepP pdcpCStatusRep;
    hdrInfoP p;

    /** To allocate memory */
    pdcpCStatusRep = ( wnPdcpCStatusRepP )  ngPktPrepend ( *pktBuf,
                                          sizeof( wnPdcpCStatusRepT ));
    if ( NULL == pdcpCStatusRep ) {
        WN_LOG_DEBUG("");
        return WN_RETNULL;
    }

    p = wnGetHdrInfoFromMbuf(*pktBuf);
    //memset(p, 0, sizeof(hdrInfoT));
    p->hdrmap |= PDCPHDR_PRSNT;
    p->hdrLoc[PDCPHDR_LOC] = pdcpCStatusRep;

    return pdcpCStatusRep;
}



/**
* @brief To initialize control status report PDU of PDCP
*
* @param pdcpCStatusRep : Pointer of PDCP control status report PDU
* @param d_c     : To check user data or control data
* @param pduType : To check PDU type
* @param res     : reserve bit
* @returns pdcpCStatusRep
*/
wnPdcpCStatusRepP wn5gNrPdcpCStsRepInit ( wnPdcpCStatusRepP pdcpCStatusRep,
                        wnUInt8 d_c, wnUInt8 pduType, wnUInt8 res )
{
    if (NULL ==  pdcpCStatusRep) {
        WN_LOG_DEBUG("");
        return WN_RETNULL;
    }
    /** 1-bit for data or control */
    (pdcpCStatusRep)->d_c = d_c;
    /**  3-bit for PDU type */
    (pdcpCStatusRep)->pduType = pduType;
    /** reserve 4-bit */
    (pdcpCStatusRep)->res = res;
    /**
     * returns as pdcpCstatusRepP pointer
     */
    return pdcpCStatusRep;
}



/**
 * @brief To Allocate memory for control PDU of interspersed ROHC feedback
 *
 * @aram pktBuf : Pointer of rte_mbuf
 * @returns pdcpUHdr12Drb or WN_RET_NULL
 */
wnPdcpCRohcFdbkP wn5gNrPdcpCRohcFdbkAlloc ( ngPkt **pktBuf )
{
    wnPdcpCRohcFdbkP pdcpCRohcFdbk;
    hdrInfoP p;

    /** To allocates memory */
    pdcpCRohcFdbk = ( wnPdcpCRohcFdbkP )  ngPktPrepend ( *pktBuf,
                                           sizeof ( wnPdcpCRohcFdbkT ));
    if ( NULL == pdcpCRohcFdbk )
    {
        WN_LOG_DEBUG("");
        /** Memory allocation failed */
        return WN_RETNULL;
    }

    p = wnGetHdrInfoFromMbuf(*pktBuf);
    //memset(p, 0, sizeof(hdrInfoT));
    p->hdrmap |= PDCPHDR_PRSNT;
    p->hdrLoc[PDCPHDR_LOC] = pdcpCRohcFdbk;

    return pdcpCRohcFdbk;
}


/**
* @brief To initialize control PDU of interspersed ROHC feedback
*
* @param pdcpCRohcFdbk: Pointer of control PDU of PDCP
* @param d_c     : To check user data or control data
* @param pduType : To check PDU type
* @param res     : reserve bit
* @returns pdcpCRohcFdbk
*/
wnPdcpCRohcFdbkP wn5gNrPdcpCRohcFdbkInit ( wnPdcpCRohcFdbkP pdcpCRohcFdbk,
                       wnUInt8 d_c, wnUInt8 pduType, wnUInt8 res)
{
    /** 1-bit for user or control */
    (pdcpCRohcFdbk)->d_c = d_c;
    /** 3-bit for PDU type */
    (pdcpCRohcFdbk)->pduType = pduType;
    /** Reserve 4-bit */
    (pdcpCRohcFdbk)->res = res;
    return pdcpCRohcFdbk;
}


/**
* @brief To Set Data or Control Bit of PDCP Header
*
* @param hdr  : Double Pointer of PDCP Header
* @param d_c  : user data or control data
* @param type : PDCP Header type
* @returns status
*/
wnInt8 wn5gNrPdcpSetDcBit ( void * hdr, wnUInt8 d_c, wnPdcpHdrTypeE hdrType)
{
    if (NULL == hdr) {
        WN_LOG_DEBUG("");
        return WN_RETINVD;
    }

    if (hdrType == WN_PDCP_HDR_SRB12_E)
        {
            // wnPdcpCHdr12SrbP p = (wnPdcpCHdr12SrbP) *hdr;
            // p->d_c = d_c;
            return WN_SUCCESS;
        }
    else if (hdrType == WN_PDCP_HDR_DRB12_E)
        {
            wnPdcpUHdr12DrbP p = (wnPdcpUHdr12DrbP) hdr;
            p->d_c = d_c;
            return WN_SUCCESS;
        }
    else if (hdrType == WN_PDCP_HDR_DRB18_E)
        {
            wnPdcpUHdr18DrbP p = (wnPdcpUHdr18DrbP) hdr;
            p->d_c = d_c;
            return WN_SUCCESS;
        }
    else
    {
        return WN_RETINVD;
    }

}


/**
* @brief To Set Reserve Bits of PDCP Header
*
* @param hdr   : Double Pointer of PDCP Header
* @param resv  : reserve Bit value
* @param type  : PDCP Header type
* @returns status
*/
wnInt8 wn5gNrPdcpSetResBits ( void * hdr, wnUInt8 resv, wnPdcpHdrTypeE hdrType)
{
    if (NULL == hdr) {
        WN_LOG_DEBUG("");
        return WN_RETINVD;
    }

    if (hdrType == WN_PDCP_HDR_SRB12_E)
        {
            wnPdcpCHdr12SrbP p = (wnPdcpCHdr12SrbP) hdr;
            p->res = resv;
            return WN_SUCCESS;
        }
    else if (hdrType == WN_PDCP_HDR_DRB12_E)
        {
            wnPdcpUHdr12DrbP p = (wnPdcpUHdr12DrbP) hdr;
            p->res = resv;
            return WN_SUCCESS;
        }
    else if (hdrType == WN_PDCP_HDR_DRB18_E)
        {
            wnPdcpUHdr18DrbP p = (wnPdcpUHdr18DrbP) hdr;
            p->res = resv;
            return WN_SUCCESS;
        }
    else
        {
           return WN_RETINVD;
        }


}


/**
* @brief To Set Sequence Number of PDCP Header
*
* @param hdr  : Double Pointer of PDCP Header
* @param sno  : Sequence Number of Header
* @param type : PDCP Header type
* @returns status
*/
wnInt8 wn5gNrPdcpSetSeqNo ( void * hdr, wnUInt32 sno, wnPdcpHdrTypeE hdrType)
{
    if (NULL == hdr)
    {
        WN_LOG_DEBUG("");
        return WN_RETINVD;
    }

    if (hdrType == WN_PDCP_HDR_SRB12_E)
        {
            wnPdcpCHdr12SrbP p = (wnPdcpCHdr12SrbP) hdr;
            #if LIT_END
                p->sn1=sno>>8;
                p->sn2=sno;
            #endif
            #if (!LIT_END)
                p->sn=sno;
            #endif

            return WN_SUCCESS;
        }
    else if (hdrType == WN_PDCP_HDR_DRB12_E)
        {
            wnPdcpUHdr12DrbP p = (wnPdcpUHdr12DrbP) hdr;
            #if LIT_END
                p->sn1=sno>>8;
                p->sn2=sno;
            #endif
            #if (!LIT_END)
                p->sn=sno;
            #endif
            return WN_SUCCESS;
        }
    else if (hdrType == WN_PDCP_HDR_DRB18_E)
        {
          wnPdcpUHdr18DrbP p = (wnPdcpUHdr18DrbP) hdr;
          #if LIT_END
              p->sn1=sno>>16;
              p->sn2=sno>>8;
              p->sn3=sno;
        #endif
        #if (!LIT_END)
              p->sn=sno;
        #endif
        return WN_SUCCESS;
        }
    else
        return WN_RETINVD;


}

/* EOF */
