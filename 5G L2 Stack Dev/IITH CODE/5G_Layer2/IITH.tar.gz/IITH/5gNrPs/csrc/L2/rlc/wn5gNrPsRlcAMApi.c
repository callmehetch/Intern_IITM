/*****************************************************************************
* Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
* www.wisig.com                                                             *
*                                                                           *
* All information contained herein is property of WiSig Networks Pvt Ltd.   *
* unless otherwise explicitly mentioned.                                    *
*                                                                           *
* The intellectual and technical concepts in this file are proprietary      *
* to WiSig Networks and may be covered by granted or in process national    *
* and international patents and are protect by trade secrets and            *
* copyright law.                                                            *
*                                                                           *
* Redistribution and use in source and binary forms of the content in       *
* this file, with or without modification are not permitted unless          *
* permission is explicitly granted by WiSig Networks.                       *
* If WiSig Networks permits this source code to be used as a part of        *
* open source project, the terms and conditions of CC-By-ND (No Derivative) *
* license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
*****************************************************************************/

/**
* @file wn5gNrPsRlcAMApi.c
* @author Venkat Rahul, Vishnu
* @brief API's for RLC AM, it is common for UE and gNB
*
* @see http://git.wisig.com/root/5gNrBsPs/fwk/L2/rlc
*/
#include "../../common/ngPkt/wnNgPktApi.h"
#include "wn5gNrPsRlcAMApi.h"


/**
 * @brief To allocates memory for RLC AM Headers
 *
 * @param pktBuf : ng packet pointer
 * @param snType : type of Sequence number
 * @returns wnVoid*
 */
wnVoid* wnRlcAMHdrAlloc(ngPkt **pktBuf, wnRlcAmHdrE snType )
{
    /* Variable for RLC Header Structure */
    wnVoid *hdr;
    hdrInfoP p;
    if( snType == WN_RLC_AM_HDR_TYPE_1_ENUMVAL_E)
    {
        /* Allocated Memory for 12-bit Header in mBuf using prepend */
        hdr = ( wnRlcAm12HdrP )ngPktPrepend( *pktBuf, \
		                                      sizeof( wnRlcAm12HdrT ) );
        if( NULL == hdr )
        {
            WN_LOG_DEBUG("Memory Allocation failed");
            return WN_RETNULL; /* Memory Allocation Failed */
        }
        p = wnGetHdrInfoFromMbuf(*pktBuf);
        p->hdrmap |= RLCHDR_PRSNT;
        p->hdrLoc[RLCHDR_LOC] = hdr;
        return hdr;
    }
    if(snType == WN_RLC_AM_HDR_TYPE_2_ENUMVAL_E)
    {
        /* Allocated Memory for 18-bit Header in mBuf using prepend */
        hdr = ( wnRlcAm18HdrP )ngPktPrepend(*pktBuf, sizeof( wnRlcAm18HdrT ));

        if( NULL == hdr )
        {
            WN_LOG_DEBUG("Memory Allocation failed");
            return WN_RETNULL; /* Memory Allocation Failed */
        }
        p = wnGetHdrInfoFromMbuf(*pktBuf);
        p->hdrmap |= RLCHDR_PRSNT;
        p->hdrLoc[RLCHDR_LOC] = hdr;
        return hdr;
    }
}

#if 0
/**
* @brief To initialize RLC AM Header
*
* @param dc: Data/Control bit
* @param Poll: Poll bit
* @param si: Segement Info
* @param so: Segement Offset
* @param sn: Sequence Number
* @returns wnInt8
*/
wnInt8 wnRlcAMHdrInit( wnVoid *amHdr, wnInt8 dc,
                            wnInt8 poll, wnUInt16 si, wnUInt16 sn, wnUInt16 so, wnRlcAmHdrE snType )
{
    if (NULL == amHdr) {
        WN_LOG_DEBUG("");
         eturn WN_RETNULL;
    }

    if(snType == WN_RLC_AM_HDR_TYPE_1_ENUMVAL_E)
    {
        /*Fields in 12-bit Header*/
        wnRlcAm12HdrP rlcAm12HdrP;
        rlcAm12HdrP = (wnRlcAm12HdrP)(amHdr);
        (rlcAm12HdrP)->dc         = dc;
        (rlcAm12HdrP)->poll       = poll;
        (rlcAm12HdrP)->si         = si;
        (rlcAm12HdrP)->sn         = sn;
        //(amHdr)->rlcAm12HdrP->so         = so;
        return WN_SUCCESS;
    }

    if(snType == WN_RLC_AM_HDR_TYPE_2_ENUMVAL_E)
    {
        /*Fields in 18-bit Header*/
        wnRlcAm18HdrP rlcAm18HdrP;
        rlcAm18HdrP = (wnRlcAm18HdrP)(amHdr);
        (rlcAm18HdrP)->dc         = dc;
        (rlcAm18HdrP)->poll       = poll;
        (rlcAm18HdrP)->si         = si;
        (rlcAm18HdrP)->sn         = sn;
        return WN_SUCCESS;
    }

 return WN_RETNULL;
}
#endif

/**
 * @brief API for assigning data/control bit
 *
 * @param amHdr  :  pointer to AM header
 * @param snType : Sequence number type of AM header
 * @returns Status
 */
wnInt8 wnRlcSetDcBit(wnVoid *amHdr, wnRlcAmHdrE snType)
{
    if (NULL == amHdr) {
        WN_LOG_DEBUG(" null ");
        printf("\nnull\n");
        return WN_RETNULL;
    }
    /* Assigning '1' to data/control bit in 12-bit header */
    if(snType == WN_RLC_AM_HDR_TYPE_1_ENUMVAL_E)
    {
        wnRlcAm12HdrP rlcAm12HdrP;
        rlcAm12HdrP = (wnRlcAm12HdrP)(amHdr);
        return (rlcAm12HdrP->dc = 1);
    }

    if(snType == WN_RLC_AM_HDR_TYPE_2_ENUMVAL_E)
    {
        wnRlcAm18HdrP rlcAm18HdrP;
        rlcAm18HdrP = (wnRlcAm18HdrP)(amHdr);
        return (rlcAm18HdrP->dc = 1);
    }
    else
    {
        WN_LOG_DEBUG("wrong sn type");
        return WN_FAILURE;
    }
}

/**
 * @brief API for assigning poll bit
 *
 * @param amHdr
 * @param Poll: Poll Bit
 * @param SnType: Type of Sn either 12 or 18
 *
 * @returns status
 */
wnInt8 wnRlcSetPollBit( wnVoid *amHdr, wnInt8 poll, wnRlcAmHdrE snType )
{
    if (NULL == amHdr) {
        WN_LOG_DEBUG("");
        return WN_FAILURE;
    }

    if( snType == WN_RLC_AM_HDR_TYPE_1_ENUMVAL_E )
    {
        wnRlcAm12HdrP rlcAm12HdrP;
        rlcAm12HdrP = (wnRlcAm12HdrP)(amHdr);
        return (rlcAm12HdrP->poll = poll);
    }
    if( snType == WN_RLC_AM_HDR_TYPE_2_ENUMVAL_E )
    {
        wnRlcAm18HdrP rlcAm18HdrP;
        rlcAm18HdrP = (wnRlcAm18HdrP)(amHdr);
        return (rlcAm18HdrP->poll = poll);
    }
    else
        return WN_RETINVD;
}

/**
 * @brief API for Update Si
 *
 * @param amHdr
 * @param Si: Segement Info
 * @param SnType: Type of Sn either 12 or 18
 * @returns Status
 */
wnInt8 wnRlcUpdateSi( wnVoid *amHdr, wnUInt16 si, wnRlcAmHdrE snType )
{
    if (NULL == amHdr) {
        WN_LOG_DEBUG("");
        return WN_FAILURE;
    }

    if( snType == WN_RLC_AM_HDR_TYPE_1_ENUMVAL_E )
    {
        wnRlcAm12HdrP rlcAm12HdrP;
        rlcAm12HdrP = (wnRlcAm12HdrP)(amHdr);
        return (rlcAm12HdrP->si = si);
    }
    if( snType == WN_RLC_AM_HDR_TYPE_2_ENUMVAL_E ){
     wnRlcAm18HdrP rlcAm18HdrP;
        rlcAm18HdrP = (wnRlcAm18HdrP)(amHdr);
        return (rlcAm18HdrP->si = si);
    }
    else
        return WN_RETINVD;
}

#if 0
/**
 * @brief API for Update So
 *
 * @param amHdr
 * @param So: Segment Offset
 * @param SnType: Type of Sn either 12 or 18
 * @returns status
 */
wnInt8 wnRlcUpdateSo( wnVoid *amHdr, wnUInt16 so, wnRlcAmHdrE snType )
{
    if (NULL == amHdr) {
        WN_LOG_DEBUG("");
        return WN_FAILURE;
    }

    if( snType == WN_RLC_AM_HDR_TYPE_1_ENUMVAL_E )
    {
        wnRlcAm12HdrP rlcAm12HdrP;
        rlcAm12HdrP = (wnRlcAm12HdrP)(amHdr);
        return (rlcAm12HdrP->so = so);
    }
    if ( snType == WN_RLC_AM_HDR_TYPE_2_ENUMVAL_E )
    {
         wnRlcAm18HdrP rlcAm18HdrP;
        rlcAm18HdrP = (wnRlcAm18HdrP)(amHdr);
        return (rlcAm18HdrP->so = so);
    }
    else
    return WN_RETINVD;
}
#endif

/**
 * @brief API for Update Sn
 *
 * @param amHdr
 * @param sn: Sequence Number
 * @param snType: Type of Sn either 12 or 18
 * @returns amHdr
 */
wnInt8 wnRlcUpdateSn( wnVoid *amHdr, wnUInt32 sn, wnRlcAmHdrE snType )
{
    if (NULL == amHdr)
    {
        WN_LOG_DEBUG("");
        return WN_FAILURE;
    }

    if( snType == WN_RLC_AM_HDR_TYPE_1_ENUMVAL_E )
    {
        wnRlcAm12HdrP rlcAm12HdrP;
        rlcAm12HdrP = (wnRlcAm12HdrP)(amHdr);
        #if (!LIT_END)
        (rlcAm12HdrP)->sn = sn;
        #endif

        #if (LIT_END)
        (rlcAm12HdrP)->sn1 = sn>>8;
        (rlcAm12HdrP)->sn2 = sn;
        #endif
        return sn;
    }
    else if( snType == WN_RLC_AM_HDR_TYPE_2_ENUMVAL_E )
    {
        wnRlcAm18HdrP rlcAm18HdrP;
        rlcAm18HdrP = (wnRlcAm18HdrP)(amHdr);
        #if (!LIT_END)
        (rlcAm18HdrP)->sn = sn;
        #endif

        #if (LIT_END)
        (rlcAm18HdrP)->sn1 = sn>>16;
        (rlcAm18HdrP)->sn2 = sn>>8;
        (rlcAm18HdrP)->sn3 = sn;
        #endif
        return sn;
    }
    else
        return WN_RETINVD;
}
