/*****************************************************************************
* Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
* www.wisig.com                                                             *
*                                                                           *
* All information contained herein is property of WiSig Networks Pvt Ltd.   *
* unless otherwise explicitly mentioned.                                    *
*                                                                           *
* The intellectual and technical concepts in this file are proprietary      *
* to WiSig Networks and may be covered by granted or in process national    *
* and international patents and are protect by trade secrets and            *
* copyright law.                                                            *
*                                                                           *
* Redistribution and use in source and binary forms of the content in       *
* this file, with or without modification are not permitted unless          *
* permission is explicitly granted by WiSig Networks.                       *
* If WiSig Networks permits this source code to be used as a part of        *
* open source project, the terms and conditions of CC-By-ND (No Derivative) *
* license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
*****************************************************************************/

/**
* @file wn5gNrPsRlcUMApi.c
* @author Venkat Rahul
* @brief API's fo RLC UM, it is common for UE and gNB
*
* @see http://git.wisig.com/root/5gNrBsPs/fwk/L2/rlc
*/


#include "wn5gNrPsRlcUMApi.h"


/**
 * @brief To Allocate memory for RLC UM 12 Header
 *
 * @param pktBuf
 * @returns rlcUm12HdrP
 */
wnRlcUm12HdrP wnRlcUM12HdrAlloc( ngPkt **pktBuf )
{
    wnRlcUm12HdrP   rlcUm12HdrP;

    /* Allocated Memory for 12 Header in mBuf using prepend */
    rlcUm12HdrP = ( wnRlcUm12HdrP ) ngPktPrepend ( *pktBuf, 
                                   sizeof( wnRlcUm12HdrT ) );
    if( NULL == rlcUm12HdrP )
    {
        WN_LOG_DEBUG("Memory Allocation failed");
        return WN_RETNULL; /* Memory Allocation Failed */
    }

    return rlcUm12HdrP;
}


/**
 * @brief To Initialise for RLC UM 12 Header
 *
 * @param rlcUm12HdrP
 * @param si: Segement Info
 * @returns rlcUm12HdrP
 */
wnRlcUm12HdrP wnRlcUM12HdrInit( wnRlcUm12HdrP *rlcUm12HdrP, wnUInt16 si, wnUInt8 res, wnUInt16 sn, wnUInt16 so )
{
    if (NULL == *rlcUm12HdrP) {
        WN_LOG_DEBUG("Input RLC UM Hdr is NULL \n");
        return WN_RETNULL;
    }

    /* Fields in 12 Header */
    (*rlcUm12HdrP)->si         = si;
    //*rlcUm12HdrP->res        = RES;
    (*rlcUm12HdrP)->sn         = sn;
    (*rlcUm12HdrP)->so         = so;
    
    /* Returns as rlcUm12Hdr */
    return *rlcUm12HdrP;
}


/**
 * @brief To Allocate memory  for RLC UM Seg6 Header
 *
 * @param pktBuf
 * @returns rlcUm6HdrP
 */
wnRlcUm6HdrP wnRlcUM6HdrAlloc( ngPkt **pktBuf )
{
    wnRlcUm6HdrP   rlcUm6HdrP;

    /* Allocated Memory for 6 Header in mBuf using prepend */
    rlcUm6HdrP = ( wnRlcUm6HdrP )ngPktPrepend( *pktBuf, sizeof( wnRlcUm6HdrT ) );
    if( NULL == rlcUm6HdrP )
    {
        WN_LOG_DEBUG("Memory Allocation failed");
        return WN_RETNULL; /* Memory Allocation Failed */
    }
    
    return rlcUm6HdrP; 
}


/**
 * @brief To Initialise for RLC UM Seg6 Header
 *
 * @param rlcUm6HdrP
 * @param si: Segement Info
 * @param so: Segement Offset
 * @param sn: Sequence Number
 * @returns rlcUm6HdrP
 */
wnRlcUm6HdrP wnRlcUM6HdrInit( wnRlcUm6HdrP *rlcUm6HdrP, wnUInt16 si, wnUInt16 sn, wnUInt16 so )
{
    if (NULL == *rlcUm6HdrP) {
        WN_LOG_DEBUG("Input RLC UM Hdr is NULL \n");
        return WN_RETNULL;
    }
    /* Fields in UM Seg6 Header*/
    (*rlcUm6HdrP)->si         = si;
    (*rlcUm6HdrP)->sn         = sn;
    (*rlcUm6HdrP)->so         = so;
    
    return *rlcUm6HdrP;
}


/**
 * @brief To Allocate memory  for RLC UM Header
 *
 * @param pktBuf
 * @returns rlcUm6HdrP
 */
#if 0
bool wnRlcUMHdr( ngPkt **pktBuf )
{
    wnRlcUmIHdrP rlcUMHdrP;

    /* Allocated Memory for Initial Header in mBuf using prepend */
    rlcUMHdrP = ( wnRlcUmIHdrP )ngPktPrepend( *pktBuf, sizeof( wnRlcUmIHdrT ) );
    if( NULL == rlcUMHdrP )
    {
        WN_LOG_DEBUG("Memory Allocation failed");
        return WN_RETNULL; /* Memory Allocation Failed */
    }
    
    return rlcUMHdrP;
}
#endif

/**
 * @brief API for Update Si
 *
 * @param umHdr
 * @param Si: Segement Info
 * @param SnType
 * @returns umHdr
 */
wnUInt8 wnRlcUmUpdateSi( wnRlcUmHdrP *umHdr, wnUInt16 Si, wnUInt8 SnType )
{
    if (NULL == *umHdr) {
        WN_LOG_DEBUG("Input RLC UM Hdr is NULL \n");
        return WN_RETINVD;
    }

    if( SnType == SN12 )
    	return ((*umHdr)->rlcUm12HdrP->si = Si);
    if( SnType == SN6 )
        return ((*umHdr)->rlcUm6HdrP->si = Si);
    else
        return WN_RETINVD;
}


/**
 * @brief API for Update So
 *
 * @param umHdr
 * @param So: Segment Offset
 * @param SnType
 * @returns umHdr
 */
wnUInt8 wnRlcUmUpdateSo( wnRlcUmHdrP *umHdr, wnUInt16 So, wnUInt8 SnType )
{
    if (NULL == *umHdr) {
        WN_LOG_DEBUG("Input RLC UM Hdr is NULL \n");
        return WN_RETINVD;
    }

    if( SnType == SN12 )
    	return ((*umHdr)->rlcUm12HdrP->so = So);
    if( SnType == SN6 )
        return ((*umHdr)->rlcUm6HdrP->so = So);
    else
        return WN_RETINVD;
}


/**
 * @brief API for Update Sn
 *
 * @param umHdr
 * @param Sn: Sequence Number
 * @param SnType
 * @returns umHdr
 */
wnUInt8 wnRlcUmUpdateSn( wnRlcUmHdrP *umHdr, wnUInt16 Sn, wnUInt8 SnType )
{
    if (NULL == *umHdr) {
        WN_LOG_DEBUG("Input RLC UM Hdr is NULL \n");
        return WN_RETINVD;
    }

    if( SnType == SN12 )
    	return ((*umHdr)->rlcUm12HdrP->sn = Sn);
    if( SnType == SN6 )
        return ((*umHdr)->rlcUm6HdrP->sn = Sn);
    else
        return WN_RETINVD;
}
