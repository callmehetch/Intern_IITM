/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wn5gNrPsPdcp.h
 * @author Manoj Kumar
 * @brief Header file of PDCP APIs for Framework ( Initial Version )
 *
 * @details it is common to both gNB & UE
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/pdcp/pdcp
 */

/**
 * wn5gNrPsDataTypes.h may be change, it would be decided by WiSig networks
 */

#ifndef __WN_5GNR_PDCP_H__
#define __WN_5GNR_PDCP_H__

#include "wn5gNrPsPdcpHdr.h"
#include "../../common/ngPkt/wnNgPktApi.h"

wnPdcpUHdr18DrbP wn5gNrPdcpUHdr18DrbAlloc ( ngPkt **pkt);
wnPdcpUHdr18DrbP wn5gNrPdcpUHdr18DrbInit ( wnPdcpUHdr18DrbP pdcpUHdr18Drb, wnUInt8 ,\
                                           wnUInt8, wnUInt32 );

wnPdcpUHdr12DrbP wn5gNrPdcpUHdr12DrbAlloc ( ngPkt **pkt );
wnPdcpUHdr12DrbP wn5gNrPdcpUHdr12DrbInit ( wnPdcpUHdr12DrbP pdcpUHdr12Drb, wnUInt8,\
                                           wnUInt8, wnUInt16 );

wnPdcpCHdr12SrbP wn5gNrPdcpCHdr12SrbAlloc (ngPkt **pkt);
wnPdcpCHdr12SrbP wn5gNrPdcpCHdr12SrbInit ( wnPdcpCHdr12SrbP pdcpCHdr12Srb, wnUInt8,\
                                           wnUInt16 );

wnPdcpCStatusRepP wn5gNrPdcpCStsRepAlloc (ngPkt **pkt);
wnPdcpCStatusRepP wn5gNrPdcpCStsRepInit (wnPdcpCStatusRepP pdcpCStatusRep, wnUInt8,\
                                         wnUInt8, wnUInt8 );

wnPdcpCRohcFdbkP wn5gNrPdcpCRohcFdbkAlloc ( ngPkt **pkt);
wnPdcpCRohcFdbkP wn5gNrPdcpCRohcFdbkInit ( wnPdcpCRohcFdbkP pdcpCRohcFdbk, wnUInt8,\
                                           wnUInt8, wnUInt8 );

wnInt8 wn5gNrPdcpSetSeqNo ( void * hdr, wnUInt32 sno, wnPdcpHdrTypeE hdrType);

wnInt8 wn5gNrPdcpSetResBits ( void * hdr, wnUInt8 resv, wnPdcpHdrTypeE hdrType);

wnInt8 wn5gNrPdcpSetDcBit ( void * hdr, wnUInt8 d_c, wnPdcpHdrTypeE hdrType);

#endif /*__WN_5GNR_PDCP_H__*/
