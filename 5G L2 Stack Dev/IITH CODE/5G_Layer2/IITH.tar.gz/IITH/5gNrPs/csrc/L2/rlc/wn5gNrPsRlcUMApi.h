/*****************************************************************************
* Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
* www.wisig.com                                                             *
*                                                                           *
* All information contained herein is property of WiSig Networks Pvt Ltd.   *
* unless otherwise explicitly mentioned.                                    *
*                                                                           *
* The intellectual and technical concepts in this file are proprietary      *
* to WiSig Networks and may be covered by granted or in process national    *
* and international patents and are protect by trade secrets and            *
* copyright law.                                                            *
*                                                                           *
* Redistribution and use in source and binary forms of the content in       *
* this file, with or without modification are not permitted unless          *
* permission is explicitly granted by WiSig Networks.                       *
* If WiSig Networks permits this source code to be used as a part of        *
* open source project, the terms and conditions of CC-By-ND (No Derivative) *
* license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
*****************************************************************************/

/**
* @file wn5gNrPsRlcUMApi.h
* @author Venkat Rahul
* @brief Declarations for RLC UM API's, it is common for UE and gNB
*
* @see http://git.wisig.com/root/5gNrBsPs/fwk/L2/rlc
*/

#ifndef __WN_5G_NR_RLC_UM_API_H__
#define __WN_5G_NR_RLC_UM_API_H__

#include "wn5gNrPsRlcUM.h"


wnRlcUm12HdrP wnRlcUM12HdrAlloc( ngPkt **pktBuf );
wnRlcUm12HdrP wnRlcUM12HdrInit( wnRlcUm12HdrP *rlcUm12HdrP, wnUInt16 si, wnUInt8 res, wnUInt16 sn, wnUInt16 so );
wnRlcUm6HdrP wnRlcUM6HdrAlloc( ngPkt **pktBuf );
wnRlcUm6HdrP wnRlcUM6HdrInit( wnRlcUm6HdrP *rlcUm6HdrP, wnUInt16 si, wnUInt16 sn, wnUInt16 so );
wnUInt8      wnRlcUmUpdateSi( wnRlcUmHdrP *umHdr, wnUInt16 Si, wnUInt8 SnType );
wnUInt8      wnRlcUmUpdateSo( wnRlcUmHdrP *umHdr, wnUInt16 So, wnUInt8 SnType );
wnUInt8      wnRlcUmUpdateSn( wnRlcUmHdrP *umHdr, wnUInt16 Sn, wnUInt8 SnType );

#endif /* __WN_5G_NR_RLC_UM_API_H__ */
/* EOF */
