/*copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/
/**
 * @file wn5gNrPsMacDlRarApi.h
 * @author Nikita Mudkanna
 * @brief file containing APIs for Mac Dl Rar Protocol Headers
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/mac/mac
 */

#ifndef __WN_5G_NR_PS_MAC_DL_RAR_API_H__
#define __WN_5G_NR_PS_MAC_DL_RAR_API_H_

#include "wn5gNrPsMacDlRarHeader.h"


/** Prototypes of APIs for MAC Rar Dl protocol Header */

wnMacRarBiSbHdrP wnMacRarBiHdrAlloc ( ngPkt **pktBuf );
wnMacRarBiSbHdrP wnMacRarBiHdrInit ( wnMacRarBiSbHdrP *macRarHdr ,
                               wnUInt8 ext, wnUInt8 type, wnUInt8 bckoffInd );
wnUInt8 wnMacRarBiHdrExt ( wnMacRarBiSbHdrP mac, wnUInt8 ext );
wnUInt8 wnMacRarBiHdrType ( wnMacRarBiSbHdrP mac, wnUInt8 type );
wnUInt8 wnMacRarBiHdrBckOffInd ( wnMacRarBiSbHdrP mac, wnUInt8 bckoffInd );

wnMacRarRapidSbHdrP wnMacRarRapidHdrAlloc ( ngPkt **pktBuf );
wnMacRarRapidSbHdrP wnMacRarRapidHdrInit ( wnMacRarRapidSbHdrP *macRapidHdr, 
                                wnUInt8 ext, wnUInt8 type, wnUInt8 rapremId );
wnUInt8 wnMacRarRapidHdrExt ( wnMacRarRapidSbHdrP mac, wnUInt8 ext );
wnUInt8 wnMacRarRapidHdrType ( wnMacRarRapidSbHdrP mac, wnUInt8 type );
wnUInt8 wnMacRarRapidHdrRapremId ( wnMacRarRapidSbHdrP mac,
                                   wnUInt8 rapremId );

#endif /** __WN_5G_NR_PS_MAC_DL_RAR_API_H_ */

/** EOF */
