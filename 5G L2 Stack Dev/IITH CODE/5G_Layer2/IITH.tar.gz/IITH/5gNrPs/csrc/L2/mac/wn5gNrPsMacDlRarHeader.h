/*****************************************************************************
* copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
* www.wisig.com                                                             *
*                                                                           *
* All information contained herein is property of WiSig Networks Pvt Ltd.   *
* unless otherwise explicitly mentioned.                                    *
*                                                                           *
* The intellectual and technical concepts in this file are proprietary      *
* to WiSig Networks and may be covered by granted or in process national    *
* and international patents and are protect by trade secrets and            *
* copyright law.                                                            *
*                                                                           *
* Redistribution and use in source and binary forms of the content in       *
* this file, with or without modification are not permitted unless          *
* permission is explicitly granted by WiSig Networks.                       *
* If WiSig Networks permits this source code to be used as a part of        *
* open source project, the terms and conditions of CC-By-ND (No Derivative) *
* license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
*****************************************************************************/  


/**
 * @file wn5gNrPsMacDlHeaders.h
 * @author Balu
 * @brief Mac Headers and Pdu structures.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/mac/mac
 */


#ifndef __WN_5G_NR_PS_MAC_DL_HEADERS_H__
#define __WN_5G_NR_PS_MAC_HEADERS_H_


#include "../../common/inc/wnBsPsDataTypes.h"
#include "../../common/inc/wnBsPsErrTypes.h"
#include "../../common/inc/wnBsPsFwk.h"
#include "../../common/ngPkt/wnNgPktApi.h"


#define EXT0                    0
#define EXT1                    1
#define TYPE0                   0
#define TYPE1                   1
#define BACK_OFF_IND0           5
#define BACK_OFF_IND1           10
#define BACK_OFF_IND2           20
#define BACK_OFF_IND3           30
#define BACK_OFF_IND4           40
#define BACK_OFF_IND5           60
#define BACK_OFF_IND6           80
#define BACK_OFF_IND7           120
#define BACK_OFF_IND8           160
#define BACK_OFF_IND9           240
#define BACK_OFF_IND10          320
#define BACK_OFF_IND11          480
#define BACK_OFF_IND12          960
#define BACK_OFF_IND13          1920
#define RA_PREM_ID0             0 
#define RA_PREM_ID1             1
#define RA_PREM_ID2             2
#define RA_PREM_ID3             3
#define RA_PREM_ID4             4 
#define RA_PREM_ID5             5
#define RA_PREM_ID6             6
#define RA_PREM_ID7             7
#define RA_PREM_ID8             8
#define RA_PREM_ID9             9
#define RA_PREM_ID10            10
#define RA_PREM_ID11            11
#define RA_PREM_ID12            12
#define RA_PREM_ID13            13
#define RA_PREM_ID14            14
#define RA_PREM_ID15            15
#define RA_PREM_ID16            16
#define RA_PREM_ID17            17
#define RA_PREM_ID18            18
#define RA_PREM_ID19            19
#define RA_PREM_ID20            20
#define RA_PREM_ID21            21
#define RA_PREM_ID22            22
#define RA_PREM_ID23            23
#define RA_PREM_ID24            24
#define RA_PREM_ID25            25
#define RA_PREM_ID26            26
#define RA_PREM_ID27            27
#define RA_PREM_ID28            28
#define RA_PREM_ID29            29
#define RA_PREM_ID30            30
#define RA_PREM_ID31            31
#define RA_PREM_ID32            32
#define RA_PREM_ID33            33
#define RA_PREM_ID34            34
#define RA_PREM_ID35            35
#define RA_PREM_ID36            36        
#define RA_PREM_ID37            37
#define RA_PREM_ID38            38
#define RA_PREM_ID39            39
#define RA_PREM_ID40            40
#define RA_PREM_ID41            41
#define RA_PREM_ID42            42
#define RA_PREM_ID43            43
#define RA_PREM_ID44            44
#define RA_PREM_ID45            45
#define RA_PREM_ID46            46
#define RA_PREM_ID47            47
#define RA_PREM_ID48            48  
#define RA_PREM_ID49            49
#define RA_PREM_ID50            50
#define RA_PREM_ID51            51
#define RA_PREM_ID52            52
#define RA_PREM_ID53            53
#define RA_PREM_ID54            54
#define RA_PREM_ID55            55
#define RA_PREM_ID56            56
#define RA_PREM_ID57            57
#define RA_PREM_ID58            58
#define RA_PREM_ID59            59
#define RA_PREM_ID60            60
#define RA_PREM_ID61            61
#define RA_PREM_ID62            62
#define RA_PREM_ID63            63


/**
 * @brief, The data structure of MAC header of Random Access Response(RAR)
 *  for backoff indicator (BI).
 *
 * 3GPP TS 38.321 (Rel 15 Ver : 15.3.0)
 * Procedure : 6.1.5-1
 */
typedef struct wnMacRarBiSbHdr
{
    wnUInt8 ext: 1;   /*! Field set to "1"->atleast another MAC SubPDU follows
                          "0"->indicates MAC subPDU including this MAC subhdr
                          is the last MAC subPDU in the MAC PDU */
    wnUInt8 type: 1;  /*! Field set to "0"->backoff indicator field in subhdr
                          "1"->Random Access Preamble ID field in subheader */
    wnUInt8 res: 2;   /*! Reserved bit, set to "0" */
    wnUInt8 bckoffInd:4; /*! Field identifies overload condition in the cell */
} wnMacRarBiSbHdrT,
 *wnMacRarBiSbHdrP;


/**
 * @brief, The data structure of MAC header of Random Access Response for
 * Random access preamble identifier (RAPID).
 *
 * 3GPP TS 38.321 (Rel 15 Ver : 15.3.0)
 * Procedure : 6.1.5-2
 */
typedef struct wnMacRarRapidSbHdr
{
    wnUInt8 ext: 1;  /*! Field set to "1"->another MAC subPDU follows
                         "0"->MAC subPDU including this MAC subhedr is the last
                         MAC subPDU in the MAC PDU */
    wnUInt8 type: 1; /*! Field set to "0"->backoff indicator field in subheader
                         "1"->Random Access Preamble Id field in subheader */
    wnUInt8 raPreamId: 6; /*! Field indicates the tx Random Access Preamble */
} wnMacRarRapidSbHdrT,
 *wnMacRarRapidSbHdrP;

#endif  /** __WN_5G_NR_PS_MAC_HEADERS_H_ */

/** EOF */

