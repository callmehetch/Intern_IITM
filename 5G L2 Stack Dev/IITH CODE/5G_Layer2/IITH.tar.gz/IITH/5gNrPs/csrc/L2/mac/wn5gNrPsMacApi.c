/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/
/**
 * @file wn5gNrPsMacApi.c
 * @author Nikita Mudkanna
 * @brief file containing APIs for mac Protocol Header.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/mac/mac
 */

#include "wn5gNrPsMacApi.h"

/** TODO: There are 3 lcid update functions, integrate all into one
    Those functions are redundant */

/**
 * @brief To allocate memory for Mac subheader with 8 bit L field
 *
 * @param pktBuf Input ngPkt buffer
 * @returns  wnMacSch8bSbHdrP or NULL
 */
wnMacSch8bSbHdrP wnMac8bHdrAlloc( ngPkt **pktBuf )
{
    wnMacSch8bSbHdrP macDl8bHdr;
    hdrInfoP p;

    /** Allocates memory for mac 8 bit Header */
    macDl8bHdr = ( wnMacSch8bSbHdrP ) ngPktPrepend ( *pktBuf,
                                    sizeof( struct wnMacSch8bSbHdr ));
    if ( NULL == macDl8bHdr ) {
        WN_LOG_DEBUG("Failed to allocate memory for MAC \
                      subheader with 8 bit L field\n");
        return WN_RETNULL;        /** Memory allocation failed  */
    }

    p = wnGetHdrInfoFromMbuf(*pktBuf);
    //memset(p, 0, sizeof(hdrInfoT));
    p->hdrmap |= MACHDR_PRSNT;
    p->hdrLoc[MACHDR_LOC] = macDl8bHdr;

    return macDl8bHdr;            /** Memory allocated successfully  */
}


/**
 * @brief To initialize the mac 8 bit Dl header
 *
 * @param macDl8bDlHdr : Mac header structure pointer
 * @param format  :  Header Length field
 * @param lcid    :  Logical channel ID
 * @param len     :  Length of MAC SDU or variable-sized MAC CE
 * @returns wnMacSch8bSbHdrP or WN_RET_NULL
 */
wnMacSch8bSbHdrP wnMac8bHdrInit ( wnMacSch8bSbHdrP *macDl8bHdr, wnUInt8 format,
                                  wnUInt8 lcid, wnUInt8 len )
{
    if (NULL == *macDl8bHdr) {
        WN_LOG_DEBUG("Input MAC header is NULL\n");
        return WN_RETNULL;
    }

    /** Initialize Mac DL header with 8-bit L field  */
    (*macDl8bHdr)->format        = format;
    (*macDl8bHdr)->lcid          = lcid;
    (*macDl8bHdr)->len           = len;
    

    return *macDl8bHdr;
}


/*
 * @brief Update format
 *
 * @param mac    : Mac header structure pointer
 * @param format : Header Length field
 * @returns wnUInt8 or 0
 */
wnUInt8 wnMac8bHdrFrmt ( wnMacSch8bSbHdrP mac, wnUInt8 format )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETINVD; /** TODO: Check the return value expected */
    }

    return (mac->format = format);
}


/*
 * @brief Update Lcid
 *
 * @param mac  : Mac header structure pointer
 * @param lcid : Logical channel ID
 * @returns wnUInt8 or 0
 */
wnUInt8 wnMac8bHdrLcid( wnMacSch8bSbHdrP mac, wnUInt8 lcid )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETINVD; /** TODO: Check the return value expected */
    }

    return (mac->lcid   = lcid);
}


/*
 * @brief Update Len
 *
 * @param mac : Mac header structure pointer
 * @param len : Length of MAC SDU or variable-sized MAC CE
 * @returns wnUInt8 or 0
 */
wnUInt8 wnMac8bHdrLen ( wnMacSch8bSbHdrP mac, wnUInt8 len )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETINVD; /** TODO: Check the return value expected */
    }

    #define MAC_MAX_LEN 64 /** TODO: Temporary fix */
    if (len == 0 || len > MAC_MAX_LEN) {
        WN_LOG_DEBUG("Invalid length parameter\n");
        return WN_RETINVD;
    }

    return (mac->len    = len);
}


/**
 * @brief To allocate memory for Mac subheader with 16 bit L field
 *
 * @param pktBuf
 * @returns  wnBsPsMacSch16bSbHdrP or WN_RET_NULL
 */
wnMacSch16bSbHdrP wnMac16bHdrAlloc ( ngPkt **pktBuf )
{
    wnMacSch16bSbHdrP macDl16bHdr;
    hdrInfoP p;
    /** Allocates memory for mac 16 bit Header */
    macDl16bHdr = ( wnMacSch16bSbHdrP ) ngPktPrepend ( *pktBuf,
                                          sizeof( struct wnMacSch16bSbHdr ) );
    if (NULL == macDl16bHdr )
        return WN_RETNULL;       /** Memory allocation failed */

    p = wnGetHdrInfoFromMbuf(*pktBuf);
    //memset(p, 0, sizeof(hdrInfoT));
    p->hdrmap |= MACHDR_PRSNT;
    p->hdrLoc[MACHDR_LOC] = macDl16bHdr;

    return macDl16bHdr;          /** Memory allocated successfully */
}


/**
 * @brief To initialize the mac 16 bit Dl header
 *
 * @param macDl16bDlHdr : Mac header structure pointer
 * @param format  : Header Length field
 * @param lcid    : Logical channel ID
 * @param lenMsb  : Len of MAC SDU or variable-sized MAC CE
 * @param lenLsb  : Len of MAC SDU or variable-sized MAC CE
 * @returns wnMacSch16bSbHdrP or WN_RET_NULL
 */
wnMacSch16bSbHdrP wnMac16bHdrInit ( wnMacSch16bSbHdrP *macDl16bHdr,
                wnUInt8 format, wnUInt8 lcid, wnUInt8 lenmsb, wnUInt8 lenlsb )
{
    if (NULL == *macDl16bHdr) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETNULL; /** TODO: Check the return value expected */
    }

    /** Initialize Mac DL header with 16-bit L field. */
    (*macDl16bHdr)->format        = format;
    (*macDl16bHdr)->lcid          = lcid;
    (*macDl16bHdr)->lenLsb        = lenlsb;
    (*macDl16bHdr)->lenMsb        = lenmsb;

    return *macDl16bHdr;
}


/*
 * @brief Update format
 *
 * @param mac    : Mac header structure pointer
 * @param format : Header Length field
 * @returns wnUInt8 or 0
 */
wnUInt8 wnMac16bHdrFrmt ( wnMacSch16bSbHdrP mac, wnUInt8 format )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETINVD; /** TODO: Check the return value expected */
    }
    return (mac->format = format);
}


/*
 * @brief Update Lcid
 *
 * @param mac  : Mac header structure pointer
 * @param lcid : Logical channel ID
 * @returns wnUInt8 or 0
 */
wnUInt8 wnMac16bHdrLcid ( wnMacSch16bSbHdrP mac, wnUInt8 lcid )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETINVD; /** TODO: Check the return value expected */
    }

    return (mac->lcid   = lcid);
}


/*
 * @brief Update LenLsb
 *
 * @param mac    : Mac header structure pointer
 * @param lenlsb : Length of MAC SDU or variable-sized MAC CE
 * @returns wnUInt8 or 0
 */
wnUInt8 wnMac16bHdrLenlsb ( wnMacSch16bSbHdrP mac, wnUInt8 lenlsb )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETINVD; /** TODO: Check the return value expected */
    }

    return (mac->lenLsb    = lenlsb);
}


/*
 * @brief Update LenMsb
 *
 * @param mac    : Mac header structure pointer
 * @param lenmsb : Length of MAC SDU or variable-sized MAC CE
 * @returns wnUInt8 or 0
 */
wnUInt8 wnMac16bHdrLenmsb ( wnMacSch16bSbHdrP mac, wnUInt8 lenmsb )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETINVD; /** TODO: Check the return value expected */
    }

    return (mac->lenMsb    = lenmsb);
}


/**
 * @brief To allocate memory for Mac fixed subheader
 *
 * @param pktBuf
 * @returns wnMacFixedSbHdrP or WN_RET_NULL
 */
wnMacFixedSbHdrP wnMacFixedHdrAlloc ( ngPkt **pktBuf )
{
    wnMacFixedSbHdrP macDlHdr;
    hdrInfoP p;
    /** Allocates memory for mac Fixed Header */
    macDlHdr = ( wnMacFixedSbHdrP ) ngPktPrepend ( *pktBuf,
                                        sizeof( struct wnMacFixedSbHdr ) );
    if (NULL == macDlHdr )
        return WN_RETNULL;       /** Memory allocation failed */

    p = wnGetHdrInfoFromMbuf(*pktBuf);
    //memset(p, 0, sizeof(hdrInfoT));
    p->hdrmap |= MACHDR_PRSNT;
    p->hdrLoc[MACHDR_LOC] = macDlHdr;

    return macDlHdr;              /** Memory allocated successfully */
}


/**
 * @brief To initialize the mac fixed subheader
 *
 * @param macDlHdr : Mac header structure pointer
 * @param lcid     : Logical channel ID
 * @returns wnMacFixedSbHdrP or WN_RET_NULL
 */
wnUInt8 wnMacFixedHdrInit ( wnMacFixedSbHdrP macDlHdr, wnUInt8 lcid )
{
    if (NULL == macDlHdr) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETINVD; /** TODO: Check the return value expected */
    }

    /** Initialize Mac FIXED DL header */
    return (macDlHdr->lcid = lcid);
}


/*
 * @brief Update Lcid
 *
 * @param mac  : Mac header structure pointer
 * @param lcid : Logical channel ID
 * @returns wnUInt8 or 0
 */
wnUInt8 wnMacFixedHdrLcid ( wnMacFixedSbHdrP mac, wnUInt8 lcid )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input MAC header is NULL \n");
        return WN_RETINVD; /** TODO: Check the return value expected */
    }

    return (mac->lcid   = lcid);
}

/** EOF */
