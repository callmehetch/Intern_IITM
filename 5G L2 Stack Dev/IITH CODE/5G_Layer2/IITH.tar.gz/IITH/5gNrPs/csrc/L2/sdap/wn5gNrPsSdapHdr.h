/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wnBsPsSdapHdr.h
 * @author RakeshReddy
 *
 * @brief Base Station Protocol Stack Sdap sub-layer structures
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/sdap/Sdap
 * @see http://www.wisig.com
 *
 */

#ifndef __WN_BS_PS_SDAP_HDR_H__
#define __WN_BS_PS_SDAP_HDR_H__


#include <stdlib.h>
#include <string.h>

#include "../../common/inc/wnBsPsDataTypes.h"
#include "../../common/inc/wnBsPsFwk.h"
#include "../../common/ngPkt/wnNgPktApi.h"

#define LIT_END 1

#define RQI0         0
#define RQI1         1

#define RDI0         0
#define RDI1         1

#define QFI0         0
#define QFI1         1
#define QFI2         2
#define QFI3         3
#define QFI4         4
#define QFI5         5
#define QFI6         6
#define QFI7         7
#define QFI8         8
#define QFI9         9
#define QFI10        10
#define QFI11        11
#define QFI12        12
#define QFI13        13
#define QFI14        14
#define QFI15        15
#define QFI16        16
#define QFI17        17
#define QFI18        18
#define QFI19        19
#define QFI20        20
#define QFI21        21
#define QFI22        22
#define QFI23        23
#define QFI24        24
#define QFI25        25
#define QFI26        26
#define QFI27        27
#define QFI28        28
#define QFI29        29
#define QFI30        30
#define QFI31        31
#define QFI32        32
#define QFI33        33
#define QFI34        34
#define QFI35        35
#define QFI36        36
#define QFI37        37
#define QFI38        38
#define QFI39        39
#define QFI40        40
#define QFI41        41
#define QFI42        42
#define QFI43        43
#define QFI44        44
#define QFI45        45
#define QFI46        46
#define QFI47        47
#define QFI48        48
#define QFI49        49
#define QFI50        50
#define QFI51        51
#define QFI52        52
#define QFI53        53
#define QFI54        54
#define QFI55        55
#define QFI56        56
#define QFI57        57
#define QFI58        58
#define QFI59        59
#define QFI60        60
#define QFI61        61
#define QFI62        62
#define QFI63        63

#if (!LIT_END)
/**
 * @brief DS of DL SDAP Data PDU Header (8-bits) & UL SDAP Data PDU Header &
 *  End-Marker Control PDU(8-bits).
 *  For Big Endian Systems
 */
typedef struct WN_PACKED wnSdapHdr
{
    wnUInt8 rdiDc : 1;	/** Reflective QoS flow DRB mapping Indication 0/1
                          * or indicates data PDU(1) or control PDU(0) */
    wnUInt8 rqiR  : 1;	/**< Reflective QoS Indication (0/1) or reserved bit */
    wnUInt8 qfi   : 6;	/**< QoS flow id */

} wnSdapHdrT,
 *wnSdapHdrP;
#endif

#if LIT_END
 /**
  * @brief DS of DL SDAP Data PDU Header (8-bits) & UL SDAP Data PDU Header &
  *  End-Marker Control PDU(8-bits).
  *  For Little Endian Systems
  */
 typedef struct WN_PACKED wnSdapHdr
 {
     wnUInt8 qfi   : 6;	/**< QoS flow id */
     wnUInt8 rqiR  : 1;	/**< Reflective QoS Indication (0/1) or reserved bit */
     wnUInt8 rdiDc : 1;	/** Reflective QoS flow DRB mapping Indication 0/1
                           * or indicates data PDU(1) or control PDU(0) */
 } wnSdapHdrT,
  *wnSdapHdrP;
#endif


/*
wnUChar* wnAddSdapDlGbrHdr (wnUInt8 ,wnUInt8 );
wnUChar* wnAddSdapDlHdr(wnUInt8 ,wnUInt8 ,wnBool );
wnVoid   wnRemSdapHdr(wnUChar* ); */ /**< remove SDAP header (UE/gNB) */

#endif /* __WN_BS_PS_SDAP_HDR_H__ */

/* EOF */
