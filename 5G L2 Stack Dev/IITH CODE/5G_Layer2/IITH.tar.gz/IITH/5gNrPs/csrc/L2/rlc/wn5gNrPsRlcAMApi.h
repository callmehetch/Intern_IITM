/*****************************************************************************
* Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
* www.wisig.com                                                             *
*                                                                           *
* All information contained herein is property of WiSig Networks Pvt Ltd.   *
* unless otherwise explicitly mentioned.                                    *
*                                                                           *
* The intellectual and technical concepts in this file are proprietary      *
* to WiSig Networks and may be covered by granted or in process national    *
* and international patents and are protect by trade secrets and            *
* copyright law.                                                            *
*                                                                           *
* Redistribution and use in source and binary forms of the content in       *
* this file, with or without modification are not permitted unless          *
* permission is explicitly granted by WiSig Networks.                       *
* If WiSig Networks permits this source code to be used as a part of        *
* open source project, the terms and conditions of CC-By-ND (No Derivative) *
* license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
*****************************************************************************/

/**
* @file wn5gNrPsRlcAMApi.h
* @author Venkat Rahul, Vishnu
* @brief Declarations for RLC AM API's, it is common for UE and gNB
*
* @see http://git.wisig.com/root/5gNrBsPs/fwk/L2/rlc
*/

#ifndef __WN_5G_NR_RLC_AM_API_H__
#define __WN_5G_NR_RLC_AM_API_H__

#include "wn5gNrPsRlcAM.h"

wnVoid* wnRlcAMHdrAlloc(ngPkt **pktBuf, wnRlcAmHdrE snType);
wnInt8 wnRlcAMHdrInit ( wnVoid *amHdr, wnInt8 dc,
                      wnInt8 poll, wnUInt16 si, wnUInt16 sn, wnUInt16 so,
					  wnRlcAmHdrE snType );
wnInt8     wnRlcSetDcBit ( wnVoid *amHdr, wnRlcAmHdrE snType );
wnInt8     wnRlcSetPollBit ( wnVoid *amHdr, wnInt8 Poll, wnRlcAmHdrE snType );
wnInt8     wnRlcUpdateSi ( wnVoid *amHdr, wnUInt16 Si, wnRlcAmHdrE snType );
wnInt8     wnRlcUpdateSo ( wnVoid *amHdr, wnUInt16 So, wnRlcAmHdrE snType );
wnInt8     wnRlcUpdateSn ( wnVoid *amHdr, wnUInt32 Sn, wnRlcAmHdrE snType );

#endif /* __WN_5G_NR_RLC_AM_API_H__ */
/* EOF */
