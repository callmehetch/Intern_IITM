/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/


/**
 * @file wn5gNrPsSdapApi.c
 * @author Nikita Mudkanna
 * @brief file containing APIs for Sdap Protocol Header.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/sdap/sdap
 */

#include "wn5gNrPsSdapApi.h"


/**
 * @brief To allocate memory for Sdap Header 
 *
 * @param pktBuf
 * @returns wnSdapHdrP or WN_RET_NULL
 */
wnSdapHdrP wnSdapHdrAlloc ( ngPkt **pktBuf )
{
    wnSdapHdrP sdapHdrP;
    hdrInfoP p;

    /** Allocates memory for Sdap Header */
    sdapHdrP = ( wnSdapHdrP ) ngPktPrepend( *pktBuf, 
                                       sizeof( struct wnSdapHdr ) );
    if (NULL == sdapHdrP )
        return WN_RETNULL;     /** Memory allocation failed */

    p = wnGetHdrInfoFromMbuf(*pktBuf);
    //memset(p, 0, sizeof(hdrInfoT));
    p->hdrmap |= SDAPHDR_PRSNT;
    p->hdrLoc[SDAPHDR_LOC] = sdapHdrP; 

    return sdapHdrP;           /** Memory allocated successfully */
}


/**
 * @brief To initialize the sdap Dl header
 *
 * @param sdapHdrP
 * @param rqi  : 1 bit
 * @param qfi  : 6 bits
 * @param rdi  : 1 bit
 * @returns wnSdapHdrP or WN_RET_NULL
 */
wnSdapHdrP wnSdapHdrInit ( wnSdapHdrP *sdapHdrP, wnUInt8 rqi,
                           wnUInt8 qfi, wnUInt8 rdi )
{
    if (NULL == *sdapHdrP) {
        WN_LOG_DEBUG("");
        return WN_RETNULL;
    }

    /** Initialize sdap DL header */
    (*sdapHdrP)->rqiR    = rqi;
    (*sdapHdrP)->qfi     = qfi;
    (*sdapHdrP)->rdiDc   = rdi;
    
    return sdapHdrP;
}


/**
 * @brief Update qfi
 *
 * @param sdap : Sdap header structure pointer
 * @param qfi  : Qos flow ID
 * @returns wnUInt8 or 0
 */
wnUInt8 wnSdapHdrQfi ( wnSdapHdrP *sdap, wnUInt8 qfi )
{
    if (NULL == sdap) 
        return WN_FAILURE;
    else
        return ((*sdap)->qfi    = qfi); 
}


/**
 *@brief Update rqi
 *
 * @param sdap : Sdap header structure pointer
 * @param rqi  : Reflective Qos Indication or Reserved bit
 * @returns wnUInt8 or 0
 */
wnUInt8 wnSdapHdrRqi ( wnSdapHdrP *sdap, wnUInt8 rqi )
{
    if (NULL == sdap) 
        return WN_FAILURE;
    else
        return ((*sdap)->rqiR    = rqi); 
}


/*
 *@brief Update rdi
 *
 * @param sdap : Sdap header structure pointer
 * @param rdi  : Reflective Qos flow DRB mapping Indication or Indicates
 *  Data PDU(0) or control PDU(1)
 * @returns wnUInt8 or 0
 */
wnUInt8 wnSdapHdrRdi ( wnSdapHdrP *sdap, wnUInt8 rdi )
{
    if (NULL == *sdap) 
        return WN_FAILURE;
    else
    return ((*sdap)->rdiDc    = rdi); 
}

/* EOF */
