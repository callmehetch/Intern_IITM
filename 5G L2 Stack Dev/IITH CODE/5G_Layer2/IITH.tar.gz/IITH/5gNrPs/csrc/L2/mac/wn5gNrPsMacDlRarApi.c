/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/
/**
 * @file wn5gNrPsMacDlRarApi.c
 * @author Nikita Mudkanna
 * @brief file containing APIs for mac Protocol Header.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/mac/mac
 */

#include "wn5gNrPsMacDlRarApi.h"

/**                                                                            
 * @brief To allocate memory for Mac Rar Back-Off Indicator subheader               
 *                                                                             
 * @param pktBuf                                                               
 * @returns  wnMacRarBiSbHdrP or NULL                            
 */
wnMacRarBiSbHdrP wnMacRarBiHdrAlloc ( ngPkt **pktBuf )
{
    wnMacRarBiSbHdrP macRarHdr;
    /** Allocates memory for mac RarBi subheader */
    macRarHdr = ( wnMacRarBiSbHdrP ) ngPktPrepend ( *pktBuf,
                                      sizeof( struct wnMacRarBiSbHdr ) );
    if (NULL == macRarHdr )
        return WN_RETNULL;      /** Memory allocation failed */
    return macRarHdr;           /** Memory allocated successfully */
}
                                                  
                             
/**                                                                            
 * @brief To initialize  mac Rar BackOff indicator subheader                                
 *                                                                             
 * @param macRarHdr   : Mac header structure pointer                                                          
 * @param ext         : Field set to "1"->atleast another MAC SubPDU follows
                          "0"->indicates MAC subPDU including this MAC subhdr
                          is the last MAC subPDU in the MAC PDU                                                       
 * @param type        : Field set to "0"->backoff indicator field in subhdr
                          "1"->Random Access Preamble ID field in subheader                                                        
 * @param bckoffInd   : Field identifies overload condition in the cell                                                       
 * @returns wnMacRarBiSbHdrP or WN_RETNULL                                                  
 */    
wnMacRarBiSbHdrP wnMacRarBiHdrInit ( wnMacRarBiSbHdrP *macRarHdr,           
                              wnUInt8 ext, wnUInt8 type, wnUInt8 bckoffInd )                                                    
{
    if (NULL == *macRarHdr) {
        WN_LOG_DEBUG("Input RAR Hdr is NULL \n");
        return WN_RETNULL;
    }    
 
    /* Initialize Mac RarBi subheader */
    (*macRarHdr)->ext        = ext; 
    (*macRarHdr)->type       = type; 
    (*macRarHdr)->bckoffInd  = bckoffInd; 
    
    return *macRarHdr;         /** Memory allocated successfully */  
}  


/*                                                                             
 * @brief Update ext                                                          
 *                                                                             
 * @param mac : Mac header structure pointer                                                                 
 * @param ext : Field set to "1"->atleast another MAC SubPDU follows  
                "0"->indicates MAC subPDU including this MAC subhdr  
                is the last MAC subPDU in the MAC PDU                                                                  
 * @returns wnUInt8 or 0                                                            
 */
wnUInt8 wnMacRarBiHdrExt ( wnMacRarBiSbHdrP mac, wnUInt8 ext )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input Rar Hdr is NULL \n");
        return WN_RETINVD;
    }
    return (mac->ext    = ext);
}


/*                                                                             
 * @brief Update Type                                                          
 *                                                                             
 * @param mac  : Mac header structure pointer                                                                  
 * @param type : Field set to "0"->backoff indicator field in subhdr    
                 "1"->Random Access Preamble ID field in subheader                                                                  
 * @returns wnUInt8 or 0
 */
wnUInt8 wnMacRarBiHdrType ( wnMacRarBiSbHdrP mac, wnUInt8 type )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input Rar Hdr is NULL \n");
        return WN_RETINVD;
    }

    return (mac->type    = type);
}


/*                                                                             
 * @brief Update Back off Indicator                                                          
 *                                                                             
 * @param mac       : Mac header structure pointer                                                           
 * @param bckoffInd : Field identifies overload condition in the cell                                                                 
 * @returns wnUInt8 or 0                                                           
 */
wnUInt8 wnMacRarBiHdrBckOffInd ( wnMacRarBiSbHdrP mac, wnUInt8 bckoffInd )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input Rar Hdr is NULL \n");
        return WN_RETINVD;
    }

    return (mac->bckoffInd    = bckoffInd);
}



/**                                                                            
 * @brief To allocate memory for Mac RarRapid subheader               
 *                                                                             
 * @param pktBuf                                                               
 * @returns  wnMacRarRapidSbHdrP or WN_RET_NULL                                               
 */
wnMacRarRapidSbHdrP wnMacRarRapidHdrAlloc ( ngPkt **pktBuf )
{
    wnMacRarRapidSbHdrP macRapidHdr;
    /** Allocates memory for mac RarRapid subheader */
    macRapidHdr = ( wnMacRarRapidSbHdrP ) ngPktPrepend ( *pktBuf,
                                sizeof( struct wnMacRarRapidSbHdr ) );
    if (NULL == macRapidHdr )
        return WN_RETNULL;       /** Memory allocation failed */
    return macRapidHdr;          /** Memory allocated successfully */
}


/**                                                                            
 * @brief To initialize  mac Rar Rapid subheader                                   
 *                                                                             
 * @param macRapidHdr : Mac header structure pointer                                                             
 * @param ext         : Field set to "1"->another MAC subPDU follows
                        "0"->MAC subPDU including this MAC subhedr is the last
                         MAC subPDU in the MAC PDU                                                       
 * @param type        : Field set to "0"->backoff indicator field in subheader
                         "1"->Random Access Preamble Id field in subheader                                                    
 * @param rapremId    : Field indicates the tx Random Access Preamble                                                       
 * @returns wnMacRarRapidSbHdrP or WN_RET_NULL                                       
 */                                                                            
wnMacRarRapidSbHdrP wnMacRarRapidHdrInit ( wnMacRarRapidSbHdrP *macRapidHdr, 
                              wnUInt8 ext, wnUInt8 type, wnUInt8 rapremId )                    
{
    if (NULL == *macRapidHdr) {
        WN_LOG_DEBUG("Input RAR Hdr is NULL \n");
        return WN_RETNULL;
    }    

    /* Initialize Mac Rar Rapid header */
    (*macRapidHdr)->ext            = ext; 
    (*macRapidHdr)->type           = type; 
    (*macRapidHdr)->raPreamId      = rapremId; 

    return *macRapidHdr;
} 

/*                                                                             
 * @brief Update ext                                                          
 *                                                                             
 * @param mac : Mac header structure pointer                                                                  
 * @param ext : Field set to "1"->another MAC subPDU follows           
                "0"->MAC subPDU including this MAC subhedr is the last
                MAC subPDU in the MAC PDU                                                                  
 * @returns wnUInt8 or 0                                                      
 */
wnUInt8 wnMacRarRapidHdrExt ( wnMacRarRapidSbHdrP mac, wnUInt8 ext ) 
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input Rar Hdr is NULL \n");
        return WN_RETINVD;
    }

    return (mac->ext = ext);
}


/*                                                                             
 * @brief Update Type                                                          
 *                                                                             
 * @param mac : Mac header structure pointer                                                                  
 * @param type : Field set to "0"->backoff indicator field in subheader
                 "1"->Random Access Preamble Id field in subheader                                                                   
 * @returns wnUInt8 or 0                                                           
 */
wnUInt8 wnMacRarRapidHdrType ( wnMacRarRapidSbHdrP mac, wnUInt8 type )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input Rar Hdr is NULL \n");
        return WN_RETINVD;
    }

    return (mac->type    = type);
}
/*                                                                             
 * @brief Update Random access preamble ID                                                          
 *                                                                             
 * @param mac : Mac header structure pointer                                                                  
 * @param rapremId : Field indicates the tx Random Access Preamble                                                                  
 * @returns wnUInt8 or 0                                                            
 */
wnUInt8 wnMacRarRapidHdrRapremId ( wnMacRarRapidSbHdrP mac, 
                                   wnUInt8 rapremId )
{
    if (NULL == mac) {
        WN_LOG_DEBUG("Input Rar Hdr is NULL \n");
        return WN_RETINVD;
    }

    return (mac->raPreamId    = rapremId);
}

/** EOF */
