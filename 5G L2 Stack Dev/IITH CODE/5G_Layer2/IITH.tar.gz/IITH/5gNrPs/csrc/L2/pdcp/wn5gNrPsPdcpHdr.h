/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/


/**
 * @file wn5gNrPsPdcpHdr.h
 * @author Manoj Kumar
 *
 * @brief DS & function declaration of PDCP header for data and control
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/pdcp/pdcp
 * @see https://www.wisig.com
 */


#ifndef __WN_5GNR_PDCP_HDR_H__
#define __WN_5GNR_PDCP_HDR_H__

#include <stdio.h>
#include "../../common/inc/wnBsPsFwk.h"


#define WN_TYPE_DATA  1
#define WN_TYPE_CTRL  0

#define LIT_END 1

/**
 * @brief The below enum is used to check PDCP SN size.
 */
typedef enum wnPdcpSnSize
{
    WN_PDCP_SN_SIZE_INVALID_E = -1, /**< Invalid PDCP SN Size */
    WN_PDCP_SN_SIZE_12BITS_E = 1,   /**< PDCP SN Size 12 Bits */
    WN_PDCP_SN_SIZE_18BITS_E        /**< PDCP SN Size 18 Bits */
} wnPdcpSnSizeE;

 /**
  * @brief The enum to determine the type of Header
  */
 typedef enum wnPdcpHdrType {
     WN_PDCP_HDR_INVALID_E=-1,
     WN_PDCP_HDR_SRB12_E=1,
     WN_PDCP_HDR_DRB12_E,
     WN_PDCP_HDR_DRB18_E,
     WN_PDCP_HDR_ROHCHDR_E,
     WN_PDCP_HDR_STSREP_E
 } wnPdcpHdrTypeE;

#if (!LIT_END)
 /**
  * @brief The PDCP header with 12-bits PDCP SN for SRB.
  */
 typedef struct WN_PACKED wnPdcpCHdr12Srb
 {
     wnUInt8  res : 4;   /**< reserve bit */
     wnUInt16 sn  :12;   /**< 12-bit for PDCP SN */
 } wnPdcpCHdr12SrbT,
  *wnPdcpCHdr12SrbP;

/**
 * @brief The PDCP header with 12-bits PDCP SN for DRB
 */
typedef struct WN_PACKED wnPdcpUHdr12Drb
{
    wnUInt8  d_c : 1;   /**< User Plane or Control Plane */
    wnUInt8  res : 3;   /**< reserve bit */
    wnUInt16 sn  : 12;  /**< 12-bit for PDCP SN */
} wnPdcpUHdr12DrbT,
 *wnPdcpUHdr12DrbP;


/**
 * @brief The PDCP header with 18-bits PDCP SN for DRB.
 */
typedef struct WN_PACKED wnPdcpUHdr18Drb
{
    wnUInt8  d_c : 1;    /**< User Plane or Control Plane */
    wnUInt8  res : 5;    /**< reserve bit */
    wnUInt32 sn  : 18;   /**< 18-bit for PDCP SN */
} wnPdcpUHdr18DrbT,
 *wnPdcpUHdr18DrbP;


/**
 * @brief The PDCP status report of Control PDU.
 */
typedef struct WN_PACKED wnPdcpCStatusRep
{
    wnUInt8  d_c     : 1;        /**< User Plane or Control Plane */
    wnUInt8  pduType : 3;        /**< To check PDU type */
    wnUInt8  res     : 4;        /**< reserve bit */
} wnPdcpCStatusRepT,
 *wnPdcpCStatusRepP;


/**
 * @brief PDCP Control PDU data structure for interspersed ROHC feedback
 */
typedef struct WN_PACKED wnPdcpCRohcFdbk
{
    wnUInt8 d_c     : 1;            /**< User Plane or Control Plane */
    wnUInt8 pduType : 3;            /**< To check PDU type */
    wnUInt8 res     : 4;            /**< reserve bit */
} wnPdcpCRohcFdbkT,
 *wnPdcpCRohcFdbkP;
#endif

#if (LIT_END)
 /**
  * @brief The PDCP header with 12-bits PDCP SN for SRB.
  */
 typedef struct WN_PACKED wnPdcpCHdr12Srb
 {
     wnUInt8  sn1 : 4;          /**< 4-bit for PDCP SN */
     wnUInt8  res   : 4;          /**< reserve bit */
     wnUInt8  sn2    ;          /**< 8-bit for PDCP SN */
 } wnPdcpCHdr12SrbT,
  *wnPdcpCHdr12SrbP;

/**
 * @brief The PDCP header with 12-bits PDCP SN for DRB
 */
typedef struct WN_PACKED wnPdcpUHdr12Drb
{
    wnUInt8  sn1   : 4;   /**< 12-bit for PDCP SN */
    wnUInt8  res     : 3;   /**< reserve bit */
    wnUInt8  d_c   : 1;   /**< User Plane or Control Plane */
    wnUInt8  sn2   ;      /**< 12-bit for PDCP SN */
} wnPdcpUHdr12DrbT,
 *wnPdcpUHdr12DrbP;


/**
 * @brief The PDCP header with 18-bits PDCP SN for DRB.
 */
typedef struct WN_PACKED wnPdcpUHdr18Drb
{
    wnUInt8  sn1   : 2;   /**< 18-bit for PDCP SN */
    wnUInt8  res     : 5;   /**< reserve bit */
    wnUInt8  d_c   : 1;   /**< User Plane or Control Plane */
    wnUInt8  sn2      ;   /**< 18-bit for PDCP SN */
    wnUInt8  sn3      ;   /**< 18-bit for PDCP SN */
} wnPdcpUHdr18DrbT,
 *wnPdcpUHdr18DrbP;


/**
 * @brief The PDCP status report of Control PDU.
 */
typedef struct WN_PACKED wnPdcpCStatusRep
{
    wnUInt8  res     : 4;        /**< reserve bit */
    wnUInt8  pduType : 3;        /**< To check PDU type */
    wnUInt8  d_c     : 1;        /**< User Plane or Control Plane */
} wnPdcpCStatusRepT,
 *wnPdcpCStatusRepP;


/**
 * @brief PDCP Control PDU data structure for interspersed ROHC feedback
 */
typedef struct WN_PACKED wnPdcpCRohcFdbk
{
    wnUInt8 res     : 4;          /**< reserve bit */
    wnUInt8 pduType : 3;          /**< To check PDU type */
    wnUInt8 d_c     : 1;          /**< User Plane or Control Plane */
} wnPdcpCRohcFdbkT,
 *wnPdcpCRohcFdbkP;
#endif


#endif /**< __WN_BSPS_PDCP_HDR_H__ */
/* EOF */
