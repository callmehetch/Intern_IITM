/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wn5gNrPsRlcUM.h
 * @author Mayur, Vishnu
 * @brief data structures and function declarations for incoming SDU
 *
 * @see http://git.wisig.com/root/5gNrBsPs/gNB/L2/rlc/csrc/
 */

#ifndef __WN_5G_NR_RLC_UM_H__
#define __WN_5G_NR_RLC_UM_H__

#include "../../common/inc/wnBsPsDataTypes.h"
#include "../../common/inc/wnBsPsFwk.h"
#include "../../common/ngPkt/wnNgPktApi.h"


#define SN12 12
#define SN6 6
#define RES 0
#define SN12 12
#define SN18 18
#define POLL0 0
#define POLL1 1
#define DC0 0
#define DC1 1
#define SI0 0
#define SI1 1
#define SI2 2
#define SI3 3


/**
 * @brief Enum for UM Hdr Type
 */
typedef enum wnRlcUmHdr {
    WN_RLC_UM_HDR_INVALID = -1,
    WN_RLC_UM_HDR_TYPE_1 = 1,      /*! 12 BIT HDR*/
    WN_RLC_UM_HDR_TYPE_2           /*! 18 BIT HDR*/
} wnRlcUmHdrE;


/**
 * @brief Structure to hold an Rlc UM PDU header with 12 bit Seq No.
 */
typedef struct WN_PACKED wnRlcUm12Hdr
{
    wnUInt8    si  :2;      /*! Segment Info */
    wnUInt8    res :2;      /*! Reserved bits */
    wnUInt16   sn  :12;     /*! Sequence number */
    wnUInt16   so;          /*! Segment offset-The SO field indicates
                                the position of the RLC SDU segment in
                                bytes within the original RLC SDU */
} wnRlcUm12HdrT,
  *wnRlcUm12HdrP;


/**
 * @brief Structure to hold an Rlc UM PDU header with 18 bit Seq No.
 */
typedef struct WN_PACKED wnRlcUm6Hdr
{
    wnUInt8     si  :2;     /*! Segment Info */
    wnUInt8     sn  :6;     /*! Sequence number */
    wnUInt16    so;         /*! Segment offset */
} wnRlcUm6HdrT,
 *wnRlcUm6HdrP;

 
 /**
 * @brief Structure to hold an Rlc UM PDU header without Seq no. when no segmentation
 */
typedef struct WN_PACKED RlcUmHdr
{
    wnUInt8     si  :2;     /*! Segment Info */
    wnUInt8    res  :6;     /*! reserved bits */
} wnRlcUmIHdrT,
  *wnRlcUmIHdrP;


/**
 * @brief union for RLC Um Hdr Type
 */
typedef union
{
    wnRlcUm12HdrP rlcUm12HdrP;
    wnRlcUm6HdrP  rlcUm6HdrP;
    wnRlcUmIHdrP   rlcUmHdr;
} wnRlcUmHdrT,
 *wnRlcUmHdrP;


#endif /* __WN_5G_NR_RLC_UM_H__ */

/*EOF*/
