/*copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/
/**
 * @file wn5gNrPsSdapApi.h
 * @author Nikita Mudkanna
 * @brief file containing prototype of APIs for sdap protocol Header
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/sdap/sdap
 */

#ifndef __WN_5G_NR_PS_SDAP_API_H__
#define __WN_5G_NR_PS_SDAP_API_H__

#include "wn5gNrPsSdapHdr.h"

/** All prototypes for sdap protocol header apis */

wnSdapHdrP wnSdapHdrAlloc ( ngPkt **pktBuf );
wnSdapHdrP wnSdapHdrInit ( wnSdapHdrP *sdapHdrP, \
                           wnUInt8 rqi, wnUInt8 qfi, wnUInt8 rdi );
wnUInt8 wnSdapHdrQfi ( wnSdapHdrP *sdap, wnUInt8 qfi );
wnUInt8 wnSdapHdrRqi ( wnSdapHdrP *sdap, wnUInt8 rqi );
wnUInt8 wnSdapHdrRdi ( wnSdapHdrP *sdap, wnUInt8 rdi );

#endif  /* __WN_BS_PS_SDAP_API_H__ */

/* EOF */
