/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wn5gNrPsRlcAM.h
 * @author Mayur, Vishnu
 * @brief data structures and function declarations for incoming SDU
 *
 * @see http://git.wisig.com/root/5gNrBsPs/fwk/L2/rlc
 */


#ifndef __WN_5G_NR_RLC_AM_H__
#define __WN_5G_NR_RLC_AM_H__

#define LIT_END 1

#include "../../common/inc/wnBsPsDataTypes.h"
#include "../../common/inc/wnBsPsFwk.h"

#define POLL0 0
#define POLL1 1
#define DC0 0
#define DC1 1
#define SI0 0
#define SI1 1
#define SI2 2
#define SI3 3

/**
 * @brief Enum for AM Hdr Type
 */
typedef enum wnRlcAmHdr {
    WN_RLC_AM_HDR_INVALID_ENUMVAL_E = -1,
    WN_RLC_AM_HDR_TYPE_1_ENUMVAL_E = 1, /**< 12 BIT HDR*/
    WN_RLC_AM_HDR_TYPE_2_ENUMVAL_E      /**< 18 BIT HDR*/
} wnRlcAmHdrE;

#if (!LIT_END)
/**
 * @brief Structure to hold an Rlc AM PDU header with 12 bit Seq No.
 */
typedef struct WN_PACKED wnRlcAm12Hdr
{
    wnUInt8     dc      :1;     /**< Data/Control bit*/
    wnUInt8     poll    :1;     /**< Poll bit*/
    wnUInt8     si      :2;     /**< Segment Info-The SI field indicates
                                    whether an RLC PDU contains a complete RLC
                                    SDU or the first, middle, last segment of
                                    an RLC SDU.*/
    wnUInt16    sn     :12;    /**< Sequence Number*/
//  wnUInt16    so     ;       /**< segment offset Disabled for now*/
} wnRlcAm12HdrT,
 *wnRlcAm12HdrP;


/**
 * @brief Structure to hold an Rlc AM PDU header with 18 bit Seq No.
 */
typedef struct WN_PACKED wnRlcAm18Hdr
{
    wnUInt8     dc      :1;     /**< Data/Control bit*/
    wnUInt8     poll    :1;     /**< Poll bit*/
    wnUInt8     si      :2;     /**< Segment Info-The SI field indicates
                                    whether an RLC PDU contains a complete RLC
                                    SDU or the first, middle, last segment of
                                    an RLC SDU.*/
    wnUInt8     re     : 2;
    wnUInt32    sn     :18;     /**< Sequence Number*/
//  wnUInt16    so     ;        /**< segment offset Disabled for now*/
} wnRlcAm18HdrT,
 *wnRlcAm18HdrP;
#endif

#if LIT_END
/**
* @brief Structure to hold an Rlc AM PDU header with 12 bit Seq No.
*/
 typedef struct WN_PACKED wnRlcAm12Hdr
{
   wnUInt8     sn1      :4;     /**< Sequence Number*/
   wnUInt8     si      :2;      /**< SI indicates the placeemnt of segment*/
   wnUInt8     poll    :1;      /**< Poll bit*/
   wnUInt8     dc      :1;      /**< Data/Control bit*/


   wnUInt8     sn2       ;      /**< Sequence Number*/
   //wnUInt16    so       ;     /**< Sequence Number disabled for now*/
} wnRlcAm12HdrT,
 *wnRlcAm12HdrP;

/**
* @brief Structure to hold an Rlc AM PDU header with 18 bit Seq No.
*/
typedef struct WN_PACKED wnRlcAm18Hdr
{
    wnUInt8     sn1     :4;      /**< Sequence Number*/
    wnUInt8     si      :2;      /**< SI indicates the placeemnt of segment*/
    wnUInt8     poll    :1;      /**< Poll bit*/
    wnUInt8     dc      :1;      /**< Data/Control bit*/
    wnUInt8     re      :2;
    wnUInt8     sn2       ;      /**< Sequence Number*/
    wnUInt8     sn3       ;      /**< Sequence Number*/
    // wnUInt16    so     ;      /**< Sequence Number*/
} wnRlcAm18HdrT,
 *wnRlcAm18HdrP;
#endif

#endif /* __WN_5G_NR_RLC_AM_H__ */

/*EOF*/
