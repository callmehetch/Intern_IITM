/*****************************************************************************
* copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
* www.wisig.com                                                             *
*                                                                           *
* All information contained herein is property of WiSig Networks Pvt Ltd.   *
* unless otherwise explicitly mentioned.                                    *
*                                                                           *
* The intellectual and technical concepts in this file are proprietary      *
* to WiSig Networks and may be covered by granted or in process national    *
* and international patents and are protect by trade secrets and            *
* copyright law.                                                            *
*                                                                           *
* Redistribution and use in source and binary forms of the content in       *
* this file, with or without modification are not permitted unless          *
* permission is explicitly granted by WiSig Networks.                       *
* If WiSig Networks permits this source code to be used as a part of        *
* open source project, the terms and conditions of CC-By-ND (No Derivative) *
* license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
*****************************************************************************/


/**
 * @file wnBsPsMacHeader.h
 * @author Bhavana
 * @brief Mac Headers and Pdu structures.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/mac/mac
 */

#ifndef __WN_BS_PS_MAC_HEADER_H__
#define __WN_BS_PS_MAC_HEADER_H_

#include "../../common/ngPkt/wnNgPktApi.h"

#define FORMAT_8_BIT                      0
#define FORMAT_16_BIT                     1
/** LCID VALUES for DL-SCH */
#define LCID_SRB_0                        0
#define LCID_SRB_1                        1
#define LCID_SRB_2                        2
#define LCID_SRB_3                        3
#define LCID_DRB_0                        4
#define LCID_DRB_1                        5
#define LCID_DRB_2                        6
#define LCID_DRB_3                        7
#define LCID_DRB_4                        8
#define LCID_DRB_5                        9
#define LCID_DRB_6                        10
#define LCID_DRB_7                        11
#define LCID_DRB_8                        12
#define LCID_DRB_9                        13
#define LCID_DRB_10                       14
#define LCID_DRB_11                       15
#define LCID_DRB_12                       16
#define LCID_DRB_13                       17
#define LCID_DRB_14                       18
#define LCID_DRB_15                       19
#define LCID_DRB_16                       20
#define LCID_DRB_17                       21
#define LCID_DRB_18                       22
#define LCID_DRB_19                       23
#define LCID_DRB_20                       24
#define LCID_DRB_21                       25
#define LCID_DRB_22                       26
#define LCID_DRB_23                       27
#define LCID_DRB_24                       28
#define LCID_DRB_25                       29
#define LCID_DRB_26                       30
#define LCID_DRB_27                       31
#define LCID_DRB_28                       32
#define REC_BIT_RATE                      47
#define SP_ZP_CSI_RS_RCS_SET_ACT_DEACT    48
#define PUCCH_SPATIAL_REL_ACT_DEACT       49
#define SP_SRS_ACT_DEACT                  50
#define SP_CSI_PUCCH_ACT_DEACT            51
#define TCI_STATE_IND_UE_PDCCH            52
#define TCI_STATE_ACT_DEACT_PDSCH         54
#define SPCSIRS_OR_CSIIM_RCSSET_ACT_DEACT 55
#define DUPLICATE_ACT_DEACT               56
#define SCELL_ACT_DEACT_32BIT             57
#define SCELL_ACT_DEACT_8BIT              58
#define LONG_DRX_COMMAND                  59
#define DRX_COMMAND                       60
#define TIMING_ADVANCE_COMMAND            61
#define UE_CR_ID                          62
#define PADDING                           63
#define LIT_END 1


#if (!LIT_END)
/**
 * @brief, The data structure of R/F/LCID/L MAC subheader with 8-bit L field.
 *
 * 3GPP TS 38.321 (Rel 15 Ver : 15.3.0)
 * Procedure : 6.1.2-1
 */
typedef struct wnMacSch8bSbHdr
{
    wnUInt8 res: 1;      /*! Reserved Bit, set to "0" */
    wnUInt8 format: 1;   /*! F-Format,"0"->8 bits of Length Field
                                      "1"->16 bits of Length Field*/
    wnUInt8 lcid: 6;     /*! Logical channel ID */
    wnUInt8 len;         /*! Length of corresponding MAC SDU or
                             variable-sized MAC CE */
} wnMacSch8bSbHdrT,
 *wnMacSch8bSbHdrP;
#endif

#if LIT_END
 /**
  * @brief, The data structure of R/F/LCID/L MAC subheader with 8-bit L field.
  *
  * 3GPP TS 38.321 (Rel 15 Ver : 15.3.0)
  * Procedure : 6.1.2-1
  */
 typedef struct wnMacSch8bSbHdr
 {
     wnUInt8 lcid: 6;     /*! Logical channel ID */
     wnUInt8 format: 1;   /*! F-Format,"0"->8 bits of Length Field
                                       "1"->16 bits of Length Field*/
     wnUInt8 res: 1;      /*! Reserved Bit, set to "0" */
     wnUInt8 len;         /*! Length of corresponding MAC SDU or
                              variable-sized MAC CE */
 } wnMacSch8bSbHdrT,
  *wnMacSch8bSbHdrP;
#endif

/**
 * @brief, The data structure of R/F/LCID/L MAC subheader with 16-bit L field.
 *
 * 3GPP TS 38.321 (Rel 15 Ver : 15.3.0)
 * Procedure : 6.1.2-2
 */
typedef struct wnMacSch16bSbHdr
{
    wnUInt8 res: 1;     /*! Reserved Bit, set to "0" */
    wnUInt8 format: 1;  /*! "0" -> 8 bits of Len field
                            "1" -> 16 bits of Len field */
    wnUInt8 lcid: 6;    /*! Logical channel ID */
    wnUInt8 lenLsb;     /*! Len of MAC SDU or variable-sized MAC CE */
    wnUInt8 lenMsb;     /*! Len of MAC SDU or variable-sized MAC CE */
} wnMacSch16bSbHdrT,
 *wnMacSch16bSbHdrP;


/**
 * @brief, The data structure of R/LCID fixed MAC subheader.
 *
 * 3GPP TS 38.321 (Rel 15 Ver : 15.3.0)
 * Procedure : 6.1.2-3
 */
typedef struct wnMacFixedSbHdr
{
    wnUInt8 res: 2;   /*! Reserved Bit, set to "0" */
    wnUInt8 lcid: 6;  /*! Logical channel ID for fixed size MAC SDU or CE */
} wnMacFixedSbHdrT,
 *wnMacFixedSbHdrP;

#endif  /** __WN_BS_PS_MAC_HEADER_H_ */

/** EOF */
