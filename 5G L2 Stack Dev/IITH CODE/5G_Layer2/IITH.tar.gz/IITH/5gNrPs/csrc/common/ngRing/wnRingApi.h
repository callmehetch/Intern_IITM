/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wnRingApis.h
 * @author Manoj Kumar
 *
 * @brief Ring APIs declaration for Framework
 *
 * @see http://git.wisig.com
 */

#include <rte_common.h>
#include <rte_ring.h>
#include "../inc/wnBsPsFwk.h"


typedef struct rte_ring  ngRing;

#define WN_RING_F_SP_ENQ 0x0001 /** For single producer */
#define WN_RING_F_SC_DEQ 0x0002 /** For single consumer */

#define WN_RING_SIZE 1024  /** Maximum size of the ring */


typedef struct ngPkt_t
{
   wnUInt16 test;
   wnUInt16 testvar;
}ngPkt;


ngRing * wnRingHndlr ( const wnChar *, wnUInt16, wnInt16, wnUInt8 );
wnUInt8 wnIsNgRingFull ( const ngRing * );
wnUInt8 wnIsNgRingEmpty ( const ngRing * );
wnUInt32 wnNumOfFreeEntries ( ngRing * );
wnUInt32 wnNumOfEntries ( ngRing * );
wnInt32 wnEnqElem2Ring ( ngRing *, wnVoid *);
wnInt32 wnDeqElemFrmRing ( ngRing *, wnVoid **);
#if 0
wnVoid wnEnqElem2Ring ( ngRing *, wnVoid *);
wnVoid wnDeqElemFrmRing ( ngRing *, wnVoid ** );
#endif
wnUInt32 wnEnqBulkElem2Ring ( ngRing *, wnVoid *, wnUInt32, wnUInt32 *);
wnUInt32 wnDeqBulkElemFrmRing ( ngRing *, wnVoid **, wnUInt32, wnUInt32 * );
wnVoid wnFreeRing ( ngRing * );
wnVoid wnErrHndlr ( const wnChar * );

