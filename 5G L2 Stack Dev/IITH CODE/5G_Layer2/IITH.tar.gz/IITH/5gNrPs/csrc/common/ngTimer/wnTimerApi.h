/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/
/**
 * @file wnTimerAPIs.h
 * @author balu
 * @brief file containing APIs declarations and headers.
 *
 * @see 
 * @see 
 */
#include <stdio.h>
#include <string.h>
#include <sys/timeb.h>
#include <time.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/queue.h>
#include <rte_common.h>
#include <rte_memory.h>
#include <rte_launch.h>
#include <rte_eal.h>
#include <rte_per_lcore.h>
#include <rte_lcore.h>
#include <rte_cycles.h>
#include <rte_timer.h>
#include <rte_log.h>
#include <rte_debug.h>


#include "../inc/wnBsPsFwk.h"

typedef struct rte_timer wnTimer;
typedef enum rte_timer_type wnTimerType;
typedef rte_timer_cb_t wnTimerCb;

/** function declerations */
wnVoid wnTimer0Cb (struct rte_timer *);
wnInt32 wnlcoreMainloop (wnVoid);
wnVoid wnTimerSubSystemInit (wnVoid);
wnVoid wnTimerInit (wnTimer);
wnInt32 wnTimerStart (wnTimer*,wnUInt64,wnTimerType,wnUInt32,wnTimerCb);
wnInt32 wnTimerStop (wnTimer *);
wnVoid wnTimerManage (wnVoid);
wnUInt32 wnLcoreId (wnVoid);
wnUInt32 wnGetTimerHz (wnVoid);
