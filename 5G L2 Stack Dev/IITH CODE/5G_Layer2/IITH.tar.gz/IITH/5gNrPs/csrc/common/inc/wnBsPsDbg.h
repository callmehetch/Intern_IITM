/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wn<SubProjectName><LayerName><Functionality>.<extention>
 * @author Anurag Asokan
 * @brief <one line description about this file>.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/coding-style
 */
#ifndef __WN_BSPS_DBG_H__
#define __WN_BSPS_DBG_H__

#ifndef DEBUG_LEVEL
#define DEBUG_LEVEL 1
#endif

#ifdef LOG_DEBUG  /*  TODO: Need to change this */
#define WN_LOG_DEBUG(x)                 printf("%s:%d | %s \t" x "\n", \
                                        __FILE__, __LINE__, __func__);
#else
#define WN_LOG_DEBUG(x)
#endif

#define pdbg_lvl(level, args...) do { if(level <= DEBUG_LEVEL) printf(args); } while(0)
#define pdbg1(args...) pdbg_lvl(1, args)
#define pdbg2(args...) pdbg_lvl(2, args)
#define pdbg3(args...) pdbg_lvl(3, args)
#define pdbg4(args...) pdbg_lvl(4, args)
#define pdbg5(args...) pdbg_lvl(5, args)

#endif  /* __WN_BSPS_DBG_H__ */
