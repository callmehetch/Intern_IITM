/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/  

/**
 * @file wn<SubProjectName><LayerName><Functionality>.<extention>
 * @author Anurag Asokan
 * @brief <one line description about this file>.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/coding-style
 */
#include "../ngPkt/wnNgPktApi.h"
#include "wnNgPoolApi.h"

static  ngPool *  ngPoolFromObj (void *obj)
{
    return (ngPool *) rte_mempool_from_obj(obj);
}


void ngPoolContigBlocksCheckCookies (const  ngPool *mp,
                                     void *const *first_obj_table_const,
                                     unsigned int n, int free)
{
return rte_mempool_contig_blocks_check_cookies(mp, first_obj_table_const, n, free);
}


ssize_t ngPoolOpCalcMemSizeDefault (const ngPool *mp, uint32_t obj_num,
                                    uint32_t pg_shift, size_t *min_chunk_size,
                                    size_t *align)
{
return rte_mempool_op_calc_mem_size_default(mp, obj_num, pg_shift,
                                           min_chunk_size, align);
}


int ngPoolOpPopulateDefault (ngPool *mp, unsigned int max_objs,
                             void *vaddr, rte_iova_t iova, size_t len,
                             ngPoolPopulateObjCbT *obj_cb,
                             void *obj_cb_arg)
{
    return rte_mempool_op_populate_default(mp, max_objs,vaddr, iova, len,
                                           obj_cb, obj_cb_arg);
}

#if 0
int ngPoolOpsGetInfo (const  ngPool *mp,  ngPoolInfo *info)
{
    return (*rte_mempool_get_info_t)(mp,info);

}
#endif

int ngPoolSetOpsByName (ngPool *mp, const char *name, void *pool_config)
{
    return rte_mempool_set_ops_byname(mp, name,pool_config);
}


int ngPoolRegisterOps (const ngPoolOps *ops)
{
    return rte_mempool_register_ops(ops);
}

#if 0
ngPool * ngPoolCreate (const char *name, unsigned n, unsigned elt_size,
                              unsigned cache_size, unsigned private_data_size,
                              ngPoolctor_t *mp_init, void *mp_init_arg,
                              ngPoolObjCbT *obj_init, void *obj_init_arg,
                              int socket_id, unsigned flags)
{
    return rte_mempool_create(name, n, elt_size, cache_size, private_data_size,
                              mp_init, mp_init_arg, obj_init, obj_init_arg,
                              socket_id, flags);

}
#endif

 ngPool * ngPoolCreateEmpty (const char *name, unsigned n,
                                   unsigned elt_size, unsigned cache_size,
                                   unsigned private_data_size, int socket_id,
                                   unsigned flags)
{
    return rte_mempool_create_empty(name, n, elt_size, cache_size, private_data_size,
                                  socket_id, flags);

}


void ngPoolFree (ngPool *mp)
{
    return rte_mempool_free(mp);
}


int ngPoolPopulateIova (ngPool *mp, char *vaddr, rte_iova_t iova,
                        size_t len, ngPoolMemchunkFreeCbT *free_cb,
                        void *opaque)
{
    return rte_mempool_populate_iova(mp, vaddr, iova, len, free_cb,opaque);

}


int ngPoolPopulateVirt (ngPool *mp, char *addr, size_t len, size_t pg_sz,
                        ngPoolMemchunkFreeCbT *free_cb, void *opaque)
{
    return rte_mempool_populate_virt(mp, addr, len, pg_sz, free_cb, opaque);
}


int ngPoolPopulateDefault (ngPool *mp)
{
    return  rte_mempool_populate_default(mp);
}


int ngPoolPopulateAnon ( ngPool *mp)
{
    return rte_mempool_populate_anon(mp);
}


uint32_t ngPoolObjIter (ngPool *mp, ngPoolObjCbT *obj_cb,
                        void *obj_cb_arg)
{
    return rte_mempool_obj_iter(mp, obj_cb, obj_cb_arg);
}


uint32_t ngPoolMemIter ( ngPool *mp, ngPoolMemCbT *mem_cb,
                        void *mem_cb_arg)
{
    return rte_mempool_mem_iter(mp, mem_cb, mem_cb_arg);
}


void ngPoolnump (FILE *f, ngPool *mp)
{
    return rte_mempool_dump(f, mp);
}


ngPoolCache * ngPoolCacheCreate (uint32_t size, int socket_id)
{
    return rte_mempool_cache_create(size, socket_id);
}


void ngPoolCacheFree ( ngPoolCache *cache)
{
    return rte_mempool_cache_free(cache);
}


static ngPoolCache * ngPoolDefaultCache ( ngPool *mp,
                                                unsigned lcore_id)
{
    return rte_mempool_default_cache(mp, lcore_id);
}


static  void ngPoolCacheFlush ( ngPoolCache *cache,  ngPool *mp)
{
    return rte_mempool_cache_flush(cache,mp);
}


static  void ngPoolGenericPut ( ngPool *mp, void *const *obj_table,
                               unsigned int n,  ngPoolCache *cache)
{
    return mempool_generic_put(mp, obj_table, n, cache);
}


static  void ngPoolPutBulk ( ngPool *mp, void *const *obj_table,
                            unsigned int n)
{
    return rte_mempool_put_bulk(mp, obj_table, n);
}


static  void ngPoolPut ( ngPool *mp, void *obj)
{
    return rte_mempool_put(mp, obj);
}


static  int ngPoolGenericGet ( ngPool *mp, void **obj_table,
                              unsigned int n, ngPoolCache *cache)
{
    return mempool_generic_get(mp, obj_table, n, cache);
}


static  int ngPoolGetBulk ( ngPool *mp, void **obj_table, unsigned int n)
{
    return rte_mempool_get_bulk(mp, obj_table, n);
}


static  int ngPoolGet (ngPool *mp, void **obj_p)
{
    return rte_mempool_get(mp, obj_p);
}


static  int ngPoolGetContigBlocks (ngPool *mp, void **first_obj_table,
                                   unsigned int n)
{
    return rte_mempool_get_contig_blocks(mp, first_obj_table, n);
}


unsigned int ngPoolAvailCount (const  ngPool *mp)
{
    return rte_mempool_avail_count(mp);
}


unsigned int ngPoolInUseCount (const ngPool *mp)
{
    return rte_mempool_in_use_count(mp);
}


static int ngPoolFull (const ngPool *mp)
{
    return rte_mempool_full(mp);
}


static int ngPoolEmpty (const  ngPool *mp)
{
    return rte_mempool_empty(mp); 
}


static rte_iova_t ngPoolVirt2Iova (const void *elt)
{
    return rte_mempool_virt2iova(elt);
}


void ngPoolAudit ( ngPool *mp)
{
    return rte_mempool_audit(mp);
}


static void * ngPoolGetPriv (ngPool *mp)
{
   return rte_mempool_get_priv(mp);
}


void ngPoolListDump (FILE *f)
{
    return rte_mempool_list_dump(f); 
}


ngPool * ngPoolLookup (const char *name)
{
    return rte_mempool_lookup(name);
}

#if 0
uint32_t ngPoolCalcObjSize (uint32_t elt_size, uint32_t flags, \
                            struct ngPoolObjsz *sz)
{
    return rte_mempool_calc_obj_size( elt_size, flags, sz);
}
#endif

void ngPoolWalk (void(*func)( ngPool *, void *arg), void *arg)
{
    return rte_mempool_walk(func, arg);
}

#if 0
int rte_mempool_full(const struct rte_mempool *mp)
{
    return rte_mempool_full(mp);
}
#endif

