/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/  

/**
 * @file wn<SubProjectName><LayerName><Functionality>.<extention>
 * @author Anurag Asokan
 * @brief <one line description about this file>.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/coding-style
 */

#ifndef __WN_NG_POOL_API_H__
#define __WN_NG_POOL_API_H__

#include <rte_mempool.h>

typedef struct rte_mempool_cache     ngPoolCache;
typedef struct rte_mempool_objsz     ngPoolObjsz;
typedef struct rte_mempool_objhdr    ngPoolObjhdr;
typedef struct rte_mempool_memhdr    ngPoolMemHdr;
typedef struct rte_mempool_info      ngPoolInfo;
typedef struct rte_mempool           ngPool;
typedef struct rte_mempool_ops       ngPoolOps;
typedef struct rte_mempool_ops_table ngPoolOpsTable;

typedef rte_mempool_memchunk_free_cb_t        ngPoolMemchunkFreeCbT;
typedef rte_mempool_alloc_t                   ngPoolAllocT;
typedef rte_mempool_free_t                    ngPoolFreeT;         
typedef rte_mempool_enqueue_t                 ngPoolEnqueueT;   
typedef rte_mempool_dequeue_t                 ngPoolDequeueT;   
typedef rte_mempool_get_count                 ngPoolGetCount; 
typedef rte_mempool_calc_mem_size_t           ngPoolCalcMemSizeT;
typedef rte_mempool_populate_t                ngPoolPopulateT;
typedef rte_mempool_get_info_t                ngPoolGetInfoT;
typedef rte_mempool_obj_cb_t                  ngPoolObjCbT;
typedef rte_mempool_populate_obj_cb_t         ngPoolPopulateObjCbT;
typedef rte_mempool_dequeue_contig_blocks_t   ngPoolDequeueContigBlocksT;
typedef rte_mempool_mem_cb_t                  ngPoolMemCbT;
typedef rte_mempool_ctor_t                    ngPoolctor_t;


static  ngPool * ngPoolFromObj (void *obj);
void ngPoolContigBlocksCheckCookies (const  ngPool *mp, 
                                     void *const *first_obj_table_const, 
                                     unsigned int n, int free);
ssize_t ngPoolOpCalcMemSizeDefault (const ngPool *mp, uint32_t obj_num, 
                                    uint32_t pg_shift, size_t *min_chunk_size, 
                                    size_t *align);
int ngPoolOpPopulateDefault ( ngPool *mp, unsigned int max_objs, 
                             void *vaddr, rte_iova_t iova, size_t len, 
                             ngPoolPopulateObjCbT *obj_cb, 
                             void *obj_cb_arg);
int ngPoolOpsGetInfo (const ngPool *mp, ngPoolInfo *info);
int ngPoolSetOpsByName ( ngPool *mp, const char *name, void *pool_config);
int ngPoolRegisterOps (const ngPoolOps *ops);
#if 0
ngPool * ngPoolCreate (const char *name, unsigned n, unsigned elt_size, 
                              unsigned cache_size, unsigned private_data_size, 
                              ngPoolctor_t *mp_init, void *mp_init_arg, 
                              ngPoolObjCbT *obj_init, void *obj_init_arg, 
                              int socket_id, unsigned flags);
#endif
ngPool * ngPoolCreateEmpty (const char *name, unsigned n, 
                                   unsigned elt_size, unsigned cache_size, 
                                   unsigned private_data_size, int socket_id, 
                                   unsigned flags);
void ngPoolFree (ngPool *mp);
int ngPoolPopulateIova ( ngPool *mp, char *vaddr, rte_iova_t iova, 
                        size_t len, ngPoolMemchunkFreeCbT *free_cb, 
                        void *opaque);
int ngPoolPopulateVirt ( ngPool *mp, char *addr, size_t len, size_t pg_sz,
                        ngPoolMemchunkFreeCbT *free_cb, void *opaque);
int ngPoolPopulateDefault (ngPool *mp);
int ngPoolPopulateAnon ( ngPool *mp);
uint32_t ngPoolObjIter ( ngPool *mp, ngPoolObjCbT *obj_cb, 
                        void *obj_cb_arg);
uint32_t ngPoolMemIter ( ngPool *mp, ngPoolMemCbT *mem_cb, 
                        void *mem_cb_arg);
void ngPoolDump (FILE *f,  ngPool *mp);
 ngPoolCache * ngPoolCacheCreate (uint32_t size, int socket_id);
void ngPoolCacheFree ( ngPoolCache *cache);
static ngPoolCache * ngPoolDefaultCache ( ngPool *mp, 
                                                unsigned lcore_id);
static  void ngPoolCacheFlush ( ngPoolCache *cache, ngPool *mp);
static  void ngPoolGenericPut ( ngPool *mp, void *const *obj_table, 
                               unsigned int n,  ngPoolCache *cache);
static  void ngPoolPutBulk ( ngPool *mp, void *const *obj_table, 
                            unsigned int n);
static  void ngPoolPut ( ngPool *mp, void *obj);
static  int ngPoolGenericGet ( ngPool *mp, void **obj_table, 
                              unsigned int n, ngPoolCache *cache);
static  int ngPoolGetBulk ( ngPool *mp, void **obj_table, unsigned int n);
static  int ngPoolGet ( ngPool *mp, void **obj_p);
static  int ngPoolGetContigBlocks ( ngPool *mp, void **first_obj_table, 
                                   unsigned int n);
unsigned int ngPoolAvailCount (const  ngPool *mp);
unsigned int ngPoolInUseCount (const  ngPool *mp);
static int ngPoolFull (const  ngPool *mp);
static int ngPoolEmpty (const  ngPool *mp);
static rte_iova_t ngPoolVirt2Iova (const void *elt);
void ngPoolAudit ( ngPool *mp);
static void * ngPoolGetPriv ( ngPool *mp);
void ngPoolListDump (FILE *f);
ngPool * ngPoolLookup (const char *name);
uint32_t ngPoolCalcObjSize (uint32_t elt_size, uint32_t flags, 
                             ngPoolObjsz *sz);
void ngPoolWalk (void(*func)( ngPool *, void *arg), void *arg);

#endif /* __WN_NG_POOL_API_H__ */
