/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/  

/**
 * @file wnBsPsFwk.h
 * @author Anurag Asokan
 * @brief Interface file for DPDK libraries to NR library.
 *
 * @see http://git.wisig.com/root/5gNrBsPs
 */

#ifndef __WN_BSPS_FWK_H__
#define __WN_BSPS_FWK_H__

#include "wnBsPsDataTypes.h"
#include "wnBsPsErrTypes.h"
#include "wnBsPsDbg.h"

#define WN_ALIGNED(x)                   __attribute__((__aligned__(x)))

#define WN_PACKED                       __attribute__((__packed__))

#define WN_OFFSETOF(type, member)       __builtin_offsetof(type, member)

#define WN_FIELD_SIZEOF(type, member)   sizeof(((type *)0)->member)


#endif /* __WN_BSPS_FWK_H__ */ 

/* EOF */
