/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/
/**
 * @file wnTimerAPIs.c
 * @author balu 
 * @brief file containing APIs for timers.
 *
 * @see 
 * @see 
 */


#include "wnTimerApi.h"


/**
 * @brief wnlcoreMainloop
 *
 * @param 
 * @returns 0 After reaching 2000 count
 */
wnInt32 wnlcoreMainloop (wnVoid) 
{
	uint64_t prev_tsc = 0, cur_tsc, diff_tsc;
	uint32_t lcore_id;
	lcore_id = wnLcoreId();
	printf("Starting mainloop on core %u\n", lcore_id);
	while (1) {
		/*
		 * Call the timer handler on each core: as we don't
		 * need a very precise timer, so only call
		 * rte_timer_manage();
		 */
		cur_tsc = rte_rdtsc();
		diff_tsc = cur_tsc - prev_tsc;
		if (diff_tsc > 0) {
            /* Manage the timer list and execute callback functions */
			wnTimerManage();
			prev_tsc = cur_tsc;
		} 
	}
}


/**
 * @brief To initialize RTE timer library
 *
 * @param 
 * @returns
 */
wnVoid wnTimerSubSystemInit (wnVoid)
{
	/* init RTE timer library */
	rte_timer_subsystem_init();
}


/**
 * @brief To initialize timer structures
 *
 * @param tim The timer to initialize
 * @returns
 */
wnVoid wnTimerInit (wnTimer tim)
{
	/* init timer structures */
	rte_timer_init(&tim);
}


/**
 * @brief To Reset and start the timer associated with the timer handle.
 *
 * @param tim	The timer handle.
 * @param ticks	The number of cycles (see rte_get_hpet_hz()) before the callback 
 *              function is called.
 * @param type	The type can be either:
 *                 PERIODICAL: The timer is automatically reloaded after execution 
 *                             (returns to the PENDING state)
 *                 SINGLE: The timer is one-shot, that is, the timer goes to a 
 *                         STOPPED state after execution.
 * @param tim_lcore	The ID of the lcore where the timer callback function has to 
 *                   be executed. If tim_lcore is LCORE_ID_ANY, the timer library 
 *                   will launch it on a different core for each call (round-robin).
 * @param fct	 The callback function of the timer.
 * @param arg	 The user argument of the callback function.
 *
 * @returns  0:   Success; the timer is scheduled.
 *        (-1):   Timer is in the RUNNING or CONFIG state.
 */
wnInt32 wnTimerStart(wnTimer *tim, wnUInt64 ticks ,wnTimerType type,
                     wnUInt32 tim_lcore,wnTimerCb fct)
{
    return rte_timer_reset(tim, ticks, type, tim_lcore, fct,NULL);
}


/**
 * @brief function function stops the timer associated with the timer handle tim
 *
 * @param tim	The timer handle.
 *
 * @returns 0:   Success; the timer is scheduled.
 *       (-1):   Timer is in the RUNNING or CONFIG state. 
 */
wnInt32 wnTimerStop (wnTimer *tim)
{
    return rte_timer_stop(tim);
}



/**
 * @brief function Manage the timer list and execute callback functions.
 *
 * @param 
 * @returns
 */
wnVoid wnTimerManage (wnVoid)
{
    rte_timer_manage();
}


/**
 * @brief function Get the number of cycles in one second for the default timer.
 *
 * @param 
 * @returns The number of cycles in one second.
 */
wnUInt32 wnGetTimerHz (wnVoid)
{
   return rte_get_timer_hz();
}


/**
 * @brief function Return the Application thread ID of the execution unit.
 *
 * @param 
 * @returns Logical core ID (in EAL thread) or LCORE_ID_ANY (in non-EAL thread)
 */
wnUInt32 wnLcoreId (wnVoid)
{
    return rte_lcore_id();
}
