/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/  

/**
 * @file wn<SubProjectName><LayerName><Functionality>.<extention>
 * @author Anurag Asokan
 * @brief <one line description about this file>.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/coding-style
 */

#ifndef __WN_NG_PKT_API_H__
#define __WN_NG_PKT_API_H__

#include <rte_mbuf.h>

#include "../inc/wnBsPsFwk.h"

#define NUM_MBUFS              8191
#define MBUF_CACHE_SIZE        250
#define rte_mempool            ngPktPool /* TEMP */
#define BURST_SIZE             32

#define RX_RING_SIZE           128
#define TX_RING_SIZE           512


#define MAX_ELT_SIZE           ((1024 * 64) - 1)
#define MAX_TB_SZ              (66392/8) /* (100 PRBS, MCS 14, MOD 64 QAM)*/
#define RING_SIZE              1024

/** FIXME: None of the IP Macros are used as of now */
#define IP_DEFTTL              64   /* from RFC 1340. */
#define IP_VERSION             0x40
#define IP_HDRLEN              0x05 /* default IP header length == five 32-bits words. */
#define IP_VHL_DEF             (IP_VERSION | IP_HDRLEN)

/** Header info: header map macro's */
#define MACHDR_PRSNT    ((1<<0))
#define RLCHDR_PRSNT    ((1<<1))
#define PDCPHDR_PRSNT   ((1<<2))
#define SDAPHDR_PRSNT   ((1<<3))
#define GTPHDR_PRSNT    ((1<<4))
#define SCTPHDR_PRSNT   ((1<<5))
#define PDUSSNHDR_PRSNT ((1<<6))
#define IPHDR_PRSNT     ((1<<7))
#define UDPHDR_PRSNT    ((1<<8))
#define ETHHDR_PRSNT    ((1<<9))

/** Header info: header location macro;s */
#define MACHDR_LOC    ((0))
#define RLCHDR_LOC    ((1))
#define PDCPHDR_LOC   ((2))
#define SDAPHDR_LOC   ((3))
#define GTPHDR_LOC    ((4))
#define SCTPHDR_LOC   ((5))
#define PDUSSNHDR_LOC ((6))
#define IPHDR_LOC     ((7))
#define UDPHDR_LOC    ((8))
#define ETHHDR_LOC    ((9))

/** Max imum number of headers supported in Header Info */
#define MAXHDR        7

/** FIXME: Temporary */
typedef struct rte_mbuf ngPkt;
typedef struct rte_mempool ngPool;
typedef rte_mbuf_extbuf_free_callback_t ngPktExtbufFreeCallbackT;
typedef struct rte_mbuf_ext_shared_info ngPktExtSharedInfo;
typedef int wniova_t;

/** Header Info */
typedef struct wnPbufHdrMetaInfo0
{
    uint32_t hdrmap;
    void     *hdrLoc[MAXHDR];
} hdrInfoT,
 *hdrInfoP;

void * wnGetHdrOffsetFromNgPkt(struct rte_mbuf *buf, uint16_t HDR);

/** function for packet generation */
void wnBsPspktgen (char *, int );

/** HdrInfo */
hdrInfoP wnGetHdrInfoFromMbuf( ngPkt *pkt );

/** RTE_MBUF to NG_PKT */
const char * 	wnGetRxOlFlagName (uint64_t mask);
int 	wnGetRxOlFlagList (uint64_t mask, char *buf, size_t buflen);
const char * 	wnGetTxOlFlagName (uint64_t mask);
int 	wnGetTxOlFlagList (uint64_t mask, char *buf, size_t buflen);
void 	ngPktPrefetchPart1 (ngPkt *p);
void 	ngPktPrefetchPart2 (ngPkt *p);
uint16_t ngPktPrivSize (ngPool *np);
wniova_t ngPktDataIova (const ngPkt *np);
wniova_t ngPktDataIovaDefault (const ngPkt *np);
ngPkt * 	ngPktFromIndirect (ngPkt *pi);
char *  	ngPktBufAddr (ngPkt *p, ngPool *np);
char *  	ngPktDataAddrDefault (ngPkt *np);
char * 	ngPktTobaddr (ngPkt *md);
//void *  	ngPktToPriv (ngPkt *p);
uint16_t ngPktRefcntUpdate (ngPkt *p, int16_t value);
uint16_t ngPktRefcntRead (const ngPkt *p);
void 	ngPktRefcntSet (ngPkt *p, uint16_t new_value);
uint16_t ngPktExtRefcntRead (const ngPktExtSharedInfo *shinfo);
void 	ngPktExtRefcntSet (ngPktExtSharedInfo *shinfo, uint16_t new_value);
uint16_t ngPktExtRefcntUpdate (ngPktExtSharedInfo *shinfo, int16_t value);
void 	ngPktSanityCheck (const ngPkt *p, int is_header);
//  int 	ngPktCheck (const ngPkt *p, int is_header, const char **reason);
ngPkt * 	ngPktRawAlloc (ngPool *np);
void 	ngPktRawFree (ngPkt *p);
void   ngPktInit (ngPool *np, void *opaque_arg, void *p, unsigned i);
void   ngPktpoolinit (ngPool *np, void *opaque_arg);
ngPool * ngPoolCreate (const char *name, unsigned n, unsigned cache_size, 
		uint16_t priv_size, uint16_t data_room_size, int socket_id);
ngPool * ngPoolCreateByOps (const char *name, unsigned int n, 
		unsigned int cache_size, uint16_t priv_size, uint16_t data_room_size, 
		int socket_id, const char *ops_name);
uint16_t ngPktDataRoomSize (ngPool *np);
void 	ngPktResetHeadRoom (ngPkt *p);
ngPkt * 	ngPktAlloc (ngPool *np);
int 	ngPktAllocBulk (ngPool *pool, ngPkt **npufs, unsigned count);
ngPktExtSharedInfo * 	ngPktExtshInfoInitHelper (void *buf_addr, 
		uint16_t *buf_len, ngPktExtbufFreeCallbackT free_cb, void *fcb_opaque);
void 	ngPktAttachExtBuf (ngPkt *p, void *buf_addr, 
		wniova_t buf_iova, uint16_t buf_len, ngPktExtSharedInfo *shinfo);
void 	ngPktAttach (ngPkt *pi, ngPkt *p);
void 	ngPktDetach (ngPkt *p);
ngPkt * 	ngPktPreFreeSeg (ngPkt *p);
void 	ngPktFreeSeg (ngPkt *p);
void 	ngPktFree (ngPkt *p);
ngPkt * 	ngPktClone (ngPkt *md, ngPool *np);
void 	ngPktRefCntUpdate (ngPkt *p, int16_t v);
uint16_t ngPktHeadRoom (const ngPkt *p);
uint16_t ngPktTailRoom (const ngPkt *p);
ngPkt * 	ngPktLastSeg (ngPkt *p);
char * 	ngPktPrepend (ngPkt *p, uint16_t len);
char * 	ngPktAppend (ngPkt *p, uint16_t len);
char * 	ngPktAdj (ngPkt *p, uint16_t len);
int 	ngPktTrim (ngPkt *p, uint16_t len);
int 	ngPktIsContiguous (const ngPkt *p);
const void * 	ngPktRead (const ngPkt *p, uint32_t off, 
		                   uint32_t len, void *buf);
int 	ngPktChain (ngPkt *head, ngPkt *tail);
int 	ngValidateTxOffload (const ngPkt *p);
int 	ngPktLinearize (ngPkt *npuf);
void   ngPktDump (FILE *f, const ngPkt *p, unsigned dump_len);
//uint32_t ngPktSchedQueueGet (const ngPkt *p);
#if 0
uint8_t 	ngPktSchedTrafficClassGet (const ngPkt *p);
uint8_t 	ngPktSchedColorGet (const ngPkt *p);
void 	ngPktSchedGet (const ngPkt *p, uint32_t *queue_id, 
		               uint8_t *traffic_class, uint8_t *color);
void 	ngPktSchedQueueSet (ngPkt *p, uint32_t queue_id);
void 	ngPktSchedTrafficClassSet (ngPkt *p, uint8_t traffic_class);
void 	ngPktSchedColorSet (ngPkt *p, uint8_t color);
void 	ngPktSchedSet (ngPkt *p, uint32_t queue_id, 
		               uint8_t traffic_class, uint8_t color);
#endif

#endif /* __WN_NG_PKT_API_H__ */

