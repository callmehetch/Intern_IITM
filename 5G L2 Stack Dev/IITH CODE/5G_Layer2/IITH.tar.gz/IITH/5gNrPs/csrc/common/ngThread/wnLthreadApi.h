/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/
/**
 * @file wnLthread.h
 * @author 
 * @brief file containing APIs for Lthreads.
 *
 * @see 
 * @see 
 */


#include <stdio.h>
#include <string.h>
#include <sys/timeb.h>
#include <time.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/queue.h>

#include <rte_common.h>
#include <rte_memory.h>
#include <rte_launch.h>
#include <rte_eal.h>
#include <rte_per_lcore.h>
#include <rte_lcore.h>
#include <rte_cycles.h>
#include <rte_log.h>

#include <rte_debug.h>
#include <sys/socket.h>
#include <fcntl.h> 
#include <netinet/in.h> 
                                                                               
                                                                               
struct lthread;
struct lthread_cond;
struct lthread_mutex;
                                                                               
struct lthread_condattr; 
struct lthread_mutexattr;


typedef void *(*lthread_func_t) (void *);
typedef void (*tls_destructor_func) (void *);


int wnLthreadCreate(struct lthread **new_lt, int lcore, lthread_func_t func, void *arg);
int wnLthreadCancel(struct lthread *lt);
int wnLthreadJoin(struct lthread *lt, void **ptr);
void wnLthreadDetach(void);
void wnLthreadExit(void *val);
void wnLthreadSleep(uint64_t nsecs);
void wnLthreadSleepClks(uint64_t clks);
void wnLthreadYield(void);
int wnLthreadSetAffinity(unsigned lcore);
void wnLthreadSetData(void *data);
void *wnLthreadGetData(void);
int wnLthreadMutexInit(char *name, struct lthread_mutex **mutex, const struct lthread_mutexattr *attr);
int wnLthreadMutexDestroy(struct lthread_mutex *mutex);
int wnLthreadMutexLock(struct lthread_mutex *mutex);
int wnLthreadMutexTrylock(struct lthread_mutex *mutex);
int wnLthreadMutexUnlock(struct lthread_mutex *mutex);
int wnLthreadCondInit(char *name, struct lthread_cond **c, const struct lthread_condattr *attr);
int wnLthreadCondDestroy(struct lthread_cond *cond);
int wnLthreadCondWait(struct lthread_cond *c, uint64_t reserved);
int wnLthreadCondSignal(struct lthread_cond *c);
int wnLthreadCondBroadcast(struct lthread_cond *c);
