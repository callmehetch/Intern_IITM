/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/
/**
 * @file wnLthread.c
 * @author 
 * @brief file containing APIs for Lthreads.
 *
 * @see 
 * @see 
 */

#include "wnLthreadApi.h"


/**                                                                            
  * @brief Create an lthread                                                          
  *                                                                           
  * @param new_lt                                                              
  *        Pointer to an lthread pointer that will be initialized                    
  * @param lcore                                                               
  *        the lcore the thread should be started on or the current clore            
  *        -1 the current lcore                                                    
  *         0 - LTHREAD_MAX_LCORES any other lcore                                  
  * @param lthread_func                                                        
  *        Pointer to the function the for the thread to run                         
  * @param arg                                                                 
  *        Pointer to args that will be passed to the thread                         
  *                                                                            
  * @return 0: success                                                              
  *         EAGAIN:  no resources available                                            
  *         EINVAL:  NULL thread or function pointer, or lcore_id out of range         
  */ 
int wnLthreadCreate(struct lthread **new_lt, int lcore, lthread_func_t func, void *arg)
{ 
    return lthread_create(&new_lt, lcore, func, (void*) arg);
}


/**                                                                            
  * @brief Cancel an lthread           
  *                                                                            
  * @param new_lt                                                              
  *        Pointer to an lthread that will be cancelled                              
  *                                                                            
  * @return 0: success                                                              
  *         EINVAL: thread was NULL                                                   
  */
int wnLthreadCancel(struct lthread *lt)
{
    return lthread_cancel(&lt);
}


/**                                                                            
  * @brief Join an lthread                                                                                
  *                                                                            
  * @param lt                                                                  
  *        Pointer to the lthread to be joined                                       
  * @param ptr                                                                 
  *        Pointer to pointer to collect returned data                               
  *                                                                            
  * @return 0: success                                                              
  *         EINVAL: lthread could not be joined.                                       
  */ 
int wnLthreadJoin(struct lthread *lt, void **ptr)
{
    return lthread_join(&lt, (void **)ptr);
}


/**                                                                            
  * @brief Detach an lthread                                                          
  *                                                                            
  * Detaches the current thread                                                
  * On exit a detached lthread will be freed immediately and will not wait     
  * to be joined. The default state for a thread is not detached.              
  *                                                                            
  * @return none                                                                      
  */
void wnLthreadDetach(void)
{
    lthread_detach();
}


/**                                                                            
  * @brief Exit an lthread                                                           
  *                              
  * After calling this function the lthread will be suspended until it is      
  * joined. After it is joined then its resources will be freed.               
  *                                                                            
  * @param ptr                                                                 
  *        Pointer to pointer to data to be returned                                 
  *                                                                            
  * @return none                                                                      
  */ 
void wnLthreadExit(void *val)
{
    lthread_exit((void *)val);
}


/**                                                                            
  * @brief Cause the current lthread to sleep for n nanoseconds             
  *                                                                            
  * @param nsecs                                                               
  *        Number of nanoseconds to sleep                                            
  *                                                                            
  * @return none                                                                      
  */ 
void wnLthreadSleep(uint64_t nsecs)
{
    lthread_sleep(nsecs);
}


/**                                                                            
  * @brief Cause the current lthread to sleep for n cpu clock ticks           
  *                                                                            
  * @param clks                                                                
  *        Number of clock ticks to sleep                                            
  *                                                                            
  * @return none                                                                      
  */ 
void wnLthreadSleepClks(uint64_t clks)
{
    lthread_sleep_clks(clks);
}


/**                                                                            
  * @brief Yield the current lthread                                                  
  *                                                                            
  *  The current thread will yield and execution will switch to the            
  *  next lthread that is ready to run                                         
  *                                                                            
  * @return none                                                                      
  */ 
void wnLthreadYield(void)
{
    lthread_yield();
}


/**                                                                            
  * @brief Migrate the current thread to another scheduler                            
  *                                                                            
  *  This function migrates the current thread to another scheduler.           
  *  Execution will switch to the next lthread that is ready to run on the     
  *  current scheduler. The current thread will be resumed on the new scheduler.
  *                                                                            
  * @param lcore                                                               
  *        The lcore to migrate to                                                    
  *                                                                            
  * @return 0: success we are now running on the specified core                      
  *         EINVAL: the destination lcore was not valid                                
  */ 
int wnLthreadSetAffinity(unsigned lcore)
{
    return lthread_set_affinity(lcore);
}


/**                                                                            
  * @brief Return the current lthread                                               
  *                                                                            
  * @return pointer to the current lthread                                            
  */                                                                           
struct lthread *wnlthreadCurrent(void)
{
    lthread_current();  
}


/**                                                                            
  * @brief Associate user data with an lthread                                        
  *                                                                            
  *  This function sets a user data pointer in the current lthread             
  *  The pointer can be retrieved with lthread_get_data()                      
  *  It is the users responsibility to allocate and free any data referenced   
  *  by the user pointer.                                                      
  *                                                                            
  * @param data                                                                
  *        pointer to user data                                                      
  *                                                                            
  * @return none                                                                      
  */ 
void wnLthreadSetData(void *data)
{
    lthread_set_data(&data);
}


/**                                                                            
  * @brief Initialize a mutex 
  *                   
  * lthread_mutex_init() initializes the mutex object pointed to by mutex     
  * Optional mutex attributes specified in mutexattr, are reserved for future 
  * use and are currently ignored. 
  *
  * @param name                                                                
  *        Optional pointer to string describing the mutex                           
  * @param mutex                                                               
  *        Pointer to pointer to the mutex to be initialized                         
  * @param attribute                                                           
  *        Pointer to attribute - unused reserved                                    
  *                                                                            
  * @return 0: success                                                                 
  *         EINVAL: mutex was not a valid pointer                                      
  *         EAGAIN: insufficient resources                                             
  */ 

int wnLthreadMutexInit(char *name, struct lthread_mutex **mutex, const struct lthread_mutexattr *attr)
{
    return lthread_mutex_init(&name, &mutex, &attr);
}


/**                                                                            
  * @brief Destroy a mutex                                                            
  *                                                                            
  * This function destroys the specified mutex freeing its resources.         
  * The mutex must be unlocked before calling lthread_mutex_destroy.          
  *                                                                            
  * @see lthread_mutex_init()                                                  
  *                                                                            
  * @param mutex                                                               
  *        Pointer to pointer to the mutex to be initialized                         
  *                                                                            
  * @return 0: success                                                                 
  *         EINVAL: mutex was not an initialized mutex                                 
  *         EBUSY: mutex was still in use                                              
  */ 
int wnLthreadMutexDestroy(struct lthread_mutex *mutex)
{
    return lthread_mutex_destroy(&mutex);
}


/**                                                                            
  * @brief Lock a mutex                                                               
  *                                                                            
  * This function attempts to lock a mutex.                                   
  * If a thread calls lthread_mutex_lock() on the mutex, then if the mutex    
  * is currently unlocked,  it  becomes  locked  and  owned  by  the calling  
  * thread, and lthread_mutex_lock returns immediately. If the mutex is       
  * already locked by another thread, lthread_mutex_lock suspends the calling 
  * thread until the mutex is unlocked.                                       
  *                                                                            
  * @see lthread_mutex_init()                                                  
  *                                                                            
  * @param mutex                                                               
  *        Pointer to pointer to the mutex to be initialized                         
  *                                                                            
  * @return 0: success                                                                 
  *         EINVAL: mutex was not an initialized mutex                                 
  *         EDEADLOCK:  the mutex was already owned by the calling thread               
  */ 
int wnLthreadMutexLock(struct lthread_mutex *mutex)
{
    return lthread_mutex_lock(&mutex);
}


/**                                                                            
  * @brief Try to lock a mutex
  *                                                                 
  * This function attempts to lock a mutex.                                   
  * lthread_mutex_trylock behaves identically to rte_thread_mutex_lock, except
  * that it does not block the calling  thread  if the mutex is already locked
  * by another thread.
  *                                                                            
  * @see lthread_mutex_init()
  *
  * @param mutex                                                               
  *        Pointer to pointer to the mutex to be initialized                         
  *                                                                            
  * @return 0: success                                                                  
  *         EINVAL: mutex was not an initialized mutex                                  
  *         EBUSY: the mutex was already locked by another thread                       
  */
int wnLthreadMutexTrylock(struct lthread_mutex *mutex)
{
    return lthread_mutex_trylock(&mutex);
}


/**                                                                            
  * Unlock a mutex                                                             
  *                                                                            
  * This function attempts to unlock the specified mutex. The mutex is assumed 
  * to be locked and owned by the calling thread.                              
  *                                                                            
  * The oldest of any threads blocked on the mutex is made ready and may          
  * compete with any other running thread to gain the mutex, it fails it will  
  * be blocked again.                                                         
  *                                                                            
  * @param mutex                                                               
  *        Pointer to pointer to the mutex to be initialized                          
  *                                                                            
  * @return 0: mutex was unlocked                                                      
  *         EINVAL: mutex was not an initialized mutex                                 
  *         EPERM: the mutex was not owned by the calling thread                       
  */
int wnLthreadMutexUnlock(struct lthread_mutex *mutex)
{
    return lthread_mutex_unlock(&mutex);
}


/**
  * @brief Initialize a condition variable
  *
  * This function initializes a condition variable.
  * Condition variables can be used to communicate changes in the state of data shared between threads.
  * @see lthread_cond_wait() 
  *
  * @param name
  *        Pointer to optional string describing the condition variable
  * @param c
  *        Pointer to pointer to the condition variable to be initialized
  * @param attr 
  *        Pointer to optional attribute reserved for future use, currently ignored
  *
  * @return 0: success
  *         EINVAL: cond was not a valid pointer
  *         EAGAIN: insufficient resources 
  */
int wnLthreadCondInit(char *name, struct lthread_cond **c, const struct lthread_condattr *attr)
{
    return lthread_cond_init(&name, &c, &attr);
}


/**
  * @brief Destroy a condition variable
  *
  * This function destroys a condition variable that was created with
  * lthread_cond_init() and releases its resources.
  *
  * @param cond
  *        Pointer to pointer to the condition variable to be destroyed
  *
  * @return 0: Success
  *         EBUSY: condition variable was still in use
  *         EINVAL: was not an initialised condition variable  
  */
int wnLthreadCondDestroy(struct lthread_cond *cond)
{
    return lthread_cond_destroy(&cond);
}


/**
  * @brief Wait on a condition variable 
  * The function blocks the current thread waiting on the condition variable
  * specified by cond. The waiting thread unblocks only after another thread 
  * calls lthread_cond_signal, or lthread_cond_broadcast, specifying the
  * same condition variable.
  *
  * @param cond  
  *        Pointer to pointer to the condition variable to be waited on 
  * @param reserved  
  *        Reserved for future use
  * 
  * @return 0: The condition was signalled ( Success )
  *         EINVAL: was not a an initialised condition variable 
  */
int wnLthreadCondWait(struct lthread_cond *c, uint64_t reserved)
{
    return lthread_cond_wait(&c, reserved);
}


/**                                                                            
  * @brief Signal a condition variable 
  * The function unblocks one thread waiting for the condition variable cond.
  * If no threads are waiting on cond, the rte_lthead_cond_signal() function has no effect. 
  *
  * @param cond 
  *        Pointer to pointer to the condition variable to be signalled 
  *
  * @return 0: The condition was signalled ( Success ) 
  *         EINVAL: was not a an initialised condition variable 
  */ 
int wnLthreadCondSignal(struct lthread_cond *c)
{
    return lthread_cond_signal(&c);
}


/**
  * @brief Broadcast a condition variable                                             
  * The function unblocks all threads waiting for the condition variable cond.
  * If no threads are waiting on cond, the rte_lthead_cond_broadcast()
  * function has no effect.
  *
  * @param cond 
  *        Pointer to pointer to the condition variable to be signalled
  *
  * @return 0: The condition was signalled ( Success ) 
  *         EINVAL: was not a an initialised condition variable
  */
int wnLthreadCondBroadcast(struct lthread_cond *c)
{
    return lthread_cond_broadcast(&c);
}

/* EOF */
