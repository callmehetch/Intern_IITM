/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wnRingApis.c
 * @author Manoj Kumar
 *
 * @brief Ring APIs definitaion for Framework
 *
 * @see http://git.wisig.com
 */


#include "wnRingApi.h"


/**
 * @brief To create a ring 
 *
 * @param ringName The name of the ring
 * @param ringSize The size of the ngRing ( must be a power of 2 )
 * @param sockId   The socket id in case of NUMA.The value can be SOCKET_ID_ANY
 *                 if there is no NUMA constraint for reserved zone.
 * @param flags    set for single producer/consumer
 * returns ret     if success The pointer to the ngRing structure, else NULL
 */
ngRing * wnRingHndlr ( const wnChar *ringName, wnUInt16 ringSize,
                                               wnInt16 sockId, wnUInt8 flags )
{
    return  rte_ring_create ( ringName, ringSize, sockId, flags );
}


/**
 * @brief To check ngRing is full or not
 *
 * @param ringName A pointer to the ngRing structure
 * @returns 1 ring is full otherwise 0 for non-full
 */
wnUInt8 wnIsNgRingFull ( const ngRing * ringName )

    return rte_ring_full ( ringName );
}


/**
 * @brief To check ngRing is empty or not
 *
 * @param ringName A pointer to the ngRing structure
 * @returns 1 ring is empty otherwise 0 for non-empty
 */
wnUInt8 wnIsNgRingEmpty ( const ngRing * ringName )
{
    return rte_ring_empty ( ringName );
}



/** 
 * @brief To enqueue an element in ring
 *
 * @param ringPtr   A pointer to the ngRing structure
 * @param ringElem  A pointer to the element to be added
 * @return ret      0 for success otherwise (-)ve value
 */
wnInt32 wnEnqElem2Ring ( ngRing *ringPtr, wnVoid *elem )
{
    return rte_ring_enqueue ( ringPtr, elem );
}

/**
 * @brief Enqueue several objects/elements on a ngRing
 *
 * @param ringPtr  A pointer to the ngRing structure 
 * @param elem     A pointer to a table of void * pointers (objects/elements)
 * @param n        The number of objects/elements to add in the ngRing from the 
 *                 elem
 * @param frSpc    if non-NULL, returns the amount of space in the ngRing 
 *                 after the enqueue operation has finished.
 * @returns        0:Success; objects enqueued, -ENOBUFS: Not enough room in 
 *                 the ring to enqueue; no object is enqueued.
 */
wnUInt32 wnEnqBulkElem2Ring ( ngRing *ringPtr, wnVoid * elem, wnUInt32 n,
                                                             wnUInt32 * frSpc )
{
    return rte_ring_enqueue_bulk ( ringPtr, elem, n, frSpc ); 
}

/**
 * @brief To dequeue an element from ring 
 *
 * @param ringPtr A pointer to the nrRing structure.
 * @param elem    A pointer to a void * pointer (element) that will be filled.
 * @returns ret   0 for success, otherwise (-)ve value
 */
wnInt32  wnDeqElemFrmRing ( ngRing * ringPtr, wnVoid **elem )
{
    return rte_ring_dequeue ( ringPtr,  elem );
}


/**
 * @brief Dequeue several objects/elements from ngRing
 *
 * @param ringPtr  A pointer to the ngRing structure 
 * @param elem     A pointer to a table of void * pointers (objects/elements)
 * @param n        The number of objects to dequeue from the ngRing to the elem
 * @param frSpc	   If non-NULL, returns the number of remaining ring entries 
 *                 after the dequeue has finished.
 * @returns The number of objects dequeued, either 0 or n
 */
wnUInt32 wnDeqBulkElemFrmRing ( ngRing *ringPtr, wnVoid **elem, wnUInt32 n,
                                                              wnUInt32 *frSpc )
{
    return rte_ring_dequeue_bulk ( ringPtr, elem, n, frSpc ); 
}


/** 
 * @brief To get number of free entries in the ngRing
 *
 * @param ringPtr A pointer to the ngRing structure
 * @returns number of free entries in the ngRing
 */
wnUInt32 wnNumOfFreeEntries ( ngRing * ringPtr )
{
    return rte_ring_free_count ( ringPtr );
}


/** 
 * @brief To get number of entries in the ngRing
 *
 * @param ringPtr A pointer to the ngRing structure 
 * @returns number of entries in the ngRing
 */ 
wnUInt32 wnNumOfEntries ( ngRing * ringPtr )
{
    return rte_ring_count ( ringPtr );
}

#if 0
/**
 * @brief To enqueue an element in ring
 *
 * @param ringPtr   A pointer to the ngRing structure
 * @param ringElem  A pointer to the element to be added
 * @return ret      0 for success otherwise (-)ve value
 */
wnVoid wnEnqElem2Ring ( ngRing *ringPtr, wnVoid *elem )
{
    wnInt16 ret = -1;
    ret = rte_ring_enqueue ( ringPtr, elem );
    if ( 0 != ret )
    {
        /** wnErrHndlr, would be replaced by WN_LOG_DEBUG */
        wnErrHndlr ("Error : Enq operation failed\n");
        exit(0);
    }
}


/**
 * @brief To dequeue an element from ring
 *
 * @param ringPtr A pointer to the nrRing structure.
 * @param elem    A pointer to a void * pointer (element) that will be filled.
 * @returns ret   0 for success, otherwise (-)ve value
 */
wnVoid  wnDeqElemFrmRing ( ngRing * ringPtr, wnVoid **elem )
{
    wnInt16 ret = -1;
    ret = rte_ring_dequeue ( ringPtr,  elem );
    if ( 0 != ret )
    {
        /** wnErrHndlr, would be replaced by WN_LOG_DEBUG */
        wnErrHndlr ("Error : Deq operation failed\n");
        exit(0);
    }
}

#endif 

/**
 * @brief De-allocate all memory used by the ring.
 *
 * @param ringPtr A pointer to the ngRing structure
 * @returns wnVoid
 */
wnVoid wnFreeRing ( ngRing *ringPtr )
 {
    rte_ring_free ( ringPtr );
 }


/**
 * @brief To handle the error
 *
 * @param err error message
 * @return wnVoid
 */
wnVoid wnErrHndlr ( const wnChar *err )
{
    printf ("%s\n", err);
}
