
/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/  

/**
 * @file wn<SubProjectName><LayerName><Functionality>.<extention>
 * @author Anurag Asokan
 * @brief <one line description about this file>.
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/coding-style
 */

#include "wnNgPktApi.h"

hdrInfoP wnGetHdrInfoFromMbuf( ngPkt *pkt )
{
    return pkt->buf_addr;
}

const char * wnGetRxOlFlagName (uint64_t mask)
{
    return rte_get_rx_ol_flag_name(mask);
}


int wnGetRxOlFlagList (uint64_t mask, char *buf, size_t buflen)
{
    return rte_get_rx_ol_flag_list(mask, buf, buflen);
}


const char * wnGetTxOlFlagName (uint64_t mask)
{
    return rte_get_tx_ol_flag_name(mask);
}


int wnGetTxOlFlagList (uint64_t mask, char *buf, size_t buflen)
{
    return rte_get_tx_ol_flag_list(mask, buf, buflen);
}


void ngPktPrefetchPart1 (ngPkt *p)
{
    rte_mbuf_prefetch_part1(p);
}


void ngPktPrefetchPart2 (ngPkt *p)
{
    rte_mbuf_prefetch_part2(p);
}


uint16_t ngPktPrivSize (ngPool *np)
{
    return rte_pktmbuf_priv_size(np); 
}


wniova_t ngPktDataIova (const ngPkt *np)
{
    return rte_mbuf_data_iova(np); 
}


wniova_t ngPktDataIovaDefault (const ngPkt *np)
{
    return rte_mbuf_data_iova_default(np);
}


ngPkt * ngPktFromIndirect (ngPkt *pi)
{
    return rte_mbuf_from_indirect(pi);
}


/* FIXME: Verify this func */
char * ngPktBufAddr (ngPkt *np, ngPool *p)
{
    return rte_mbuf_to_baddr(np);
}


char * ngPktDataAddrDefault (ngPkt *np)
{
    return rte_mbuf_data_iova_default(np);
}

char * ngPktTobaddr (ngPkt *md)
{
    return rte_mbuf_to_baddr(md);	
}


#if 0
void * ngPktToPriv (ngPkt *p)
{
    return rte_pktmbuf_pool_private(p);
}
#endif


uint16_t ngPktRefcntUpdate (ngPkt *p, int16_t value)
{
    return  rte_mbuf_refcnt_update(p, value);
}


uint16_t ngPktRefcntRead (const ngPkt *p)
{
    return rte_mbuf_refcnt_read(p);
}


void ngPktRefcntSet (ngPkt *p, uint16_t new_value)
{
    rte_mbuf_refcnt_set(p, new_value);
}


uint16_t ngPktExtRefcntRead (const ngPktExtSharedInfo *shinfo)
{
    return rte_mbuf_refcnt_read	(shinfo);	

}


void ngPktExtRefcntSet (ngPktExtSharedInfo *shinfo, 
                               uint16_t new_value)
{
    rte_mbuf_refcnt_set	(shinfo, new_value);	    
}


uint16_t ngPktExtRefcntUpdate (ngPktExtSharedInfo *shinfo, 
                                      int16_t value)
{
    return  rte_mbuf_ext_refcnt_update(shinfo, value);
}


void ngPktSanityCheck (const ngPkt *p, int is_header)
{
    rte_mbuf_sanity_check(p, is_header);
}

#if 0
int ngPktCheck (const ngPkt *p, int is_header, const char **reason)
{
    return rte_mbuf_check( p, is_header, *reason);	
}
#endif

ngPkt * ngPktRawAlloc (ngPool *np)
{
    return (ngPkt *) rte_mbuf_raw_alloc(np);
}


void ngPktRawFree (ngPkt *p)
{
    rte_mbuf_raw_free(p);
}


void ngPktInit (ngPool *np, void *opaque_arg, void *p, unsigned i)
{
    rte_pktmbuf_init(np, opaque_arg, p, i);
}


void ngPktpoolinit (ngPool *np, void *opaque_arg)
{
    rte_pktmbuf_pool_init(np, opaque_arg); 
}


ngPool * ngPoolCreate (const char *name, unsigned n, 
                             unsigned cache_size, uint16_t priv_size, 
                             uint16_t data_room_size, int socket_id)
{
    return rte_pktmbuf_pool_create(name, n, cache_size, priv_size,
                                   data_room_size, socket_id);
}


ngPool * ngPoolCreateByOps (const char *name, unsigned int n, 
                                  unsigned int cache_size, uint16_t priv_size, 
                                  uint16_t data_room_size, int socket_id, 
                                  const char *ops_name)
{
    return rte_pktmbuf_pool_create_by_ops(name, n, cache_size,
                                          priv_size, data_room_size,
                                          socket_id, ops_name);
 
}


uint16_t ngPktDataRoomSize (ngPool *np)
{
    return rte_pktmbuf_data_room_size(np);
}


void ngPktResetHeadRoom (ngPkt *p)
{
    rte_pktmbuf_reset_headroom(p);
}


ngPkt * ngPktAlloc (ngPool *np)
{
    return rte_pktmbuf_alloc(np);
}


ngPktExtSharedInfo * ngPktExtshInfoInitHelper (void *buf_addr, 
                     uint16_t *buf_len, ngPktExtbufFreeCallbackT free_cb, 
                     void *fcb_opaque)
{
    return rte_pktmbuf_ext_shinfo_init_helper (buf_addr, buf_len, 
                                             free_cb, fcb_opaque);
} 
 

void ngPktAttachExtBuf (ngPkt *p, void *buf_addr, 
                               wniova_t buf_iova, uint16_t buf_len, 
                               ngPktExtSharedInfo *shinfo)
{
    rte_pktmbuf_attach_extbuf(p,	buf_addr, buf_iova,  
                                    buf_len, shinfo);
}


void  ngPktAttach (ngPkt *pi, ngPkt *p)
{
    rte_pktmbuf_attach(pi, p);
}


void  ngPktDetach (ngPkt *p)
{
    rte_pktmbuf_detach(p);
}


ngPkt * ngPktPreFreeSeg (ngPkt *p)
{
    return rte_pktmbuf_prefree_seg(p);
}


void ngPktFreeSeg (ngPkt *p)
{
    rte_pktmbuf_free_seg	(p);	
}


void ngPktFree (ngPkt *p)
{
#if 0
    __rte_pktmbuf_prefree_seg(p);
#else
	rte_pktmbuf_free(p);
#endif
}


ngPkt * ngPktClone (ngPkt *md, ngPool *np)
{
    return  (ngPkt *) rte_pktmbuf_clone(md,np);
}


void ngPktRefCntUpdate (ngPkt *p, int16_t v)
{
    rte_pktmbuf_refcnt_update(p, v);
}


uint16_t ngPktHeadRoom (const ngPkt *p)
{
    return  rte_pktmbuf_headroom(p) ;
}


uint16_t ngPktTailRoom (const ngPkt *p)
{
    return  rte_pktmbuf_tailroom(p);
}


ngPkt * ngPktLastSeg (ngPkt *p)
{
    return (ngPkt *) rte_pktmbuf_lastseg(p);
}


char * ngPktPrepend (ngPkt *p, uint16_t len)
{
    return rte_pktmbuf_prepend(p, len);
}


char * ngPktAppend (ngPkt *p, uint16_t len)
{
    return rte_pktmbuf_append(p, len);
}


char * ngPktAdj (ngPkt *p, uint16_t len)
{
    return rte_pktmbuf_adj(p, len);
}


int ngPktTrim (ngPkt *p, uint16_t len)
{
    return rte_pktmbuf_trim(p, len);
}


int ngPktIsContiguous (const ngPkt *p)
{
    return rte_pktmbuf_is_contiguous(p);
}


const void * ngPktRead (const ngPkt *p, uint32_t off, 
                               uint32_t len, void *buf)
{
    return  rte_pktmbuf_read(p, off, len, buf);
}


int ngPktChain (ngPkt *head, ngPkt *tail)
{
    return rte_pktmbuf_chain( head, tail);
}


int ngValidateTxOffload (const ngPkt *p)
{
    return rte_validate_tx_offload(p);
}


int ngPktLinearize (ngPkt *npuf)
{
    return rte_pktmbuf_linearize(npuf);
}


void ngPktDump (FILE *f, const ngPkt *p, unsigned dump_len)
{
    rte_pktmbuf_dump(f, p, dump_len);
}


#if 0
uint32_t ngPktSchedQueueGet (const ngPkt *p)
{
    return rte_mbuf_sched_queue_get(p);
}


uint8_t ngPktSchedTrafficClassGet (const ngPkt *p)
{
    return rte_mbuf_sched_traffic_class_get(p);	
}
#endif

#if 0
uint8_t ngPktSchedColorGet (const ngPkt *p)
{
    return rte_mbuf_sched_color_get(p);	
}


void ngPktSchedGet (const ngPkt *p, uint32_t *queue_id, 
                           uint8_t *traffic_class, uint8_t *color)
{
    rte_mbuf_sched_get(p, queue_id, traffic_class, color);		
}


void ngPktSchedQueueSet (ngPkt *p, uint32_t queue_id)
{
    rte_mbuf_sched_queue_set(p, queue_id);	
}


void  ngPktSchedTrafficClassSet (ngPkt *p, uint8_t traffic_class)
{
    rte_mbuf_sched_traffic_class_set( p, traffic_class);	
}


void ngPktSchedColorSet (ngPkt *p, uint8_t color)
{
    rte_mbuf_sched_color_set(p, color);	
}


void ngPktSchedSet (ngPkt *p, uint32_t queue_id,
                           uint8_t traffic_class, uint8_t color)
{
    rte_mbuf_sched_set(p, queue_id, traffic_class, color); 
}

#endif

/*EOF*/
