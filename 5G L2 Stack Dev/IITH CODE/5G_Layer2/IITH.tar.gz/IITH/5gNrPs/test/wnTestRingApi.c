/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/


/**
 * @file wnTestRingApi.c
 * @author Manoj Kumar
 *
 * @brief driver function to test Ring APIs functionalities for framework
 *
 * @see http://git.wisig.com
 */


#include "../csrc/common/ngRing/wnRingApi.h"


/**
 * @brief Driver (main) function, to test ring apis functionalities
 *
 * @param argc count the number of arguments
 * @param argv number of values
 * @returns ret as integer
 */
//wnInt32 wnRingMain ( wnInt32 argc, wnChar **argv )
wnInt32 main ( wnInt32 argc, wnChar **argv )
{

    wnInt32 ret = -1;
    ngRing *wnRingBuf = NULL;
    /** Dummy ngPkt to test ring apis */
    ngPkt pktVals1, pktVals2, pktVals3[2];
    ngPkt *pkt3, *pkt4, *pkt6[2] ;
    pktVals1.test = 10;
    pktVals1.testvar =12 ;
    pktVals2.test = 15;
    pktVals2.testvar =16 ;
    pktVals3[0].test = 11;
    pktVals3[0].testvar =18 ;
    pktVals3[1].test = 19;
    pktVals3[1].testvar =26 ;
    ngPkt *pkt1 = &pktVals1;
    ngPkt *pkt2 = &pktVals2;
    ngPkt *pkt5 = pktVals3;
    /** To initialize */
    rte_eal_init ( argc, argv );
    /** To create a ring as wnTest */
    wnRingBuf = wnRingHndlr ( "wnTest", WN_RING_SIZE, SOCKET_ID_ANY,
                                      WN_RING_F_SP_ENQ | WN_RING_F_SC_DEQ );
    if ( wnIsNgRingFull ( wnRingBuf ) )
    {
        printf ( "Ring is full \n");
    }
    if ( wnIsNgRingEmpty ( wnRingBuf ) )
    {
        printf ( "Ring is empty \n");
    }
    printf ("Before enq (pkt1) %p %d %d\n", pkt1, pkt1->test, pkt1->testvar);
    if ( wnEnqElem2Ring ( wnRingBuf, ( wnVoid ** ) pkt1 ) )
    {
        wnErrHndlr ("Error : Enqueue operation failed\n");
    }
    printf ("Before enq(pkt2) %p %d %d \n", pkt2, pkt2->test, pkt2->testvar);
    if ( wnEnqElem2Ring ( wnRingBuf, ( wnVoid ** ) pkt2 ) )
    {
        wnErrHndlr ("Error : Enqueue operation failed\n");
    }
    printf ( "Before enq(pkt5 [0]) %p %d %d\n", pkt5, (pkt5)->test, (pkt5)->testvar );
    printf ( "Before enq(pkt5 [1]) %p %d %d\n", (pkt5+1), (pkt5+1)->test, (pkt5+1)->testvar );
    wnEnqBulkElem2Ring ( wnRingBuf, ( wnVoid **) &pkt5, 2, NULL );
    printf ( "Enqueue operation is successful\n" );
    printf("%u ring entries are now free\n",  wnNumOfFreeEntries (wnRingBuf) );
    printf("%u ring entries are now \n",  wnNumOfEntries (wnRingBuf) );
    /** To dequeue element in ring */
    if ( wnDeqElemFrmRing ( wnRingBuf,  (wnVoid **)&pkt3 ) )
    {
        wnErrHndlr ("Error : Dequeue operation failed\n");
    }
    printf ("After Deq (pkt3) %p  %d  %d\n", pkt3, pkt3->test, pkt3->testvar );
    if ( wnDeqElemFrmRing ( wnRingBuf,  (wnVoid **) &pkt4 ) )
    {
        wnErrHndlr ("Error : Dequeue operation failed\n");
    }
    printf ("After deq (pkt4) %p  %d  %d\n", pkt4, pkt4->test, pkt4->testvar );
    wnDeqBulkElemFrmRing ( wnRingBuf, (wnVoid **) &pkt6, 2, NULL );
    printf ("After Deq (pkt6 [0]) %p  %d  %d\n", *pkt6, pkt6[0]->test, pkt6[0]->testvar );
    (*pkt6)++;
    printf ("After Deq (pkt6 [1]) %p  %d  %d\n", *pkt6, pkt6[0]->test, pkt6[0]->testvar );
    printf ( "Dequeue operation is successful\n" );
    printf("%u ring entries are now free\n", wnNumOfFreeEntries (wnRingBuf) );
    printf("%u ring entries are now \n", wnNumOfEntries (wnRingBuf) );
    wnFreeRing ( wnRingBuf );
    printf ( "Ring operation is successful\n" );
    return ret;
}

