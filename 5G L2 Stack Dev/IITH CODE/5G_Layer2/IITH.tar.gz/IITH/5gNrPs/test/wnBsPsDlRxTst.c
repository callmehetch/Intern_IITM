/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wnBsPsDlRxTst.c
 * @author Venkat Rahul
 * @brief Rx  file for Base Station Protocol Stack
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 */

#include <netdb.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <stdbool.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netpacket/packet.h>
#include <net/ethernet.h>
#include <sys/ioctl.h>
#include <net/if.h>

#include "../csrc/common/ngPkt/wnNgPktApi.h"
#include "../csrc/L2/rlc/wn5gNrPsRlcAMApi.h"
#include "../csrc/L2/rlc/wn5gNrPsRlcUMApi.h"
#include "../csrc/L2/pdcp/wn5gNrPdcp.h"
#include "../csrc/L2/pdcp/wn5gNrPsPdcpHdr.h"
#include "../csrc/L2/sdap/wn5gNrPsSdapApi.h"
#include "../csrc/L2/mac/wn5gNrPsMacApi.h"
#include "../csrc/L2/mac/wn5gNrPsMacDlRarApi.h"

#define PORT 5555
#define SA struct sockaddr
#define DEBUG 0
#define WN_LOG_DEBUG printf

int main(int argc, char *argv[])
{
    wnInt32 i;                    /** Increment Variable */
    ngPkt *pktBuf = NULL;    /** mBuf Allocation Address collection variable */
    wnInt32 j;                /** Increment Variable */
    wnInt32 ret;              /** EAL intiation check variable */
    ngPool *mbuf_pool; /*  Memory pool for packets */
    wnUChar *data;
    wnUInt32 cnt=0;
    wnInt32 len =1500;
    struct sockaddr_in servaddr;
 #ifdef RING_TEST
    wnRingMain();
    return 0;
#endif
  printf("%s\n",argv[1]); 
    ret = rte_eal_init(argc, argv);
    if ( ret < 0 )
    {
        rte_exit(EXIT_FAILURE, "EAL Init failed\n");
    }
    
    /** Creates a new mbuf mempool */
    mbuf_pool = ngPoolCreate("DL_TX_POOL", MAX_ELT_SIZE, MBUF_CACHE_SIZE, 0,
            (MAX_TB_SZ - RTE_PKTMBUF_HEADROOM), rte_socket_id());
    
    if (mbuf_pool == NULL)
     {
         rte_exit(EXIT_FAILURE, "mbuf_pool create failed\n");
     }
    
    wnInt32 sockfd;

    
    /** socket create and varification */
    
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    
    if (sockfd == -1)
    {
        WN_LOG_DEBUG("socket creation failed...\n");
        exit(0);
    }
    else
    {
        WN_LOG_DEBUG("Socket successfully created..\n");
    }
    
    /** assign IP, PORT */
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT );
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);

    /** connect the client socket to server socket */
        if (connect(sockfd, (SA*)&servaddr, sizeof( servaddr)) != 0)
        {
            WN_LOG_DEBUG("connection with the server failed...\n");
            return 0;
        }
        else
        {
            WN_LOG_DEBUG("connected to the server..\n");
        }

    while(cnt<10000)
    {
        /** Allocate Mbuf from Pool */
        pktBuf = ngPktAlloc(mbuf_pool);
        if (NULL == pktBuf) 
        {
            printf("mbuf allocation failed \n");
            return 0;
        }
        /** Append data pointer to mbuf */
        data = ngPktAppend(pktBuf, len);

        wnUInt32 var = 0;

#if 0
        /** Packet Receive */
        if ((var = read( sockfd, pktBuf, RTE_MBUF_DEFAULT_BUF_SIZE )) <= 0) {
	    if (var < 0) {
                break;
	    }
	    else {
                cnt++;
	    }
        }
#endif
   /** Packet Receive */
        if ((read( sockfd,pktBuf, RTE_MBUF_DEFAULT_BUF_SIZE )) <= 0) 
        {
		       break;
	    }
	    ++cnt;

#if DEBUG
        unsigned char *hdrptr = pktBuf;
        printf("\n===receved len ========%d\n", var);
        printf("\n-----Recevied Packet-------\n");
        for( int m = 0; m < var; m++ )
            printf("%02x ", *( hdrptr+m ) );
        printf("\n-----------------------------------------\n");
        i = 0;
        /** MAC  */
        /** Mac 8 bit Header  */
        printf ("\n-----MAC Header-----\nSize of Mac 8bit Header:%d \n",\
                sizeof( wnMacSch8bSbHdrT ) );
        printf("---Mac 8bit header Values in hex-------\n");
        for(  j = 0; j < sizeof( wnMacSch8bSbHdrT ); j++, i++ )
        {
            printf("%02x ",hdrptr[i]);
        }
        wnMacSch8bSbHdrT macHdr;
        memcpy(&macHdr,&hdrptr[i-2],sizeof( wnMacSch8bSbHdrT ));
        printf("\n--------Mac 8bit header Values----------\n");
        printf("Format                   :       %d\n",macHdr.format);
        printf("LCID                     :       %d\n",macHdr.lcid);
        printf("Length                   :       %d\n",macHdr.len);
        printf("-------------------\n");

        /** RLC  */
        /** RLC 12 bit Header  */
        printf("-----RLC Header-----\nSize of RLC AM 12 Bit Header:%d\n",\
                sizeof( wnRlcAm12HdrT ) );
        wnRlcAm12HdrT rlcHdr;
        printf("-------RLC AM Header 12 bit in hex-------\n");
        for( j = 0; j < sizeof( wnRlcAm12HdrT ); j++, i++ )
        {
            printf("%02x ",hdrptr[i]);
        }
        memcpy(&rlcHdr,&hdrptr[i-2],sizeof( wnRlcAm12HdrT ));
        printf("\nRLC AM Header 12 bit Values\n");
        printf("d_c                      :       %d\n",rlcHdr.dc);
        printf("poll                     :       %d\n",rlcHdr.poll);
        printf("si                       :       %d\n",rlcHdr.si);
#if (!LIT_END)
        printf("Sequence Number      :       %d\n",rlcHdr.sn);
#endif
#if LIT_END
        wnUInt32 seqno;
        seqno=(rlcHdr.sn1<<8)|(rlcHdr.sn2);
        printf("SequenceNumber MSB       :    %d\n",rlcHdr.sn1);
        printf("SequenceNumber LSB       :    %d\n",rlcHdr.sn2);
        printf("SequenceNumber           :    %d  :%x\n",seqno,seqno);
        printf("-------------------\n");
#endif
        /** PDCP Header */
        wnPdcpUHdr18DrbT pdcpHdr;
        printf("----PDCP Header-----\nsize of PDCP 18 bit sn Header:%d\n",\
                sizeof( wnPdcpUHdr18DrbT ) );
        printf("-------PDCP hdr hex value-------\n");
        for( j = 0; j < sizeof( wnPdcpUHdr18DrbT ); j++, i++ )
        {
            printf("%02x ",hdrptr[i]);
        }
        memcpy(&pdcpHdr,&hdrptr[i-3],sizeof( wnPdcpUHdr18DrbT ));
        printf("\n----PDCP 18 bit sn DRB hdr Values---\n");
        printf("Data or Control       :      %d\n",pdcpHdr.d_c);
#if (!LIT_END)
        printf("sn                :      %d\n",pdcpHdr.sn);
#endif
#if LIT_END
        wnUInt32 seqno1;
        seqno1=(pdcpHdr.sn1<<16)|(pdcpHdr.sn2<<8)|(pdcpHdr.sn3);
        printf("SequenceNumber MSB1       :    %d\n",pdcpHdr.sn1);
        printf("SequenceNumber MSB2       :    %d\n",pdcpHdr.sn2);
        printf("SequenceNumber LSB        :    %d\n",pdcpHdr.sn3);
        printf("SequenceNumber            :    %d  :%x\n",seqno1,seqno1);
#endif

        printf("-------------------\n");

        /* Sdap Header  */
        wnSdapHdrT sdapHdr;
        printf("----SDAP Header-----\nsize of SDAP Header:%d\n",\
                sizeof( wnSdapHdrT ) );
        printf("--------Sdap hdr hex value-------\n");
        for( j = 0; j < sizeof( wnSdapHdrT ); j++, i++ )
        {
            printf("%02x ",hdrptr[i]);
        }
        printf("\nSDAP header values\n");
        memcpy(&sdapHdr,&hdrptr[i-1],sizeof( wnSdapHdrT ));
        printf("Qfi                       :        %d\n",sdapHdr.qfi);
        printf("Rqi                       :        %d\n",sdapHdr.rqiR);
        printf("Rdi                       :        %d\n",sdapHdr.rdiDc);
        printf("-------------------\n");
        printf("Packet data lenfth %d\n", pktBuf->data_len );
        printf("Packet headroom remaining: %d\n", ngPktHeadRoom( pktBuf ) );
        printf("Packet tailroom remaining: %d\n", ngPktTailRoom( pktBuf ) );
        printf("\nPacket Count=%d\n",cnt );
#endif
  //      ngPktFree(pktBuf);
    
//        printf("\nNo of Packets Received= %d\n", cnt);
        //printf(".");
    }
    /** close the socket */
    close( sockfd );
    printf("\nNo of Packets Received= %d\n", cnt);
    return 0;
}
