/*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 ****************************************************************************/
/**
 * @file wnTestTimerApi.c
 * @author balu 
 * @brief file containing test main to test APIs for timers.
 *
 * @see 
 * @see 
 */

#include "../csrc/common/ngTimer/wnTimerApi.h"


/**
 * @brief timer0 callback function
 *
 * @param tim The timer handle
 * @returns
 */
wnVoid wnTimer0Cb (wnTimer *timer0)
{
    wnChar buf[1000];
    static wnUInt32 count = 0;
    wnChar append[100];
    struct timeb start;
    wnInt32 ret;
    ftime(&start);
    strftime(buf, 1000, "%H:%M:%S", localtime(&start.time));
    /* append milliseconds */
    sprintf(append, ":%03u", start.millitm);
    strcat(buf, append);
    FILE *fd=fopen("timer_log.txt","a");
    fprintf(fd,"%s",buf);
    fprintf(fd,"\n");
    fclose(fd);
    if((count++)== 100)
    {
      /* stops the timer associated with the timer handle timi after 100 itrations. 
      It may fail if the timer is currently running or being configured */
    ret = wnTimerStop (timer0);
    if(ret < 0)
    {
        printf("failed: %d\n", ret);
    }
    else
    {
        printf("sucess Timer 0 stopped: %d\n", ret);
        return;
    }
    }
}


/**
 * @brief main function to test the timer APIS with different intervels
 *
 * @param 
 * @returns
 */
wnInt32 wnTimerMain(wnInt32 argc, wnChar **argv)
{
    wnTimer timer0;
	wnInt32 ret;
    wnUInt64 hz;
	wnUInt32 lcore_id;
    wnInt32 choice;
  	/* init EAL */
	ret = rte_eal_init(argc, argv);
	if (ret < 0)
		rte_panic("Cannot init EAL\n");
    /*initialize timer sud system */
    wnTimerSubSystemInit();
    /* timer initialization */
    wnTimerInit(timer0);
	hz = wnGetTimerHz ();
	lcore_id = wnLcoreId ();
	/* load timer0, every second, on master lcore, reloaded automatically */
    printf("\n1 100 microsec multishot timer start\n2 200 microsec multishot\
    timer start\n3 300 microsec multishot timer start\n4 400 microsec\
    multishot timer start\n5  500 microsec multishot timer start\n6 1 millisec\
    multishot timer start\n7 1 sec oneshot timer start\n");
    printf("Enter the choice which timer has to run\n");
    scanf("%d",&choice);
    switch (choice)
    {
        case 1 :
	            printf("******************* test case one on lcore with 100\
                microsec multishot timer start ********** %u\n", lcore_id);
                if ((ret= wnTimerStart(&timer0, hz/10000, PERIODICAL, 
                    lcore_id,(wnVoid *)wnTimer0Cb)==0))
                {
                    printf("success\n");
                }
                else
                {
                    printf("failure\n");
                }
	            printf("******************* test case one on lcore with 100\
                microsec multishot timer stop********** %u\n", lcore_id);
                break ;
        case 2 :
	            printf("******************* test case one on lcore with 200\
                microsec multishot timer start ********** %u\n", lcore_id);
                if ((ret= wnTimerStart(&timer0, hz/5000, PERIODICAL, lcore_id, 
                     (wnVoid *)wnTimer0Cb)==0))
                {
                    printf("success\n");
                }
                else
                {
                    printf("failure\n");
                }
	            printf("******************* test case one on lcore with 200\
                microsec multishot timer stop ********** %u\n", lcore_id);
	            break;
        case 3 :
                printf("******************* test case one on lcore with 300\
                microsec multishot timer start ********** %u\n", lcore_id);
                if ((ret= wnTimerStart(&timer0, hz/3333, PERIODICAL, lcore_id,
                     (wnVoid*)wnTimer0Cb)==0))
                {
                    printf("success\n");
                }
                else
                {
                    printf("failure\n");
                }
	            printf("******************* test case one on lcore with 300\
                microsec multishot timer stop********** %u\n", lcore_id);
                break;
        case 4 :
	            printf("******************* test case one on lcore with 400\
                microsec multishot timer start ********** %u\n", lcore_id);
                if ((ret= wnTimerStart(&timer0, hz/2500, PERIODICAL, lcore_id,
                     (wnVoid*)wnTimer0Cb)==0))
                {
                    printf("success\n");
                }
                else
                {
                    printf("failure\n");
                }
	            printf("******************* test case one on lcore with 400\
                microsec multishot timer stop********** %u\n", lcore_id);
	            break;
        case 5 :
                printf("******************* test case one on lcore with 500\
                microsec multishot timer start ********** %u\n", lcore_id);
                if ((ret= wnTimerStart(&timer0, hz/2000, PERIODICAL, lcore_id
                    ,(wnVoid *)wnTimer0Cb)==0))
                {
                    printf("success\n");
                }
                else
                {
                    printf("failure\n");
                }
	            printf("******************* test case one on lcore with 500\
                microsec multishot timer stop********** %u\n", lcore_id);
	            break;
        case 6 :
                printf("******************* test case one on lcore with 1\
                millisec multishot timer start ********** %u\n", lcore_id);
                if ((ret= wnTimerStart(&timer0, hz/1000, PERIODICAL, lcore_id,
                    (wnVoid*)wnTimer0Cb)==0))
                {
                    printf("success\n");
                }
                else
                {
                    printf("failure\n");
                }
	            printf("******************* test case one on lcore with 1\
                millisec multishot timer stop********** %u\n", lcore_id);
                break;
        case 7 :
                printf("******************* test case one on lcore with 1 sec\
                one shot timer start ********** %u\n", lcore_id);
                if ((ret= wnTimerStart(&timer0, hz, SINGLE, lcore_id, 
                    (wnVoid*)wnTimer0Cb)==0))
                {
                    printf("success\n");
                }
                else
                {
                    printf("failure\n");
                }
	            printf("******************* test case one on lcore with 1 sec\
                one shot timer stop********** %u\n", lcore_id);
                break;
    }
	/* call it on master lcore too */
     wnlcoreMainloop();
     printf("===============================\n");
	 return 0;
}

