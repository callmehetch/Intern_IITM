 /*****************************************************************************
 * Copyright (c) 2016-2018, WiSig Networks Pvt Ltd. All rights reserved.     *
 * www.wisig.com                                                             *
 *                                                                           *
 * All information contained herein is property of WiSig Networks Pvt Ltd.   *
 * unless otherwise explicitly mentioned.                                    *
 *                                                                           *
 * The intellectual and technical concepts in this file are proprietary      *
 * to WiSig Networks and may be covered by granted or in process national    *
 * and international patents and are protect by trade secrets and            *
 * copyright law.                                                            *
 *                                                                           *
 * Redistribution and use in source and binary forms of the content in       *
 * this file, with or without modification are not permitted unless          *
 * permission is explicitly granted by WiSig Networks.                       *
 * If WiSig Networks permits this source code to be used as a part of        *
 * open source project, the terms and conditions of CC-By-ND (No Derivative) *
 * license (https://creativecommons.org/licenses/by-nd/4.0/) shall apply.    *
 *****************************************************************************/

/**
 * @file wnBsPsDlTxTst.c
 * @author Nikita, Hemasai
 * @brief Dummy file for Base Station Protocol Stack
 *
 * @see http://git.wisig.com/root/5gNrBsPs/wikis/README
 */
#include <netdb.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>

#include "../csrc/common/ngPkt/wnNgPktApi.h"
#include "../csrc/L2/rlc/wn5gNrPsRlcAMApi.h"
#include "../csrc/L2/rlc/wn5gNrPsRlcUMApi.h"
#include "../csrc/L2/pdcp/wn5gNrPdcp.h"
#include "../csrc/L2/pdcp/wn5gNrPsPdcpHdr.h"
#include "../csrc/L2/sdap/wn5gNrPsSdapApi.h"
#include "../csrc/L2/mac/wn5gNrPsMacApi.h"
#include "../csrc/L2/mac/wn5gNrPsMacDlRarApi.h"

#define PORT 5555
#define SA struct sockaddr
#define DEBUG 0
#define WN_LOG_DEBUG printf
/**
 * NOTE: This is just a test code to test the header addition functionality
 * using the API's provided by the framework.
 *
 * GTP and PDU Session container are still not completely functional.
 *
 */

/* Prototypes */
int wn5gNrPlatformInit (int, char **);
int wn5gNrSdapSubLyrFn (wnSdapHdrP *, ngPkt*);
int wn5gNrPdcpSubLyrFn (wnPdcpUHdr18DrbP*, ngPkt*);
int wn5gNrRlcAmsubLyrFn (wnVoid**, ngPkt*);
int wn5gNrMacSubLyrFn (wnMacSch8bSbHdrP*, ngPkt*);

/** Printing the parameters */
int wn5gNrPrintSdapParams (wnSdapHdrP);
int wn5gNrPrintPdcpParams (wnPdcpUHdr18DrbP);
int wn5gNrPrintRlcAmParams (wnRlcAm12HdrP);
int wn5gNrPrintMacParams (wnMacSch8bSbHdrP );

/** @brief function to initialise the DPDK platform
 */
int wn5gNrPlatformInit ( int argc, char **argv)
{
    int ret = rte_eal_init(argc, argv);
    if (ret < 0)
    {
         rte_exit(EXIT_FAILURE, "EAL Init failed\n");
    }
    return 0;
}

#if 0
int wn5gNrGtpIntfceFn (wnGTPv1UP *GTPv1UHdr, wnPDUSessionContainerP *PDUSessionContainerHdr, struct rte_mbuf *pktBuf)
{
    if (NULL != *GTPv1UHdr)
    {
        *GTPv1UHdr = (wnGTPv1UP) wnGTPv1UAlloc( &pktBuf );
        if (NULL == *GTPv1UHdr)
        {
             return -1;
        }
        *GTPv1UHdr = (wnGTPv1UP) wnGTPv1UInit( *GTPv1UHdr ,0,0,1,0,0,1,0,0,1,0,0,1 );
        *PDUSessionContainerHdr = (wnPDUSessionContainerP)wnPDUSessionContainerAlloc( &pktBuf );
        if (NULL == *PDUSessionContainerHdr)
        {
            return -1;
        }
        *PDUSessionContainerHdr = (wnPDUSessionContainerP)wnPDUSessionContainerInit( *PDUSessionContainerHdr ,0,0,1,0,0);
    }
    else
    {
        printf("NULL Buffer \n");
    return -1;
    }
    printf("GTP Done \n");
    return 0;
}

int wn5gNrPrintGtpParams(wnGTPv1UP GTPv1UHdr,wnPDUSessionContainerP PDUSessionContainerHdr)
{
    printf("Size of GTP header                :       %lu\n",sizeof(wnGTPv1UT));
    printf("version                           :       %d\n",GTPv1UHdr->version);
    printf("ProtocolTypeFlag                  :       %d\n",GTPv1UHdr->ProtocolTypeFlag);
    printf("Spare                             :       %d\n",GTPv1UHdr->Spare);
    printf("ExtensionFlag                     :       %d\n",GTPv1UHdr->ExtensionFlag);
    printf("SequenceNumberFLAG                :       %d\n",GTPv1UHdr->SequenceNumberFLAG );
    printf("NpduNumberFlag                    :       %d\n",GTPv1UHdr->NpduNumberFlag );
    printf("MessageType                       :       %d\n",GTPv1UHdr->MessageType);
    printf("Length                            :       %d\n",GTPv1UHdr->Length);
    printf("TEID                              :       %d\n",GTPv1UHdr->TEID);
    printf("SequenceNumber                    :       %d\n",GTPv1UHdr->SequenceNumber);
    printf("NPDUNumber                        :       %d\n",GTPv1UHdr->NPDUNumber);
    printf("NextExtensionHeaderType           :       %d\n",GTPv1UHdr->NextExtensionHeaderType);
    printf("\n");
    printf("LengthInOctet                     :       %d\n",PDUSessionContainerHdr->LengthInOctet);
    printf("PDUSSessionContainer1             :       %d\n",PDUSessionContainerHdr->PDUSSessionContainer1);
    printf("PDUSSessionContainer2             :       %d\n",PDUSessionContainerHdr->PDUSSessionContainer2);
    printf("PDUSSessionContainer3             :       %d\n",PDUSessionContainerHdr->PDUSSessionContainer3);
    printf("NextExtensionHeaderType           :       %d\n",PDUSessionContainerHdr->NextExtensionHeaderType);
    printf("\n");
    return 0;
}
#endif

/** @brief function to initialise the SDAP sublayer
 */
int wn5gNrSdapSubLyrFn(wnSdapHdrP *sdapHdr,struct rte_mbuf *pktBuf)
{
    *sdapHdr = (wnSdapHdrP) wnSdapHdrAlloc( &pktBuf );
    if(NULL == *sdapHdr)
    {
        printf("sdap int failed\n");
        return -1;
    }

    if (wnSdapHdrQfi (sdapHdr, 10) == WN_FAILURE) {
        WN_LOG_DEBUG("QoS Flow ID Not Updated\n");
    }
    if (wnSdapHdrRqi (sdapHdr, 0) == WN_FAILURE) {
        WN_LOG_DEBUG("RQI Not Updated\n");
    }
    if (wnSdapHdrRdi (sdapHdr, 1) == WN_FAILURE) {
        WN_LOG_DEBUG("RDI Not Updated\n");
    }

    return 0;
}

/** @brief function to print the SDAP header
 */
int wn5gNrPrintSdapParams(wnSdapHdrP sdapHdr)
{
    printf("\n==================SDAP HDR Values=============\n");
    printf("Qfi                               :        %d\n",sdapHdr->qfi);
    printf("Rqi                               :        %d\n",sdapHdr->rqiR);
    printf("Rdi                               :        %d\n",sdapHdr->rdiDc);
    wnUChar *hdr;
    hdr = (wnUChar*)sdapHdr;
    printf("=======================SDAP HDR IN HEX=============\n");

    printf("%02x ",hdr[0] );
    return 0;
}

/** @brief function to initialise the PDCP sublayer
 */
int wn5gNrPdcpSubLyrFn(wnPdcpUHdr18DrbP *PdcpDrb18Hdr,struct rte_mbuf *pktBuf)
{
    *PdcpDrb18Hdr = wn5gNrPdcpUHdr18DrbAlloc( &pktBuf );
    if(NULL == *PdcpDrb18Hdr)
    {
        return -1;
    }
    *PdcpDrb18Hdr = wn5gNrPdcpUHdr18DrbInit( *PdcpDrb18Hdr,1,0,192427);
    return 0;
}

/** @brief function to print PDCP parameters
 */
int wn5gNrPrintPdcpParams(wnPdcpUHdr18DrbP pdcpHdr18Drb)
{
    printf("\n==============PDCP HDR IN HEX=============\n");
    printf("Data or Control                  :    %d\n",pdcpHdr18Drb->d_c);

    #if (!LIT_END)
        printf("SequenceNumber                   :    %d\n",pdcpHdr18Drb->sn);
    #endif

    #if LIT_END
        wnUInt32 seqno;
        seqno=(pdcpHdr18Drb->sn1<<16)|(pdcpHdr18Drb->sn2<<8)|(pdcpHdr18Drb->sn3);

        printf("SequenceNumber                :    %d\n",pdcpHdr18Drb->sn1);
        printf("SequenceNumber2                :    %d\n",pdcpHdr18Drb->sn2);
        printf("SequenceNumber3                :    %d\n",pdcpHdr18Drb->sn3);
        printf("SequenceNumber                :    %d  :%x\n",seqno,seqno);
    #endif

    wnUChar *hdr;
    hdr = (wnUChar*)pdcpHdr18Drb;


    printf("\n=======================PDCP HDR IN HEX=============\n");

    printf("%02x ",hdr[0] );
    printf("%02x ",hdr[1] );
    printf("%02x ",hdr[2] );
    return 0;
}

/** @brief function to initialise the RLC sublayer
 */
int wn5gNrRlcAmsubLyrFn(wnVoid **amHdr, ngPkt *pktBuf)
{
    *amHdr = wnRlcAMHdrAlloc(&pktBuf, 12);
    //wnRlcAMHdrInit( *amHdr, 0, 0, 0, 0, 0, 12 );
    wnRlcSetDcBit(*amHdr, 12);
    //wnRlcUpdateSo(*amHdr, 3, 12);
    wnRlcSetPollBit(*amHdr, 1, 12);
    wnRlcUpdateSi(*amHdr, 0, 12);

    wnRlcUpdateSn(*amHdr, 0xeab, 12);
    return 0;
}

/** @brief function to print PDCP parameters
 */
int wn5gNrPrintRlcAmParams(wnRlcAm12HdrP amHdr)
{
    printf("Rlc AM12 header values\n");
    printf("\nsize of RLC AM 12 Bit Header:%d\n",sizeof( wnRlcAm12HdrT ) );

    printf("d_c                             :       %d\n",amHdr->dc);
    printf("poll                            :       %d\n",amHdr->poll);
    printf("si                              :       %d\n",amHdr->si);


    #if (!LIT_END)
    printf("sn                              :       %d\n",amHdr->sn);
    #endif
    #if LIT_END
    wnUInt32 seqno;
    seqno=(amHdr->sn1<<8)|amHdr->sn2;
    printf("sn1                             :       %d\n",amHdr->sn1);
    printf("sn2                             :       %d\n",amHdr->sn2);
    printf("sn                              :       %d   %02x\n",seqno,seqno);

    #endif

    printf("\n=======================RLC HDR IN HEX=============\n");
    wnUChar *amHdr1;
    amHdr1 = (wnUChar*)amHdr;

    for(int i = 0; i<2; i++)
        printf("%02x ",amHdr1[i] );

    return 0;
}

/** @brief function to initialise the MAC sublayer
 */
int wn5gNrMacSubLyrFn(wnMacSch8bSbHdrP *macDl, ngPkt *pktBuf)
{
    *macDl =(wnMacSch8bSbHdrP) wnMac8bHdrAlloc ( &pktBuf );
    if ( NULL == *macDl)
    {
        printf("Mac 8 bit hdr Init failed \n");
        return -1;
    }

    *macDl =(wnMacSch8bSbHdrP) wnMac8bHdrInit ( macDl, 1, 0, 3);
    wnMac8bHdrFrmt (*macDl,1);
    wnMac8bHdrLcid (*macDl, 7);
    wnMac8bHdrLen  (*macDl, 8);
    return 0;
}

/** @brief function to initialise the MAC sublayer
 */
int wn5gNrPrintMacParams(wnMacSch8bSbHdrP macDl)
{
    printf("\n===============MAC HDR Values============\n");
    printf("Format            :         %d\n",macDl->format);
    printf("LCID              :         %d\n",macDl->lcid);
    printf("Length            :         %d\n",macDl->len);

    printf("\n=======================MAC HDR IN HEX=============\n");
    wnUChar *macdl1;
    macdl1 = (wnUChar*)macDl;
    for(int i = 0; i<2; i++)
    printf("%02x ",macdl1[i] );
    return 0;
}


wnInt32 main(wnInt32 argc, wnChar *argv[])
{
    WN_LOG_DEBUG("Started ... \n");

    int option = 1;
    ngPool                 *mbuf_pool;
    wnChar                 *data;
    ngPkt                  *pktBuf = NULL;
    wnInt32                sockfd;
    wnInt32                connfd;
    wnInt32                length;
    struct sockaddr_in     servaddr, cli;

    /** Headers */
    wnPdcpUHdr18DrbP       PdcpDrb18Hdr;
    wnVoid                 *amHdr;
    wnMacSch8bSbHdrP       macDl;
    wnMacSch16bSbHdrP      mac16bDl;
    wnMacFixedSbHdrP       macFixDl;
    wnMacRarBiSbHdrP       macRarDl;
    wnMacRarRapidSbHdrP    macRapidDl;
    wnSdapHdrP             sdapHdr;

    wnUInt32               len = 256; /* TODO: Keep MACRO */

    wnUInt32               pktlen;
    wnUInt32               pktCnt;

    int status = wn5gNrPlatformInit( argc, argv );   /**< EAL initialisation */
    if (status != 0)
    {
        WN_LOG_DEBUG("Platform Init failed\n");
    }

    /** Creates an mbufpool */
    mbuf_pool = ngPoolCreate ("DL_TX_POOL", MAX_ELT_SIZE,
                                         MBUF_CACHE_SIZE, 0,
                                         ( MAX_TB_SZ - RTE_PKTMBUF_HEADROOM ),
	      		                 rte_socket_id()); /* TODO Need to change rte_socket_id */
    if (mbuf_pool == NULL)
    {
        WN_LOG_DEBUG("Pool creation failed\n");
    }


    /* socket create and verification */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        WN_LOG_DEBUG("socket creation failed...\n");
        exit(0);
    }
    else
        WN_LOG_DEBUG("Socket successfully created..\n");
    bzero(&servaddr, sizeof(servaddr));

    /* assign IP, PORT */
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    if(setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &option, sizeof(option)) < 0) {
	    printf("Sock opt error\n");
    }

    /* Binding newly created socket to given IP and verification */
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
        WN_LOG_DEBUG("socket bind failed...\n");
        return 0;
    }
    else
        WN_LOG_DEBUG("Socket successfully binded..\n");

    /* Now server is ready to listen and verification */
    if ((listen(sockfd, 5)) != 0) {
        WN_LOG_DEBUG("Listen failed...\n");
        return 0;
    }
    else
        WN_LOG_DEBUG("Server listening..\n");
    length = sizeof(cli);

        /* Accept the data packet from client and verification */
        connfd = accept(sockfd, (SA*)&cli, &length);
        if (connfd < 0) {
            WN_LOG_DEBUG("server acccept failed...\n");
            return 0;
        }
        else
        {
            WN_LOG_DEBUG("server acccept the client...\n");
        }

    while(pktCnt < 10000)
    {
        /** Need to add code to take packet from interface here */
        /** Allocation of an mbuf */
        pktBuf = ngPktAlloc (mbuf_pool);

        /** For filling data to payload */
        data =  ngPktAppend( pktBuf, len );

        /** function for generation of payload */
        wnBsPspktgen(data,len);
    	pktlen += len;

        /* FIXME: GTP Not defined properly */
        #if 0     /** GTP APIs */
            wnGTPv1UP GTPv1UHdr;
            wnPDUSessionContainerP PDUSessionContainerHdr;
            if (wn5gNrGtpIntfceFn(&GTPv1UHdr, &PDUSessionContainerHdr, pktBuf) < 0)
            {
                return -1;
            }
            p->hdrmap= p->hdrmap|GTPHDR_PRSNT;
            p->hdrLoc[0] = (wnVoid *)PDUSessionContainerHdr;
        #endif

        /* SDAP Sublayer */
        wn5gNrSdapSubLyrFn(&sdapHdr,pktBuf);
    	pktlen += sizeof(wnSdapHdrT);

        /* PDCP Sublayer */
        wn5gNrPdcpSubLyrFn( &PdcpDrb18Hdr, pktBuf);
    	pktlen += sizeof(wnPdcpUHdr18DrbT);

        /* RLC Sublayer */
        wn5gNrRlcAmsubLyrFn(&amHdr, pktBuf);
    	pktlen += sizeof(wnRlcAm12HdrT);

        /* MAC Sublayer */
        wn5gNrMacSubLyrFn(&macDl, pktBuf);
    	pktlen += sizeof(wnMacSch8bSbHdrT);
        hdrInfoP h = (hdrInfoP)wnGetHdrInfoFromMbuf(pktBuf);
        wnInt32 hdr = h->hdrmap;
        wnInt32 bir;
        #if DEBUG
        printf("\n---sdap param---\n");
        wn5gNrPrintSdapParams(sdapHdr);
        printf("\n---pdcp param---\n" );
        wn5gNrPrintPdcpParams (PdcpDrb18Hdr);
        printf("\n---rlc param---\n" );
        wn5gNrPrintRlcAmParams (amHdr);
        printf("\n---mac param---\n");
        wn5gNrPrintMacParams (macDl);

        printf("\nMempool resource remaining      :        %d\n", rte_mempool_avail_count(mbuf_pool));
        printf("Packet | Data Length              :        %d\n", pktBuf->data_len);
        printf("Packet | headroom remaining       :        %d\n", rte_pktmbuf_headroom(pktBuf));
        printf("Packet | tailroom remaining       :        %d\n", rte_pktmbuf_tailroom(pktBuf));

        printf("\n" );
        if (NULL == h)
        {
            printf("No header info \n");
            return 0;
        }


        printf("HDRINFO BITMAP: \t");  /**< for printing binary
                                         value */
        for ( wnInt32 c = 31; c >=0; c--)              /**< printing hdr info in
                                                            Binary */
        {
            bir = hdr >> c;
            if(bir & 1)
            {
                printf("1");
            }
            else
            {
                printf("0");
            }
        }

        printf("\n\n");
        printf("HDRINFO LOCATIONS: \t \n");

        for (int k = 0; k < MAXHDR; k++)
        {
            if (NULL != h->hdrLoc[k])
            {
                printf("\n header pointer [%d] : %p \n",k, (h->hdrLoc[k]));
            }
            printf("\n");
        }

        printf("\n");
        printf("pktlen %d\n", pktlen);

        /** Packet hex dump*/
        unsigned char *p;
        p = (unsigned char *) pktBuf->buf_addr;
        for(int i=0; i<266; i++)
        {
            printf("%02x ", p[i+120]);  /** 120 because head room is 128 and her len is 10*/
        }
        #endif



        //WN_LOG_DEBUG(" To receiver side :\n");
	usleep(999);

        /* sending mbuf to client */
        if(write(connfd, (pktBuf->buf_addr) +120, 266) < 0)
        {
            printf("!\n");
	    break;
        }
    	ngPktFree(pktBuf);
        // #define DELAY
        // #ifdef DELAY
        //         usleep(300);
        // #else
        // 		for (int delay = 100000;delay != 0; delay --);
        // #endif
        pktCnt++;
        #if DEBUG
        printf("---------Packet Count-----------:  %d\n",pktCnt );
        #endif
    }
    printf("---------Number of Packets sent-----------  %d\n",pktCnt );
    close(sockfd);
    return 0;
}

/* EOF */
